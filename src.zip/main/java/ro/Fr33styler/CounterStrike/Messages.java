/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package ro.Fr33styler.CounterStrike;

public enum Messages {
    PREFIX("\u00a78[\u00a73CS:GO\u00a78]"),
    WINNER("Winner"),
    SPLITTER("and"),
    LINE_PREFIX("  \u00a7c\u00a7lCS:GO"),
    LINE_SPLITTER("\u00a7a\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac\u25ac"),
    WINNER_TIMES_OUT("\u00a7eTimes out!#\u00a7eCops has won the round!"),
    ROUND_START("\u00a7a\u00a7lGo!"),
    ROUND_FIRST("\u00a7aHave fun!"),
    ROUND_WINNER_COP("\u00a7eRound winner: \u00a7cCops"),
    ROUND_WINNER_CRIMS("\u00a7eRound winner: \u00a7cCrims"),
    ROUND_TOP_COP("\u00a73Top cop: \u00a7f%player%\u00a7e - %kills% kills"),
    ROUND_MOST_WANTED("\u00a74Most wanted: \u00a7f%player%\u00a7e - %kills% kills"),
    ARENA_IS_NULL("\u00a7cGame dosen't exist!"),
    ARENA_JOIN_ANOTHER_GAME("\u00a7cYou can't play in more than 1 game!"),
    ARENA_IS_DISABLED("\u00a7cGame is disabled!"),
    ARENA_HAS_STARTED("\u00a7aGame already has started!"),
    ARENA_NO_TEXTURE("\u00a7cYou must have the texture in order to play!"),
    ARENA_IS_FULL("\u00a7cArena is full!"),
    TEAM_SWAP("\u00a7cTeams swapped!"),
    TITLE_GAME_OVER("\u00a7aGame Over"),
    BOMB_DEFUSED("\u00a7cBomb Defused"),
    BOMB_DEFUSING("\u00a7b\u00a7lBomb Defusing"),
    BOMB_PLANTED("\u00a7cBomb\u00a7e has been planted!"),
    BOMB_DEFUSING_CANCELED("\u00a7b\u00a7lBomb defusing has been canceled!"),
    BAR_INGAME("\u00a7fMap: \u00a7a%name% \u00a7fTime Left: \u00a7a%timer%"),
    BAR_WAITING("\u00a77You are currently playing \u00a7dCS:GO \u00a77on \u00a7a%name%"),
    GAME_START(" \u00a77Game starts in \u00a7c%timer%\u00a77 seconds."),
    GAME_JOIN(" \u00a7a%name% \u00a77has joined the game. \u00a78(\u00a7d%size%\u00a78/\u00a7d%maxsize%\u00a78)"),
    GAME_LEAVE(" \u00a7a%name% \u00a77has left the game. \u00a78(\u00a7d%size%\u00a78/\u00a7d%maxsize%\u00a78)"),
    GAME_LEFT(" \u00a7cYou left the game"),
    GAME_NO_PLAYERS(" \u00a7c\u00a7lThe game was stopped because a team has no more players!"),
    CHAT_PLAYING_FORMAT("\u00a78[%team%\u00a78] \u00a77%player%\u00a7f: %message%"),
    CHAT_GLOBAL_FORMAT("\u00a78[\u00a7eGlobal\u00a78]\u00a7c %player%\u00a7f: %message%"),
    CHAT_WAITING_FORMAT("\u00a77%player%\u00a7f: %message%"),
    SELECTOR_TEAM_A("\u00a77Click to join team \u00a7cA\u00a77!"),
    SELECTOR_TEAM_B("\u00a77Click to join team \u00a7cB\u00a77!"),
    SELECTOR_CHOOSE_TEAM_A("\u00a7aYou chose to be placed on Team A"),
    SELECTOR_CHOOSE_TEAM_B("\u00a7aYou chose to be placed on Team B"),
    SELECTOR_CHOOSE_TEAM_RANDOM("\u00a7aYou chose to be placed on random Team"),
    SELECTOR_NAME("Team Selector"),
    SELECTOR_LORE("\u00a77Choose a team."),
    SELECTOR_TEAM_RANDOM("\u00a77Click to join a \u00a7crandom\u00a77 Team!"),
    OPEN_SHOP("\u00a7eOpen the shop to buy equipment"),
    OPEN_SHOP_SPAWN("\u00a7cYou can open the shop only at the team spawn!"),
    OPEN_SHOP_30SECONDS("\u00a7cThe shop can be open only in the first 30 seconds!"),
    TEAM_SWAP_CRIMS("\u00a7aYou are a crim! Plant the bomb and kill the cops!"),
    TEAM_SWAP_COPS("\u00a7aYou are a cop! Kill the crims and defuse the bomb!"),
    BAR_BOMB_PLANT("\u00a7aYou got the \u00a7e\u9276\u00a7a, you must plant it at a bomb site!"),
    BAR_BOMB_PROTECTOR("\u00a7aEscort the bomb carrier \u00a7e\u9276\u00a7a at a bomb site to plant it!"),
    BAR_BOMB_DEFEND("\u00a7aDefend bomb sites and shots the crims"),
    BAR_PLAYERS("\u00a7cThere should be at least \u00a7b%min%\u00a7c for game to begin!"),
    BAR_RESPAWN_FIRST("\u00a7a\u00a7lDon't leave! \u00a7e\u00a7lYou will respawn next round!"),
    BAR_RESPAWN_SECOND("\u00a7a\u00a7lDon't leave! \u00a7f\u00a7lYou will respawn next round!"),
    BAR_BOMB_PLANTED_CRIMS_FIRST("\u00a7c\u00a7lThe bomb is planted! \u00a7e\u00a7lYou must protect it!"),
    BAR_BOMB_PLANTED_CRIMS_SECOND("\u00a7c\u00a7lThe bomb is planted! \u00a7f\u00a7lYou must protect it!"),
    BAR_BOMB_PLANTED_COPS_FIRST("\u00a7c\u00a7lThe bomb is planted! \u00a7e\u00a7lYou must defuse it!"),
    BAR_BOMB_PLANTED_COPS_SECOND("\u00a7c\u00a7lThe bomb is planted! \u00a7f\u00a7lYou must defuse it!"),
    RESTRICTED_COMMAND("\u00a7cYou can't use commands in-game!"),
    TEXTURE_DECLINED("\u00a7cYou can't play because you declined the texture!"),
    TEXTURE_ACCEPTED("\u00a7eWe are trying to send the game texture.."),
    TEXTURE_FAILED("\u00a7cWe couldn't send you the texture pack, please restart your game!"),
    TEXTURE_LOADED("\u00a7aNow you can play the game!"),
    SHOP_NOT_ENOUGH_MONEY("\u00a7cNot enough money!"),
    SHOP_NO_PERMISSION("\u00a7cYou don't have access to this weapon!"),
    SHOP_ITEM_NO_PERMISSION("\u00a7cYou don't have access to this item!"),
    SHOP_AFTER_30_SECONDS("\u00a7cThe time where you can buy equipment has expired!"),
    ALREADY_DEAD("\u00a7c\u00a7lYou died!"),
    SCOREBOARD_TITLE("\u00a78[\u00a73CS:GO\u00a78]"),
    SCOREBOARD_LOBBY_NAME("Name:"),
    SCOREBOARD_LOBBY_PLAYERS("Players:"),
    SCOREBOARD_LOBBY_GAME_START("Game starts in:"),
    SCOREBOARD_LOBBY_WAITING("Waiting..."),
    SCOREBOARD_LOBBY_SERVER("\u00a7ewww.spigotmc.org"),
    SCOREBOARD_GAME_OBJECTIVE("Objective"),
    SCOREBOARD_GAME_STATUS("Status"),
    SCOREBOARD_GAME_DEFUSE("Defuse the bomb!"),
    SCOREBOARD_GAME_PROTECT("Protect bomb sites!"),
    SCOREBOARD_GAME_PROTECT_BOMB("Protect the bomb!"),
    SCOREBOARD_GAME_PLANT_BOMB("Plant the bomb!"),
    SCOREBOARD_GAME_ESCORT_CARRIER("Protect the carrier!"),
    SCOREBOARD_GAME_MONEY("Money: "),
    SCOREBOARD_GAME_ARMOR("Armor: "),
    SCOREBOARD_GAME_DEATHS("Deaths: "),
    SCOREBOARD_GAME_KILLS("Kills: "),
    SCOREBOARD_GAME_ALIVE("Alive: "),
    STATE_WAITING("WAITING"),
    STATE_IN_GAME("IN GAME"),
    STATE_ENDING("ENDING"),
    STATE_DISABLED("DISABLED"),
    SIGN_QUICKJOIN("QuickJoin"),
    SIGN_FIRST("%prefix%"),
    SIGN_SECOND("%name%"),
    SIGN_THIRD("\u00a75\u2022 \u00a7f\u00a7l%state% \u00a75\u2022"),
    SIGN_FOURTH("\u00a7c\u00bb\u00a78\u00a7l%min%/%max%\u00a7c\u00ab"),
    ITEM_RIGHT_CLICK("Right click"),
    ITEM_BOMB_NAME("Bomb"),
    ITEM_KNIFE_NAME("Knife"),
    ITEM_SHOP_NAME("Shop"),
    ITEM_SHEAR_NAME("Shear"),
    ITEM_BOMB_LOCATOR("Bomb Locator"),
    ITEM_LEFTGAME_NAME("\u00a7c\u00a7lLeave game"),
    ITEM_LEFTGAME_LORE("\u00a77Leave the game."),
    TEAM_NAME("Team:"),
    TEAM_RANDOM("Random"),
    TEAM_FIRST("A"),
    TEAM_SECOND("B"),
    TEAM_TERRORIST_NAME("Crims"),
    TEAM_COUNTERTERRORIST_NAME("Cops"),
    COP_START_MESSAGE("\u00a7eYou are a cop! Prevent the bomb from#\u00a7ebeing planted and shot the criminals."),
    CRIMS_START_MESSAGE_NO_BOMB("\u00a7eYou are a criminal! Protect the bomb#\u00a7ecarrier and shoot the Cops you see."),
    CRIMS_START_MESSAGE_HAS_BOMB("\u00a7eYou are a criminal! Go to a bomb site#\u00a7eand shoot the Cops you see."),
    SHOP_ALREADY_BROUGHT("\u00a7c\u00a7lYou already have this item!"),
    SHOP_GRENADE_ALREADY_IN_SLOT("\u00a7c\u00a7lYou already have a grenade in that slot, drop it and try again!"),
    SHOP_GUN_ALREADY_IN_SLOT("\u00a7c\u00a7lYou already have a weapon in that slot, drop it and try again!"),
    NOT_ENOUGH_PLAYERS(" \u00a7c\u00a7lNot enough players!"),
    NEW_COMBATANTS("\u00a76New combatants:"),
    NO_GAME_FOUND("\u00a7cNo game found!"),
    GAME_MARKER("\u27a2 ");

    private String msg;

    private Messages(String string2) {
        this.msg = string2.replace('&', '\u00a7');
    }

    public void setMessage(String string) {
        this.msg = string.replace('&', '\u00a7');
    }

    public String toString() {
        return this.msg;
    }

    public static Messages getEnum(String string) {
        for (Messages messages : Messages.values()) {
            if (!messages.name().equals((Object)string)) continue;
            return messages;
        }
        return null;
    }
}
