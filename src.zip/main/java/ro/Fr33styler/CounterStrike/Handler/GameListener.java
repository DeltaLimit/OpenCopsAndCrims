/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.DataOutputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  org.bukkit.Bukkit
 *  org.bukkit.Effect
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.block.Sign
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockBurnEvent
 *  org.bukkit.event.block.BlockIgniteEvent
 *  org.bukkit.event.block.BlockIgniteEvent$IgniteCause
 *  org.bukkit.event.block.BlockPhysicsEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.block.SignChangeEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.EntityRegainHealthEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.hanging.HangingBreakByEntityEvent
 *  org.bukkit.event.hanging.HangingBreakEvent
 *  org.bukkit.event.hanging.HangingBreakEvent$RemoveCause
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.event.inventory.InventoryType$SlotType
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerGameModeChangeEvent
 *  org.bukkit.event.player.PlayerInteractAtEntityEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerItemConsumeEvent
 *  org.bukkit.event.player.PlayerItemHeldEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerLoginEvent
 *  org.bukkit.event.player.PlayerLoginEvent$Result
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerPickupItemEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerResourcePackStatusEvent
 *  org.bukkit.event.player.PlayerResourcePackStatusEvent$Status
 *  org.bukkit.event.player.PlayerSwapHandItemsEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.event.player.PlayerTeleportEvent$TeleportCause
 *  org.bukkit.event.player.PlayerToggleSneakEvent
 *  org.bukkit.event.server.PluginEnableEvent
 *  org.bukkit.event.server.ServerListPingEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.util.Vector
 *  ro.Fr33styler.CounterStrike.Api.GameLeaveEvent
 *  ro.Fr33styler.CounterStrike.Cache.PlayerShop
 *  ro.Fr33styler.CounterStrike.Cache.PlayerStatus
 *  ro.Fr33styler.CounterStrike.Cache.ShopType
 *  ro.Fr33styler.CounterStrike.Grenades.Grenade
 *  ro.Fr33styler.CounterStrike.Guns.Gun
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameManager
 *  ro.Fr33styler.CounterStrike.Handler.GameState
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam$Role
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.Messages
 *  ro.Fr33styler.CounterStrike.Utils.GameUtils
 *  ro.Fr33styler.CounterStrike.Utils.ItemBuilder
 *  ro.Fr33styler.CounterStrike.Version.SpigotSound
 */
package ro.Fr33styler.CounterStrike.Handler;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Sign;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import ro.Fr33styler.CounterStrike.Api.GameLeaveEvent;
import ro.Fr33styler.CounterStrike.Cache.PlayerShop;
import ro.Fr33styler.CounterStrike.Cache.PlayerStatus;
import ro.Fr33styler.CounterStrike.Cache.ShopType;
import ro.Fr33styler.CounterStrike.Grenades.Grenade;
import ro.Fr33styler.CounterStrike.Guns.Gun;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameManager;
import ro.Fr33styler.CounterStrike.Handler.GameState;
import ro.Fr33styler.CounterStrike.Handler.GameTeam;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.Messages;
import ro.Fr33styler.CounterStrike.Utils.GameUtils;
import ro.Fr33styler.CounterStrike.Utils.ItemBuilder;
import ro.Fr33styler.CounterStrike.Version.SpigotSound;

public class GameListener
implements Listener {
    private Main main;
    private Inventory selector = Bukkit.createInventory(null, (int)27, (String)Messages.SELECTOR_NAME.toString());

    public GameListener(Main main) {
        this.main = main;
        this.selector.setItem(11, ItemBuilder.create((Material)Material.YELLOW_DYE, (int)1, (int)14, (String)("&a" + Messages.TEAM_NAME + " " + Messages.TEAM_FIRST), (String)Messages.SELECTOR_TEAM_A.toString()));
        this.selector.setItem(13, ItemBuilder.create((Material)Material.GRAY_DYE, (int)1, (int)8, (String)("&a" + Messages.TEAM_RANDOM), (String)Messages.SELECTOR_TEAM_RANDOM.toString()));
        this.selector.setItem(15, ItemBuilder.create((Material)Material.GREEN_DYE, (int)1, (int)10, (String)("&a" + Messages.TEAM_NAME + " " + Messages.TEAM_SECOND), (String)Messages.SELECTOR_TEAM_B.toString()));
    }

    @EventHandler
    public void onBlockBurn(BlockBurnEvent blockBurnEvent) {
        blockBurnEvent.setCancelled(true);
    }

    @EventHandler
    public void onIgnite(BlockIgniteEvent blockIgniteEvent) {
        if (blockIgniteEvent.getCause() == BlockIgniteEvent.IgniteCause.SPREAD) {
            blockIgniteEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onGameModeChange(PlayerGameModeChangeEvent playerGameModeChangeEvent) {
        Game game;
        Player player = playerGameModeChangeEvent.getPlayer();
        if (playerGameModeChangeEvent.getNewGameMode() != GameMode.SPECTATOR && (game = this.main.getManager().getGame(player)) != null && game.inQueue(player)) {
            playerGameModeChangeEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent playerInteractEvent) {
        block22: {
            Player player;
            block19: {
                Gun gun;
                block20: {
                    Game game;
                    block21: {
                        block23: {
                            player = playerInteractEvent.getPlayer();
                            game = this.main.getManager().getGame(player);
                            if (game == null) break block19;
                            if (playerInteractEvent.getHand() != EquipmentSlot.HAND) {
                                playerInteractEvent.setCancelled(true);
                                return;
                            }
                            if (playerInteractEvent.getAction() != Action.RIGHT_CLICK_AIR && playerInteractEvent.getAction() != Action.RIGHT_CLICK_BLOCK) break block20;
                            if (game.getState() != GameState.WAITING) break block21;
                            if (player.getInventory().getItemInHand() == null) break block22;
                            if (player.getInventory().getItemInHand().getType() != Material.LEATHER) break block23;
                            player.openInventory(this.selector);
                            break block22;
                        }
                        if (player.getInventory().getItemInHand().getType() != Material.RED_BED) break block22;
                        playerInteractEvent.setCancelled(true);
                        this.main.getManager().removePlayer(game, player, false, false);
                        player.sendMessage(Messages.PREFIX + Messages.GAME_LEFT.toString());
                        break block22;
                    }
                    if (game.getState() != GameState.IN_GAME && game.getState() != GameState.ROUND) break block22;
                    ItemStack itemStack = player.getInventory().getItemInHand();
                    if (itemStack != null && itemStack.getType() != Material.AIR && itemStack.getType() == Material.GHAST_TEAR) {
                        if (this.main.getManager().isAtSpawn(game, player)) {
                            if (game.getTimer() > 90 || game.getState() == GameState.ROUND) {
                                player.openInventory((Inventory)game.getShops().get((Object)player.getUniqueId()));
                            } else {
                                player.sendMessage(Messages.SHOP_AFTER_30_SECONDS.toString());
                            }
                        } else {
                            player.sendMessage(Messages.OPEN_SHOP_SPAWN.toString());
                        }
                        return;
                    }
                    if (itemStack != null && itemStack.getType() != Material.AIR && game.getState() == GameState.IN_GAME) {
                        Grenade grenade;
                        Gun gun2;
                        if ((itemStack.getType() == Material.SHEARS || itemStack.getType() == Material.GOLD_NUGGET) && playerInteractEvent.getClickedBlock() != null && playerInteractEvent.getClickedBlock().getType() == Material.DAYLIGHT_DETECTOR) {
                            playerInteractEvent.setCancelled(true);
                            if (this.main.getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayers().contains((Object)player) && !game.isDefusing(player) && player.getLocation().distance(game.getBomb().getLocation()) <= 2.0) {
                                game.addDefuser(player, itemStack.getType() == Material.SHEARS ? 5 : 10);
                                player.playSound(player.getLocation(), SpigotSound.LEVEL_UP.getSound(), 1.0f, 1.0f);
                            }
                        }
                        if ((itemStack.getType() == Material.SHEARS || itemStack.getType() == Material.GOLD_NUGGET) && playerInteractEvent.getClickedBlock() != null && playerInteractEvent.getClickedBlock().getType() == Material.WHEAT) {
                            playerInteractEvent.setCancelled(true);
                            if (this.main.getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayers().contains((Object)player) && !game.isDefusing(player) && player.getLocation().distance(game.getBomb().getLocation()) <= 2.0) {
                                game.addDefuser(player, itemStack.getType() == Material.SHEARS ? 5 : 10);
                                player.playSound(player.getLocation(), SpigotSound.LEVEL_UP.getSound(), 1.0f, 1.0f);
                            }
                        }
                        if ((gun2 = this.main.getGun(itemStack)) != null && !game.isDefusing(player)) {
                            gun2.shot(game, player);
                        }
                        if ((grenade = this.main.getGrenade(itemStack)) != null && game.getState() == GameState.IN_GAME && !game.isRoundEnding() && !game.isDefusing(player)) {
                            playerInteractEvent.setCancelled(true);
                            grenade.throwGrenade(this.main, game, player);
                        }
                    }
                    break block22;
                }
                if (playerInteractEvent.getAction() != Action.LEFT_CLICK_AIR && playerInteractEvent.getAction() != Action.LEFT_CLICK_BLOCK) break block22;
                playerInteractEvent.setCancelled(true);
                ItemStack itemStack = player.getInventory().getItemInHand();
                if (itemStack != null && itemStack.getType() != Material.AIR && (gun = this.main.getGun(itemStack)) != null) {
                    gun.reload(player, player.getInventory().getHeldItemSlot());
                }
                break block22;
            }
            if (playerInteractEvent.getAction() == Action.RIGHT_CLICK_BLOCK && playerInteractEvent.getClickedBlock().getState() instanceof Sign) {
                Location location = playerInteractEvent.getClickedBlock().getLocation();
                for (Game game : this.main.getManager().getGames()) {
                    for (Location location2 : game.getSigns()) {
                        if (location.getWorld() != location2.getWorld() || location.distance(location2) != 0.0) continue;
                        playerInteractEvent.setCancelled(true);
                        this.main.getManager().addPlayer(player, game);
                        return;
                    }
                }
                for (Game game : this.main.getManager().getQuickJoinSigns()) {
                    if (!location.equals((Object)game)) continue;
                    Iterator iterator = this.main.getManager().findGame(player);
                    if (iterator == null) break;
                    if (iterator.getState() == GameState.WAITING) {
                        this.main.getManager().addPlayer(player, (Game)iterator);
                        break;
                    }
                    if (iterator.getState() != GameState.IN_GAME && iterator.getState() != GameState.ROUND) break;
                    this.main.getManager().addQuickPlayer((Game)iterator, player);
                    break;
                }
            }
        }
    }

    @EventHandler
    public void onDamageWithKnife(EntityDamageByEntityEvent entityDamageByEntityEvent) {
        Game game;
        if (entityDamageByEntityEvent.getEntity().getType() == EntityType.PLAYER && entityDamageByEntityEvent.getDamager().getType() == EntityType.PLAYER) {
            Player player = (Player)entityDamageByEntityEvent.getEntity();
            Player player2 = (Player)entityDamageByEntityEvent.getDamager();
            Game game2 = this.main.getManager().getGame(player);
            if (game2 != null) {
                entityDamageByEntityEvent.setCancelled(true);
                if (game2.getState() == GameState.IN_GAME && !this.main.getManager().sameTeam(game2, player, player2) && player2.getInventory().getHeldItemSlot() == 2 && player2.getItemInHand() != null && this.main.getUpdateTask().getDelay().get((Object)player.getUniqueId()) == null && !game2.getSpectators().contains((Object)player)) {
                    if (this.main.enableBlood()) {
                        player.getWorld().playEffect(player.getLocation(), Effect.STEP_SOUND, (Object)Material.REDSTONE_WIRE);
                    }
                    Vector vector = player2.getEyeLocation().toVector().subtract(player.getEyeLocation().toVector());
                    Vector vector2 = player.getEyeLocation().getDirection().normalize();
                    float f = vector.angle(vector2);
                    if (player2.getLocation().distance(player.getLocation()) <= 1.7 || (double)f <= 1.5) {
                        this.main.getManager().damage(game2, player2, player, 3.0, "\u928c");
                    } else {
                        this.main.getManager().damage(game2, player2, player, 20.0, "\u928c");
                    }
                    this.main.getUpdateTask().getDelay().put((Object)player.getUniqueId(), (Object)35);
                }
            }
        } else if (entityDamageByEntityEvent.getDamager().getType() == EntityType.PLAYER && entityDamageByEntityEvent.getEntity().getType() == EntityType.ITEM_FRAME && (game = this.main.getManager().getGame((Player)entityDamageByEntityEvent.getDamager())) != null) {
            entityDamageByEntityEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onBombPlant(PlayerItemConsumeEvent playerItemConsumeEvent) {
        Player player = playerItemConsumeEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            Block block;
            playerItemConsumeEvent.setCancelled(true);
            if (player.getInventory().getItemInHand().getType() == Material.GOLDEN_APPLE && game.getState() == GameState.IN_GAME && !game.isRoundEnding() && player.getLocation().getBlock().getRelative(BlockFace.DOWN).getType().isSolid() && (block = player.getLocation().getBlock()).getType() == Material.AIR) {
                player.getInventory().setItem(5, new ItemStack(Material.AIR));
                block.setType(Material.DAYLIGHT_DETECTOR);
                game.getBomb().setLocation(block.getLocation());
                game.getBomb().setTimer(this.main.getBombTime());
                game.setGameTimer(this.main.getBombTime());
                game.getBomb().isPlanted(true);
                game.setMoney(player, game.getMoney(player) + this.main.getBombPlantMoney());
                ((PlayerStatus)game.getStats().get((Object)player.getUniqueId())).addBombPlanted();
                for (Player player2 : this.main.getManager().getTeam(game, GameTeam.Role.TERRORIST).getPlayers()) {
                    player2.setCompassTarget(player.getLocation().getBlock().getLocation());
                    player2.playSound(player2.getLocation(), "cs.gamesounds.bombplanted", 1.0f, 1.0f);
                    this.main.getVersionInterface().sendTitle(player2, 0, 23, 0, "", Messages.BOMB_PLANTED.toString());
                }
                for (Player player2 : this.main.getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                    player2.playSound(player2.getLocation(), "cs.gamesounds.bombplanted", 1.0f, 1.0f);
                    this.main.getVersionInterface().sendTitle(player2, 0, 23, 0, "", Messages.BOMB_PLANTED.toString());
                }
            }
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent asyncPlayerChatEvent) {
        Player player = asyncPlayerChatEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game == null) {
            for (Game game2 : this.main.getManager().getGames()) {
                asyncPlayerChatEvent.getRecipients().removeAll((Collection)game2.getTeamA().getPlayers());
                asyncPlayerChatEvent.getRecipients().removeAll((Collection)game2.getTeamB().getPlayers());
            }
        } else {
            asyncPlayerChatEvent.getRecipients().clear();
            if (game.getState() == GameState.WAITING || game.getState() == GameState.END) {
                asyncPlayerChatEvent.getRecipients().addAll((Collection)game.getTeamA().getPlayers());
                asyncPlayerChatEvent.getRecipients().addAll((Collection)game.getTeamB().getPlayers());
                asyncPlayerChatEvent.setFormat(Messages.CHAT_WAITING_FORMAT.toString().replace((CharSequence)"%player%", (CharSequence)player.getName()).replace((CharSequence)"%message%", (CharSequence)"%2$s"));
            } else if (asyncPlayerChatEvent.getMessage().startsWith("@") && asyncPlayerChatEvent.getMessage().length() > 1) {
                asyncPlayerChatEvent.getRecipients().addAll((Collection)game.getTeamA().getPlayers());
                asyncPlayerChatEvent.getRecipients().addAll((Collection)game.getTeamB().getPlayers());
                asyncPlayerChatEvent.setMessage(asyncPlayerChatEvent.getMessage().substring(1));
                asyncPlayerChatEvent.setFormat(Messages.CHAT_GLOBAL_FORMAT.toString().replace((CharSequence)"%player%", (CharSequence)player.getName()).replace((CharSequence)"%message%", (CharSequence)"%2$s"));
            } else if (this.main.getManager().getTeam(game, player) == GameTeam.Role.COUNTERTERRORIST) {
                GameTeam gameTeam = this.main.getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST);
                asyncPlayerChatEvent.getRecipients().addAll((Collection)gameTeam.getPlayers());
                asyncPlayerChatEvent.setFormat(Messages.CHAT_PLAYING_FORMAT.toString().replace((CharSequence)"%team%", (CharSequence)"\u00a73\u9290").replace((CharSequence)"%player%", (CharSequence)player.getName()).replace((CharSequence)"%message%", (CharSequence)"%2$s"));
            } else {
                GameTeam gameTeam = this.main.getManager().getTeam(game, GameTeam.Role.TERRORIST);
                asyncPlayerChatEvent.getRecipients().addAll((Collection)gameTeam.getPlayers());
                asyncPlayerChatEvent.setFormat(Messages.CHAT_PLAYING_FORMAT.toString().replace((CharSequence)"%team%", (CharSequence)"\u00a74\u9291").replace((CharSequence)"%player%", (CharSequence)player.getName()).replace((CharSequence)"%message%", (CharSequence)"%2$s"));
            }
        }
    }

    @EventHandler
    public void onSlotChange(PlayerItemHeldEvent playerItemHeldEvent) {
        Player player = playerItemHeldEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null && game.getState() != GameState.WAITING) {
            Gun gun;
            Gun gun2 = this.main.getGun(player.getInventory().getItem(playerItemHeldEvent.getPreviousSlot()));
            if (gun2 != null) {
                gun2.resetPlayer(player);
                if (gun2.getModule() == 2) {
                    player.setExp(0.0f);
                } else {
                    player.getInventory().getItem(playerItemHeldEvent.getPreviousSlot()).setDurability((short)0);
                }
            }
            if ((gun = this.main.getGun(player.getInventory().getItemInHand())) != null && gun.hasSnipe() && player.isSneaking()) {
                playerItemHeldEvent.setCancelled(true);
            }
            if (!playerItemHeldEvent.isCancelled()) {
                if (playerItemHeldEvent.getNewSlot() == 2) {
                    player.setWalkSpeed(0.25f);
                } else {
                    player.setWalkSpeed(0.2f);
                }
            }
        }
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent playerTeleportEvent) {
        Player player = playerTeleportEvent.getPlayer();
        if (this.main.getManager().getGame(player) != null && playerTeleportEvent.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE) {
            playerTeleportEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerInteractAtEntity(PlayerInteractAtEntityEvent playerInteractAtEntityEvent) {
        Player player = playerInteractAtEntityEvent.getPlayer();
        if (this.main.getManager().getGame(player) == null) {
            return;
        }
        if (playerInteractAtEntityEvent.getRightClicked().getType() == EntityType.ARMOR_STAND) {
            playerInteractAtEntityEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent inventoryClickEvent) {
        Player player = (Player)inventoryClickEvent.getWhoClicked();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            inventoryClickEvent.setCancelled(true);
            if (inventoryClickEvent.getSlotType() != InventoryType.SlotType.OUTSIDE) {
                if (inventoryClickEvent.getClickedInventory().equals((Object)this.selector)) {
                    if (inventoryClickEvent.getSlot() == 11) {
                        game.addTeamA(player);
                        player.playSound(player.getLocation(), SpigotSound.NOTE_STICKS.getSound(), 1.0f, 1.0f);
                        player.sendMessage(Messages.SELECTOR_CHOOSE_TEAM_A.toString());
                        player.closeInventory();
                    } else if (inventoryClickEvent.getSlot() == 13) {
                        game.addRandomTeam(player);
                        player.playSound(player.getLocation(), SpigotSound.NOTE_STICKS.getSound(), 1.0f, 1.0f);
                        player.sendMessage(Messages.SELECTOR_CHOOSE_TEAM_RANDOM.toString());
                        player.closeInventory();
                    } else if (inventoryClickEvent.getSlot() == 15) {
                        game.addTeamB(player);
                        player.playSound(player.getLocation(), SpigotSound.NOTE_STICKS.getSound(), 1.0f, 1.0f);
                        player.sendMessage(Messages.SELECTOR_CHOOSE_TEAM_B.toString());
                        player.closeInventory();
                    }
                }
                if (game.getState() != GameState.WAITING && inventoryClickEvent.getClickedInventory().getType() == InventoryType.CHEST && !inventoryClickEvent.getClickedInventory().equals((Object)player.getInventory())) {
                    for (PlayerShop playerShop : this.main.getShops()) {
                        if (inventoryClickEvent.getSlot() != playerShop.getSlot() || playerShop.getRole() != null && this.main.getManager().getTeam(game, player) != playerShop.getRole()) continue;
                        if (playerShop.getType() == ShopType.ITEMS && playerShop.hasPermission() && !player.hasPermission("cs.weapon." + playerShop.getItName())) {
                            player.closeInventory();
                            player.sendMessage(Messages.SHOP_ITEM_NO_PERMISSION.toString());
                            player.playSound(player.getLocation(), "cs.shop.shopcantbuy", 1.0f, 1.0f);
                            break;
                        }
                        if (playerShop.getType() != ShopType.ITEMS && playerShop.hasPermission() && !player.hasPermission("cs.weapon." + playerShop.getWeaponName())) {
                            player.closeInventory();
                            player.sendMessage(Messages.SHOP_NO_PERMISSION.toString());
                            player.playSound(player.getLocation(), "cs.shop.shopcantbuy", 1.0f, 1.0f);
                            break;
                        }
                        if (playerShop.getPrice() <= game.getMoney(player)) {
                            if (playerShop.getType() == ShopType.GRENADE) {
                                Grenade grenade = this.main.getGrenade(playerShop.getWeaponName());
                                if (player.getInventory().getItem(grenade.getGrenadeType().getSlot()) == null) {
                                    game.setMoney(player, game.getMoney(player) - playerShop.getPrice());
                                    player.getInventory().setItem(grenade.getGrenadeType().getSlot(), ItemBuilder.create((Material)grenade.getItem().getType(), (int)1, (int)grenade.getItem().getData(), (String)(grenade.getItem().getName() + " &7" + grenade.getSymbol())));
                                    player.playSound(player.getLocation(), "cs.shop.shopbuyitem", 1.0f, 1.0f);
                                    break;
                                }
                                player.closeInventory();
                                player.sendMessage(Messages.SHOP_GRENADE_ALREADY_IN_SLOT.toString());
                                player.playSound(player.getLocation(), "cs.shop.shopcantbuy", 1.0f, 1.0f);
                                break;
                            }
                            if (playerShop.getType() == ShopType.GUN) {
                                Gun gun = this.main.getGun(playerShop.getWeaponName());
                                if (player.getInventory().getItem(gun.getGunType().getID().intValue()) == null || this.main.replaceOldGuns()) {
                                    game.setMoney(player, game.getMoney(player) - playerShop.getPrice());
                                    player.getInventory().setItem(gun.getGunType().getID().intValue(), ItemBuilder.create((Material)gun.getItem().getType(), (int)gun.getAmount(), (int)gun.getItem().getData(), (String)(gun.getItem().getName() + " &7" + gun.getSymbol())));
                                    player.playSound(player.getLocation(), "cs.shop.shopbuyitem", 1.0f, 1.0f);
                                    break;
                                }
                                player.closeInventory();
                                player.sendMessage(Messages.SHOP_GUN_ALREADY_IN_SLOT.toString());
                                player.playSound(player.getLocation(), "cs.shop.shopcantbuy", 1.0f, 1.0f);
                                break;
                            }
                            if (playerShop.getRole() != null && this.main.getManager().getTeam(game, player) != playerShop.getRole()) break;
                            if (playerShop.getMaterial() != Material.SHEARS) {
                                ItemStack itemStack = player.getInventory().getItem(playerShop.getSlotPlace());
                                if (playerShop.getSlotPlace() == 2 || itemStack == null || itemStack.getType() == Material.LEATHER_HELMET || itemStack.getType() == Material.LEATHER_CHESTPLATE) {
                                    game.setMoney(player, game.getMoney(player) - playerShop.getPrice());
                                    player.getInventory().setItem(playerShop.getSlotPlace(), ItemBuilder.create((Material)playerShop.getMaterial(), (int)1, (String)playerShop.getName(), (boolean)false));
                                    player.playSound(player.getLocation(), "cs.shop.shopbuyitem", 1.0f, 1.0f);
                                    break;
                                }
                                player.closeInventory();
                                player.sendMessage(Messages.SHOP_ALREADY_BROUGHT.toString());
                                player.playSound(player.getLocation(), "cs.shop.shopcantbuy", 1.0f, 1.0f);
                                break;
                            }
                            if (player.getInventory().getItem(playerShop.getSlotPlace()).getType() != Material.SHEARS) {
                                game.setMoney(player, game.getMoney(player) - playerShop.getPrice());
                                player.getInventory().setItem(playerShop.getSlotPlace(), ItemBuilder.create((Material)playerShop.getMaterial(), (int)1, (String)playerShop.getName(), (boolean)false));
                                player.playSound(player.getLocation(), "cs.shop.shopbuyitem", 1.0f, 1.0f);
                                break;
                            }
                            player.closeInventory();
                            player.sendMessage(Messages.SHOP_ALREADY_BROUGHT.toString());
                            player.playSound(player.getLocation(), "cs.shop.shopcantbuy", 1.0f, 1.0f);
                            break;
                        }
                        player.closeInventory();
                        player.sendMessage(Messages.SHOP_NOT_ENOUGH_MONEY.toString());
                        player.playSound(player.getLocation(), "cs.shop.shopcantbuy", 1.0f, 1.0f);
                        break;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerCommand(PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        Player player = playerCommandPreprocessEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            String[] stringArray = playerCommandPreprocessEvent.getMessage().split(" ");
            String string = stringArray[0];
            if (string.equalsIgnoreCase("/leave") || string.equalsIgnoreCase("/quit")) {
                playerCommandPreprocessEvent.setCancelled(true);
                player.sendMessage(Messages.PREFIX + Messages.GAME_LEFT.toString());
                this.main.getManager().removePlayer(game, player, false, false);
            } else if (!(string.equalsIgnoreCase("/cs") || string.equalsIgnoreCase("/counterstrike") || GameUtils.containsIgnoreCase((List)this.main.getWhitelistCommands(), (String)string))) {
                playerCommandPreprocessEvent.setCancelled(true);
                player.sendMessage(Messages.PREFIX + " " + Messages.RESTRICTED_COMMAND.toString());
            }
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent blockPlaceEvent) {
        Player player = blockPlaceEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            blockPlaceEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent blockBreakEvent) {
        Player player = blockBreakEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            blockBreakEvent.setCancelled(true);
        } else if (blockBreakEvent.getBlock().getState() instanceof Sign && player.hasPermission("cs.sign")) {
            Location location;
            Object object;
            Location location2 = blockBreakEvent.getBlock().getLocation();
            for (Game game2 : this.main.getManager().getGames()) {
                object = game2.getSigns().iterator();
                while (object.hasNext()) {
                    location = (Location)object.next();
                    if (location2.getWorld() != location.getWorld() || location2.distance(location) != 0.0) continue;
                    player.sendMessage(Messages.PREFIX + " \u00a7cSign removed succefully!");
                    String string = game2.getID() + "," + location2.getWorld().getName() + "," + location2.getBlockX() + "," + location2.getBlockY() + "," + location2.getBlockZ();
                    List list = this.main.getGameDatabase().getStringList("Signs");
                    list.remove((Object)string);
                    this.main.getGameDatabase().set("Signs", (Object)list);
                    this.main.saveGameDatabase();
                    object.remove();
                    return;
                }
            }
            Iterator iterator = this.main.getManager().getQuickJoinSigns().iterator();
            while (iterator.hasNext()) {
                Game game2;
                game2 = (Location)iterator.next();
                if (!location2.equals((Object)game2)) continue;
                player.sendMessage(Messages.PREFIX + " \u00a7cQuick-Sign removed succefully!");
                object = location2.getWorld().getName() + "," + location2.getBlockX() + "," + location2.getBlockY() + "," + location2.getBlockZ();
                location = this.main.getGameDatabase().getStringList("QuickJoinSigns");
                location.remove(object);
                this.main.getGameDatabase().set("QuickJoinSigns", (Object)location);
                this.main.saveGameDatabase();
                iterator.remove();
            }
        }
    }

    @EventHandler
    public void onPing(ServerListPingEvent serverListPingEvent) {
        if (this.main.getManager().isBungeeMode()) {
            Game game = (Game)this.main.getManager().getGames().get(this.main.getManager().getMap());
            serverListPingEvent.setMotd(game.getState().getState());
            serverListPingEvent.setMaxPlayers(game.getMaxPlayers());
        }
    }

    @EventHandler
    public void onLogin(PlayerLoginEvent playerLoginEvent) {
        if (this.main.getManager().isBungeeMode()) {
            Game game = (Game)this.main.getManager().getGames().get(this.main.getManager().getMap());
            if (game.getTeamA().size() + game.getTeamB().size() == game.getMaxPlayers()) {
                playerLoginEvent.disallow(PlayerLoginEvent.Result.KICK_FULL, Messages.ARENA_IS_FULL.toString());
            } else if (game.getState() != GameState.WAITING && !this.main.canJoinStartedGame()) {
                playerLoginEvent.disallow(PlayerLoginEvent.Result.KICK_OTHER, Messages.ARENA_HAS_STARTED.toString());
            }
        }
    }

    @EventHandler
    public void onLeave(GameLeaveEvent gameLeaveEvent) {
        if (this.main.getManager().isBungeeMode()) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream((OutputStream)byteArrayOutputStream);
            try {
                dataOutputStream.writeUTF("Connect");
                dataOutputStream.writeUTF(this.main.getHub());
                gameLeaveEvent.getPlayer().sendPluginMessage((Plugin)this.main, "BungeeCord", byteArrayOutputStream.toByteArray());
                dataOutputStream.close();
                byteArrayOutputStream.close();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent playerJoinEvent) {
        GameManager gameManager = this.main.getManager();
        if (gameManager.isBungeeMode()) {
            Player player = playerJoinEvent.getPlayer();
            playerJoinEvent.setJoinMessage(null);
            Game game = (Game)gameManager.getGames().get(gameManager.getMap());
            if (game.getState() != GameState.WAITING) {
                gameManager.addQuickPlayer(game, player);
            } else {
                gameManager.addPlayer(player, game);
            }
        } else {
            for (Game game : gameManager.getGames()) {
                for (Player player : game.getTeamA().getPlayers()) {
                    player.hidePlayer(playerJoinEvent.getPlayer());
                }
                for (Player player : game.getTeamB().getPlayers()) {
                    player.hidePlayer(playerJoinEvent.getPlayer());
                }
            }
        }
        this.main.getVersionInterface().setHandSpeed(playerJoinEvent.getPlayer(), 4.0);
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onLeave(PlayerQuitEvent playerQuitEvent) {
        Player player = playerQuitEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            this.main.getManager().removePlayer(game, player, false, true);
        }
        if (this.main.getManager().isBungeeMode()) {
            playerQuitEvent.setQuitMessage("");
        }
        this.main.getTextureUsers().remove((Object)player.getUniqueId());
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPluginEnable(PluginEnableEvent pluginEnableEvent) {
        if (pluginEnableEvent.getPlugin().equals((Object)this.main)) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                this.main.getTextureUsers().add((Object)player.getUniqueId());
            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent playerMoveEvent) {
        Player player = playerMoveEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            if (game.getState() == GameState.IN_GAME) {
                ItemStack itemStack;
                if (player.getFallDistance() >= 6.0f && !game.getSpectators().contains((Object)player) && player.getLocation().getBlock().getRelative(BlockFace.DOWN).getType().isSolid()) {
                    this.main.getManager().damage(game, null, player, (double)player.getFallDistance(), "\u9271\u9272");
                }
                if ((playerMoveEvent.getFrom().getBlockX() != playerMoveEvent.getTo().getBlockX() || playerMoveEvent.getFrom().getBlockZ() != playerMoveEvent.getTo().getBlockZ()) && game.getBomb().getCarrier() == player && (itemStack = player.getInventory().getItem(5)) != null) {
                    if (this.main.getManager().isInBombArea(game, playerMoveEvent.getTo())) {
                        if (itemStack.getType() == Material.QUARTZ) {
                            ItemMeta itemMeta = itemStack.getItemMeta();
                            itemMeta.setDisplayName("\u00a7e\u9276\u00a7a " + Messages.ITEM_BOMB_NAME + " \u00a78(\u00a7c" + Messages.ITEM_RIGHT_CLICK + "\u00a78)");
                            itemStack.setItemMeta(itemMeta);
                            itemStack.setType(Material.GOLDEN_APPLE);
                            player.playSound(player.getLocation(), SpigotSound.CLICK.getSound(), 1.0f, 1.0f);
                        }
                    } else if (itemStack.getType() == Material.GOLDEN_APPLE) {
                        ItemMeta itemMeta = itemStack.getItemMeta();
                        itemMeta.setDisplayName("\u00a7e\u9276\u00a7a " + Messages.ITEM_BOMB_NAME);
                        itemStack.setItemMeta(itemMeta);
                        itemStack.setType(Material.QUARTZ);
                        player.playSound(player.getLocation(), SpigotSound.CLICK.getSound(), 1.0f, 1.0f);
                    }
                }
            } else if (!(game.getState() != GameState.ROUND || game.getSpectators().contains((Object)player) || playerMoveEvent.getFrom().getX() == playerMoveEvent.getTo().getX() && playerMoveEvent.getFrom().getZ() == playerMoveEvent.getTo().getZ())) {
                playerMoveEvent.setTo(playerMoveEvent.getFrom());
            }
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent entityDamageEvent) {
        if (entityDamageEvent.getEntity() instanceof Player && this.main.getManager().getGame((Player)entityDamageEvent.getEntity()) != null && entityDamageEvent.getCause() != EntityDamageEvent.DamageCause.CUSTOM) {
            entityDamageEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onFoodChange(FoodLevelChangeEvent foodLevelChangeEvent) {
        if (foodLevelChangeEvent.getEntity() instanceof Player && this.main.getManager().getGame((Player)foodLevelChangeEvent.getEntity()) != null) {
            foodLevelChangeEvent.setFoodLevel(20);
        }
    }

    @EventHandler
    public void onHealthRegain(EntityRegainHealthEvent entityRegainHealthEvent) {
        if (entityRegainHealthEvent.getEntity() instanceof Player && this.main.getManager().getGame((Player)entityRegainHealthEvent.getEntity()) != null) {
            entityRegainHealthEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntityBreak(HangingBreakByEntityEvent hangingBreakByEntityEvent) {
        if (hangingBreakByEntityEvent.getRemover().getType() == EntityType.PLAYER) {
            Player player = (Player)hangingBreakByEntityEvent.getRemover();
            Game game = this.main.getManager().getGame(player);
            if (game != null) {
                hangingBreakByEntityEvent.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onEntityBreak(HangingBreakEvent hangingBreakEvent) {
        if (hangingBreakEvent.getCause() != HangingBreakEvent.RemoveCause.ENTITY) {
            hangingBreakEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onPick(PlayerPickupItemEvent playerPickupItemEvent) {
        Player player = playerPickupItemEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            playerPickupItemEvent.setCancelled(true);
            if (!(game.getSpectators().contains((Object)player) || game.getState() != GameState.IN_GAME && game.getState() != GameState.ROUND)) {
                Item item = playerPickupItemEvent.getItem();
                ItemStack itemStack = playerPickupItemEvent.getItem().getItemStack();
                if (itemStack.getType() == Material.SHEARS && this.main.getManager().getTeam(game, player) == GameTeam.Role.COUNTERTERRORIST) {
                    item.remove();
                    game.getDrops().remove((Object)item);
                    player.getInventory().setItem(5, itemStack);
                    player.playSound(player.getLocation(), SpigotSound.ITEM_PICKUP.getSound(), 5.0f, 1.0f);
                } else {
                    if ((itemStack.getType() == Material.QUARTZ || itemStack.getType() == Material.GOLDEN_APPLE) && this.main.getManager().getTeam(game, player) == GameTeam.Role.TERRORIST) {
                        ItemMeta itemMeta;
                        item.remove();
                        game.getDrops().remove((Object)item);
                        if (itemStack.getType() == Material.QUARTZ && this.main.getManager().isInBombArea(game, item.getLocation())) {
                            itemMeta = itemStack.getItemMeta();
                            itemMeta.setDisplayName("\u00a7e\u9276\u00a7a " + Messages.ITEM_BOMB_NAME + " \u00a78(\u00a7c" + Messages.ITEM_RIGHT_CLICK + "\u00a78)");
                            itemStack.setItemMeta(itemMeta);
                            itemStack.setType(Material.GOLDEN_APPLE);
                        }
                        if (itemStack.getType() == Material.GOLDEN_APPLE && !this.main.getManager().isInBombArea(game, item.getLocation())) {
                            itemMeta = itemStack.getItemMeta();
                            itemMeta.setDisplayName("\u00a7e\u9276\u00a7a " + Messages.ITEM_BOMB_NAME);
                            itemStack.setItemMeta(itemMeta);
                            itemStack.setType(Material.QUARTZ);
                        }
                        for (Player player2 : this.main.getManager().getTeam(game, GameTeam.Role.TERRORIST).getPlayers()) {
                            player2.playSound(player2.getLocation(), "cs.gamesounds.pickedupthebomb", 1.0f, 1.0f);
                        }
                        game.getBomb().setCarrier(player);
                        player.getInventory().setItem(5, itemStack);
                        return;
                    }
                    Grenade grenade = this.main.getGrenade(itemStack);
                    if (grenade != null && game.getDrops().get((Object)item) != null) {
                        int n = grenade.getGrenadeType().getSlot();
                        if (player.getInventory().getItem(n) == null) {
                            playerPickupItemEvent.setCancelled(true);
                            player.getInventory().setItem(n, itemStack);
                            game.getDrops().remove((Object)item);
                            item.remove();
                            player.playSound(player.getLocation(), SpigotSound.ITEM_PICKUP.getSound(), 5.0f, 1.0f);
                        }
                    }
                    Gun gun = this.main.getGun(itemStack);
                    Integer n = (Integer)game.getDrops().get((Object)item);
                    if (gun != null && n != null) {
                        int n2 = gun.getGunType().getID();
                        if (player.getInventory().getItem(n2) == null) {
                            playerPickupItemEvent.setCancelled(true);
                            itemStack.setAmount(n + 1);
                            player.getInventory().setItem(n2, itemStack);
                            game.getDrops().remove((Object)item);
                            item.remove();
                            player.playSound(player.getLocation(), SpigotSound.ITEM_PICKUP.getSound(), 5.0f, 1.0f);
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent playerDropItemEvent) {
        Player player = playerDropItemEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null) {
            ItemStack itemStack;
            int n = player.getInventory().getHeldItemSlot();
            ItemStack itemStack2 = playerDropItemEvent.getItemDrop().getItemStack();
            int n2 = player.getInventory().getItemInHand().getAmount();
            if (game.getState() == GameState.IN_GAME || game.getState() == GameState.ROUND) {
                if (itemStack2.getType() == Material.SHEARS) {
                    game.getDrops().put((Object)playerDropItemEvent.getItemDrop(), (Object)1);
                    player.getInventory().setItem(5, ItemBuilder.create((Material)Material.GOLD_NUGGET, (int)1, (String)("&a" + Messages.ITEM_SHEAR_NAME + " &7\u927b"), (boolean)false));
                    return;
                }
                if (itemStack2.getType() == Material.QUARTZ || itemStack2.getType() == Material.GOLDEN_APPLE) {
                    if (itemStack2.getType() == Material.GOLDEN_APPLE) {
                        ItemMeta itemMeta = itemStack2.getItemMeta();
                        itemMeta.setDisplayName("\u00a7e\u9276\u00a7a " + Messages.ITEM_BOMB_NAME);
                        itemStack2.setItemMeta(itemMeta);
                        itemStack2.setType(Material.QUARTZ);
                    }
                    game.getDrops().put((Object)playerDropItemEvent.getItemDrop(), (Object)1);
                    game.getBomb().setDrop(playerDropItemEvent.getItemDrop());
                    for (Player player2 : this.main.getManager().getTeam(game, GameTeam.Role.TERRORIST).getPlayers()) {
                        player2.playSound(player2.getLocation(), "cs.gamesounds.bombdroppedyourteam", 1.0f, 1.0f);
                    }
                    for (Player player2 : this.main.getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                        player2.playSound(player2.getLocation(), "cs.gamesounds.bombdroppedenemyteam", 1.0f, 1.0f);
                    }
                    return;
                }
                itemStack = this.main.getGun(itemStack2);
                if (itemStack != null) {
                    game.getDrops().put((Object)playerDropItemEvent.getItemDrop(), (Object)n2);
                    itemStack2.setAmount(1);
                    player.setExp(0.0f);
                    itemStack.resetDelay(player);
                    playerDropItemEvent.getItemDrop().setItemStack(ItemBuilder.create((Material)itemStack2.getType(), (int)1, (int)itemStack.getItem().getData(), (String)itemStack2.getItemMeta().getDisplayName()));
                    player.getInventory().setItem(n, null);
                    player.playSound(player.getLocation(), "cs.gamesounds.droppedagun", 1.0f, 1.0f);
                    if (itemStack.hasSnipe()) {
                        this.main.getVersionInterface().sendFakeItem(player, 5, player.getInventory().getHelmet());
                    }
                    return;
                }
                Grenade grenade = this.main.getGrenade(itemStack2);
                if (grenade != null) {
                    game.getDrops().put((Object)playerDropItemEvent.getItemDrop(), (Object)1);
                    itemStack2.setAmount(1);
                    playerDropItemEvent.getItemDrop().setItemStack(ItemBuilder.create((Material)itemStack2.getType(), (int)1, (int)grenade.getItem().getData(), (String)itemStack2.getItemMeta().getDisplayName()));
                    player.getInventory().setItem(n, null);
                    player.playSound(player.getLocation(), "cs.gamesounds.droppedagun", 1.0f, 1.0f);
                    return;
                }
            }
            itemStack = itemStack2.clone();
            playerDropItemEvent.getItemDrop().remove();
            player.getInventory().setItem(player.getInventory().getHeldItemSlot(), itemStack);
        }
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent playerToggleSneakEvent) {
        ItemStack itemStack;
        Gun gun;
        Player player = playerToggleSneakEvent.getPlayer();
        Game game = this.main.getManager().getGame(player);
        if (game != null && (gun = this.main.getGun(itemStack = player.getInventory().getItemInHand())) != null && gun.hasSnipe()) {
            if (playerToggleSneakEvent.isSneaking()) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20, 1));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, Integer.MAX_VALUE, 2));
                this.main.getVersionInterface().sendFakeItem(player, 5, new ItemStack(Material.CARVED_PUMPKIN));
            } else {
                player.removePotionEffect(PotionEffectType.SLOW);
                player.removePotionEffect(PotionEffectType.BLINDNESS);
                this.main.getVersionInterface().sendFakeItem(player, 5, player.getInventory().getHelmet());
            }
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onInteract(PlayerInteractAtEntityEvent playerInteractAtEntityEvent) {
        Player player = playerInteractAtEntityEvent.getPlayer();
        ItemStack itemStack = player.getInventory().getItemInHand();
        Game game = this.main.getManager().getGame(player);
        if (game != null && itemStack != null && itemStack.getType() != Material.AIR) {
            Gun gun;
            playerInteractAtEntityEvent.setCancelled(true);
            if ((itemStack.getType() == Material.SHEARS || itemStack.getType() == Material.GOLD_NUGGET) && playerInteractAtEntityEvent.getRightClicked().getType() == EntityType.valueOf((String)"ARMOR_STAND") && this.main.getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayers().contains((Object)player) && !game.isDefusing(player) && player.getLocation().distance(game.getBomb().getLocation()) <= 2.0) {
                game.addDefuser(player, itemStack.getType() == Material.SHEARS ? 5 : 10);
                player.playSound(player.getLocation(), SpigotSound.LEVEL_UP.getSound(), 1.0f, 1.0f);
            }
            if ((gun = this.main.getGun(itemStack)) != null && !game.isDefusing(player) && game.getState() == GameState.IN_GAME) {
                gun.shot(game, player);
            }
        }
    }

    @EventHandler
    public void onPsyhics(BlockPhysicsEvent blockPhysicsEvent) {
        if (blockPhysicsEvent.getBlock().getType() == Material.WHEAT) {
            blockPhysicsEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onInteract(PlayerSwapHandItemsEvent playerSwapHandItemsEvent) {
        Player player = playerSwapHandItemsEvent.getPlayer();
        if (this.main.getManager().getGame(player) != null) {
            playerSwapHandItemsEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onResourcePack(PlayerResourcePackStatusEvent playerResourcePackStatusEvent) {
        if (this.main.canForceTexture()) {
            Player player = playerResourcePackStatusEvent.getPlayer();
            if (playerResourcePackStatusEvent.getStatus() == PlayerResourcePackStatusEvent.Status.DECLINED) {
                player.sendMessage(Messages.TEXTURE_DECLINED.toString());
                if (this.main.getManager().isBungeeMode()) {
                    this.main.getServer().getPluginManager().callEvent((Event)new GameLeaveEvent(player));
                }
            }
            if (playerResourcePackStatusEvent.getStatus() == PlayerResourcePackStatusEvent.Status.ACCEPTED) {
                player.sendMessage(Messages.TEXTURE_ACCEPTED.toString());
            }
            if (playerResourcePackStatusEvent.getStatus() == PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD) {
                player.sendMessage(Messages.TEXTURE_FAILED.toString());
                if (this.main.getManager().isBungeeMode()) {
                    this.main.getServer().getPluginManager().callEvent((Event)new GameLeaveEvent(player));
                }
            }
            if (playerResourcePackStatusEvent.getStatus() == PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED) {
                player.sendMessage(Messages.TEXTURE_LOADED.toString());
                this.main.getTextureUsers().add((Object)player.getUniqueId());
            }
        }
    }

    @EventHandler
    public void onSignPlace(SignChangeEvent signChangeEvent) {
        Player player = signChangeEvent.getPlayer();
        if (signChangeEvent.getLine(0).equals((Object)"[CounterStrike]") && player.hasPermission("cs.sign")) {
            try {
                int n = Integer.valueOf((String)signChangeEvent.getLine(1));
                Game game = this.main.getManager().getGame(n);
                if (game != null) {
                    Location location = signChangeEvent.getBlock().getLocation();
                    game.getSigns().add((Object)location);
                    signChangeEvent.setLine(0, Messages.SIGN_FIRST.toString().replace((CharSequence)"%prefix%", (CharSequence)Messages.PREFIX.toString()).replace((CharSequence)"%name%", (CharSequence)game.getName()).replace((CharSequence)"%state%", (CharSequence)game.getState().getState()).replace((CharSequence)"%min%", (CharSequence)(game.getTeamA().size() + game.getTeamB().size() + "")).replace((CharSequence)"%max%", (CharSequence)(game.getMaxPlayers() + "")));
                    signChangeEvent.setLine(1, Messages.SIGN_SECOND.toString().replace((CharSequence)"%prefix%", (CharSequence)Messages.PREFIX.toString()).replace((CharSequence)"%name%", (CharSequence)game.getName()).replace((CharSequence)"%state%", (CharSequence)game.getState().getState()).replace((CharSequence)"%min%", (CharSequence)(game.getTeamA().size() + game.getTeamB().size() + "")).replace((CharSequence)"%max%", (CharSequence)(game.getMaxPlayers() + "")));
                    signChangeEvent.setLine(2, Messages.SIGN_THIRD.toString().replace((CharSequence)"%prefix%", (CharSequence)Messages.PREFIX.toString()).replace((CharSequence)"%name%", (CharSequence)game.getName()).replace((CharSequence)"%state%", (CharSequence)game.getState().getState()).replace((CharSequence)"%min%", (CharSequence)(game.getTeamA().size() + game.getTeamB().size() + "")).replace((CharSequence)"%max%", (CharSequence)(game.getMaxPlayers() + "")));
                    signChangeEvent.setLine(3, Messages.SIGN_FOURTH.toString().replace((CharSequence)"%prefix%", (CharSequence)Messages.PREFIX.toString()).replace((CharSequence)"%name%", (CharSequence)game.getName()).replace((CharSequence)"%state%", (CharSequence)game.getState().getState()).replace((CharSequence)"%min%", (CharSequence)(game.getTeamA().size() + game.getTeamB().size() + "")).replace((CharSequence)"%max%", (CharSequence)(game.getMaxPlayers() + "")));
                    List list = this.main.getGameDatabase().getStringList("Signs");
                    list.add((Object)(n + "," + location.getWorld().getName() + "," + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ()));
                    this.main.getGameDatabase().set("Signs", (Object)list);
                    this.main.saveGameDatabase();
                    player.sendMessage(Messages.PREFIX + " \u00a7aSign created succefully!");
                } else {
                    signChangeEvent.setCancelled(true);
                    player.sendMessage(Messages.PREFIX + " \u00a7cThe game dosen't exist!");
                }
            }
            catch (Exception exception) {
                String string = signChangeEvent.getLine(1);
                if (string != null && string.equalsIgnoreCase("QuickJoin")) {
                    Location location = signChangeEvent.getBlock().getLocation();
                    signChangeEvent.setLine(0, Messages.PREFIX.toString());
                    signChangeEvent.setLine(1, "\u00a75\u2022 \u00a70" + Messages.SIGN_QUICKJOIN.toString() + " \u00a75\u2022");
                    String string2 = location.getWorld().getName() + "," + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ();
                    List list = this.main.getGameDatabase().getStringList("QuickJoinSigns");
                    list.add((Object)string2);
                    this.main.getGameDatabase().set("QuickJoinSigns", (Object)list);
                    this.main.saveGameDatabase();
                    this.main.getManager().getQuickJoinSigns().add((Object)location);
                    player.sendMessage(Messages.PREFIX + " \u00a7aQuick-Sign created succefully!");
                } else {
                    player.sendMessage(Messages.PREFIX + " \u00a7cGame ID invalid!");
                }
                return;
            }
        }
    }
}
