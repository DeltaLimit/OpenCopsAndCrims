/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.bukkit.entity.Player
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam$Role
 */
package ro.Fr33styler.CounterStrike.Handler;

import java.util.List;
import org.bukkit.entity.Player;
import ro.Fr33styler.CounterStrike.Handler.GameTeam;

/*
 * Exception performing whole class analysis ignored.
 */
public class GameTeam {
    private Role role;
    private List<Player> players = null;

    public GameTeam(List<Player> list) {
        this.players = list;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Role getRole() {
        return this.role;
    }

    public Player getPlayer(int n) {
        return (Player)this.players.get(n);
    }

    public void addPlayer(Player player) {
        this.players.add((Object)player);
    }

    public void removePlayer(Player player) {
        this.players.remove((Object)player);
    }

    public List<Player> getPlayers() {
        return this.players;
    }

    public int size() {
        return this.players.size();
    }

    public static Role getEnum(String string) {
        for (Role role : Role.values()) {
            if (!role.name().equals((Object)string)) continue;
            return role;
        }
        return null;
    }
}
