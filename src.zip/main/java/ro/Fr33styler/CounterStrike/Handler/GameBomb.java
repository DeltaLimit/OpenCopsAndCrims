/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  ro.Fr33styler.CounterStrike.Handler.Game
 */
package ro.Fr33styler.CounterStrike.Handler;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import ro.Fr33styler.CounterStrike.Handler.Game;

public class GameBomb {
    private Item item;
    private int timer;
    private Location l;
    private Player carrier;
    private boolean isPlanted = false;

    public boolean isPlanted() {
        return this.isPlanted;
    }

    public void setDrop(Item item) {
        this.item = item;
        this.carrier = null;
    }

    public void setCarrier(Player player) {
        this.l = null;
        this.carrier = player;
        this.item = null;
    }

    public Player getCarrier() {
        return this.carrier;
    }

    public int getTimer() {
        return this.timer;
    }

    public void setTimer(int n) {
        this.timer = n;
    }

    public void setLocation(Location location) {
        this.l = location;
        this.carrier = null;
        this.item = null;
    }

    public void reset() {
        this.timer = 0;
        if (this.l != null) {
            this.l.getBlock().setType(Material.AIR);
            this.l = null;
        }
        this.item = null;
        this.carrier = null;
        this.isPlanted = false;
    }

    public List<Player> getNearbyPlayers(Game game, int n) {
        ArrayList arrayList = new ArrayList();
        for (Player player : game.getTeamA().getPlayers()) {
            if (!(player.getLocation().distance(this.l) <= (double)n)) continue;
            arrayList.add((Object)player);
        }
        for (Player player : game.getTeamB().getPlayers()) {
            if (!(player.getLocation().distance(this.l) <= (double)n)) continue;
            arrayList.add((Object)player);
        }
        return arrayList;
    }

    public Location getLocation() {
        if (this.l != null) {
            return this.l;
        }
        if (this.carrier != null) {
            return this.carrier.getLocation();
        }
        return this.item.getLocation();
    }

    public void isPlanted(boolean bl) {
        this.isPlanted = bl;
    }
}
