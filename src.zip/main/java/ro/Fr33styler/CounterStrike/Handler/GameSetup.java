/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  org.bukkit.Location
 */
package ro.Fr33styler.CounterStrike.Handler;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;

public class GameSetup {
    private int id;
    private int min;
    private int max;
    private String name;
    private Location lobby;
    private List<Location> cops = new ArrayList();
    private List<Location> bombs = new ArrayList();
    private List<Location> criminals = new ArrayList();
    private List<Location> fireworks = new ArrayList();

    public GameSetup(int n, String string, int n2, int n3) {
        this.setID(n);
        this.setName(string);
        this.setMin(n2);
        this.setMax(n3);
    }

    public Integer getID() {
        return this.id;
    }

    public void setID(Integer n) {
        this.id = n;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String string) {
        this.name = string;
    }

    public List<Location> getCriminals() {
        return this.criminals;
    }

    public List<Location> getCops() {
        return this.cops;
    }

    public Location getLobby() {
        return this.lobby;
    }

    public void setLobby(Location location) {
        this.lobby = location;
    }

    public List<Location> getBombs() {
        return this.bombs;
    }

    public List<Location> getFireworks() {
        return this.fireworks;
    }

    public int getMin() {
        return this.min;
    }

    public void setMin(int n) {
        this.min = n;
    }

    public int getMax() {
        return this.max;
    }

    public void setMax(int n) {
        this.max = n;
    }
}
