/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.UUID
 *  org.bukkit.Bukkit
 *  org.bukkit.Color
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.block.Sign
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  ro.Fr33styler.CounterStrike.Api.GameJoinEvent
 *  ro.Fr33styler.CounterStrike.Api.GameLeaveEvent
 *  ro.Fr33styler.CounterStrike.Cache.PlayerData
 *  ro.Fr33styler.CounterStrike.Cache.PlayerShop
 *  ro.Fr33styler.CounterStrike.Cache.PlayerStatus
 *  ro.Fr33styler.CounterStrike.Cache.ShopType
 *  ro.Fr33styler.CounterStrike.Grenades.Grenade
 *  ro.Fr33styler.CounterStrike.Guns.Gun
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameState
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam$Role
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.Messages
 *  ro.Fr33styler.CounterStrike.MySQL.MySQL
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardStatus
 *  ro.Fr33styler.CounterStrike.Utils.ItemBuilder
 *  ro.Fr33styler.CounterStrike.Version.MathUtils
 *  ro.Fr33styler.CounterStrike.Version.SpigotSound
 */
package ro.Fr33styler.CounterStrike.Handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Sign;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import ro.Fr33styler.CounterStrike.Api.GameJoinEvent;
import ro.Fr33styler.CounterStrike.Api.GameLeaveEvent;
import ro.Fr33styler.CounterStrike.Cache.PlayerData;
import ro.Fr33styler.CounterStrike.Cache.PlayerShop;
import ro.Fr33styler.CounterStrike.Cache.PlayerStatus;
import ro.Fr33styler.CounterStrike.Cache.ShopType;
import ro.Fr33styler.CounterStrike.Grenades.Grenade;
import ro.Fr33styler.CounterStrike.Guns.Gun;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameState;
import ro.Fr33styler.CounterStrike.Handler.GameTeam;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.Messages;
import ro.Fr33styler.CounterStrike.MySQL.MySQL;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardStatus;
import ro.Fr33styler.CounterStrike.Utils.ItemBuilder;
import ro.Fr33styler.CounterStrike.Version.MathUtils;
import ro.Fr33styler.CounterStrike.Version.SpigotSound;

public class GameManager {
    private Main main;
    private Location spawn;
    private boolean bungee;
    private int bungee_map = 0;
    private List<Game> games = new ArrayList();
    private List<Location> quick_join = new ArrayList();
    private HashMap<UUID, PlayerData> data = new HashMap();

    public GameManager(Main main, boolean bl) {
        this.main = main;
        if (bl) {
            this.bungee = bl;
            main.getServer().getMessenger().registerOutgoingPluginChannel((Plugin)main, "BungeeCord");
        }
    }

    public void setSpawn(Location location) {
        this.spawn = location;
    }

    public int getMap() {
        return this.bungee_map;
    }

    public Game findGame(Player player) {
        int n = 0;
        Game game = null;
        for (Game game2 : this.main.getManager().getGames()) {
            int n2 = MathUtils.abs((int)(game2.getTeamA().size() - game2.getTeamB().size()));
            if (game2.getState() != GameState.IN_GAME && game2.getState() != GameState.ROUND || game2.getTeamA().size() + game2.getTeamB().size() >= game2.getMaxPlayers() || game2.getTimer() <= 1 || game2.getTeamA().size() <= 0 || game2.getTeamB().size() <= 0) continue;
            if (game == null) {
                game = game2;
                n = n2;
                continue;
            }
            if (n2 > 1 && n2 > n) {
                game = game2;
                n = n2;
                continue;
            }
            if (n > n2 || game2.getTeamA().size() + game2.getTeamB().size() <= game.getTeamA().size() + game.getTeamB().size()) continue;
            game = game2;
            n = n2;
        }
        if (game == null) {
            int n3 = 0;
            for (Game game3 : this.main.getManager().getGames()) {
                int n4 = game3.getTeamA().size() + game3.getTeamB().size();
                if (game3.getState() != GameState.WAITING || game3.getTeamA().size() + game3.getTeamB().size() >= game3.getMaxPlayers() || game3.getTimer() <= 1) continue;
                if (game == null) {
                    game = game3;
                    n3 = n4;
                    continue;
                }
                if (n4 <= n3) continue;
                game = game3;
                n3 = n4;
            }
            if (game == null) {
                player.sendMessage(Messages.NO_GAME_FOUND.toString());
                return null;
            }
            return game;
        }
        return game;
    }

    public void addQuickPlayer(Game game, Player player) {
        GameJoinEvent gameJoinEvent = new GameJoinEvent(player);
        this.main.getServer().getPluginManager().callEvent((Event)gameJoinEvent);
        this.data.put((Object)player.getUniqueId(), (Object)new PlayerData(this.main, player));
        game.addinQueue(player);
        game.setMoney(player, 800);
        this.main.getVersionInterface().setHandSpeed(player, 100.0);
        GameTeam.Role role = this.main.getManager().getTeam(game, player);
        Inventory inventory = Bukkit.createInventory(null, (int)54, (String)Messages.ITEM_SHOP_NAME.toString());
        for (PlayerShop playerShop : this.main.getShops()) {
            Grenade grenade;
            if (playerShop.getType() == ShopType.GRENADE) {
                grenade = this.main.getGrenade(playerShop.getWeaponName());
                inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)grenade.getItem().getType(), (int)1, (int)grenade.getItem().getData(), (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
                continue;
            }
            if (playerShop.getType() == ShopType.GUN && (playerShop.getRole() == null || playerShop.getRole() == role)) {
                if (this.main.hideVipGuns() && playerShop.hasPermission() && !player.hasPermission("cs.weapon." + playerShop.getWeaponName())) continue;
                grenade = this.main.getGun(playerShop.getWeaponName());
                inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)grenade.getItem().getType(), (int)1, (int)grenade.getItem().getData(), (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
                continue;
            }
            if (playerShop.getRole() != role) continue;
            inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)playerShop.getMaterial(), (Integer)1, (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
        }
        game.getShops().put((Object)player.getUniqueId(), (Object)inventory);
        Iterator iterator = new ScoreBoard(this.main, game, player);
        game.getStatus().put((Object)player.getUniqueId(), (Object)iterator);
        player.playSound(player.getLocation(), SpigotSound.ENDERMAN_TELEPORT.getSound(), 1.0f, 1.0f);
        this.updateSigns(game);
        for (Grenade grenade : game.getStatus().values()) {
            if (iterator != grenade) {
                grenade.getTeams().add(game, player);
            }
            this.updateStatus(game, grenade.getStatus());
        }
        this.updateTitle(game);
        iterator.showTeams(game);
        iterator.showHealth(game);
        player.setGameMode(GameMode.SPECTATOR);
        if (game.getBar() != null) {
            game.getBar().addPlayer(player);
        }
        for (Grenade grenade : Bukkit.getOnlinePlayers()) {
            if (game.getTeamA().getPlayers().contains((Object)grenade) || game.getTeamB().getPlayers().contains((Object)grenade)) {
                grenade.showPlayer(player);
                continue;
            }
            player.hidePlayer((Player)grenade);
        }
    }

    public void addPlayer(Player player, Game game) {
        if (game == null) {
            player.sendMessage(Messages.ARENA_IS_NULL.toString());
        } else if (this.getGame(player) != null) {
            player.sendMessage(Messages.ARENA_JOIN_ANOTHER_GAME.toString());
        } else if (game.getState() == GameState.DISABLED) {
            player.sendMessage(Messages.ARENA_IS_DISABLED.toString());
        } else if (game.getState() != GameState.WAITING) {
            player.sendMessage(Messages.ARENA_HAS_STARTED.toString());
        } else if (!this.bungee && !this.main.getTextureUsers().contains((Object)player.getUniqueId()) && this.main.canForceTexture()) {
            player.sendMessage(Messages.ARENA_NO_TEXTURE.toString());
        } else if (game.getTeamA().size() + game.getTeamB().size() == game.getMaxPlayers()) {
            player.sendMessage(Messages.ARENA_IS_FULL.toString());
        } else {
            GameJoinEvent gameJoinEvent = new GameJoinEvent(player);
            this.main.getServer().getPluginManager().callEvent((Event)gameJoinEvent);
            game.addRandomTeam(player);
            this.main.getVersionInterface().setHandSpeed(player, 100.0);
            player.getInventory().setHeldItemSlot(4);
            this.data.put((Object)player.getUniqueId(), (Object)new PlayerData(this.main, player));
            player.teleport(game.getLobby());
            ScoreBoard scoreBoard = new ScoreBoard(this.main, game, player);
            game.getStatus().put((Object)player.getUniqueId(), (Object)scoreBoard);
            game.getStats().put((Object)player.getUniqueId(), (Object)new PlayerStatus(player.getName(), player.getUniqueId()));
            player.playSound(player.getLocation(), SpigotSound.ENDERMAN_TELEPORT.getSound(), 1.0f, 1.0f);
            player.getInventory().setItem(0, ItemBuilder.create((Material)Material.LEATHER, (Integer)1, (String)("&a" + Messages.SELECTOR_NAME + " &8(&e" + Messages.ITEM_RIGHT_CLICK + "&8)"), (String)Messages.SELECTOR_LORE.toString()));
            player.getInventory().setItem(8, ItemBuilder.create((Material)Material.RED_BED, (Integer)1, (String)(Messages.ITEM_LEFTGAME_NAME + " &8(&e" + Messages.ITEM_RIGHT_CLICK + "&8)"), (String)Messages.ITEM_LEFTGAME_LORE.toString()));
            player.updateInventory();
            game.broadcast(Messages.PREFIX + Messages.GAME_JOIN.toString().replace((CharSequence)"%name%", (CharSequence)player.getName()).replace((CharSequence)"%size%", (CharSequence)String.valueOf((int)(game.getTeamA().size() + game.getTeamB().size()))).replace((CharSequence)"%maxsize%", (CharSequence)String.valueOf((int)game.getMaxPlayers())));
            if (game.getTeamA().size() + game.getTeamB().size() >= game.getMinPlayers()) {
                game.start();
            }
            this.updateSigns(game);
            this.updateTitle(game);
            if (game.getBar() != null) {
                game.getBar().addPlayer(player);
            }
            for (ScoreBoard scoreBoard2 : game.getStatus().values()) {
                this.updateStatus(game, scoreBoard2.getStatus());
            }
            for (ScoreBoard scoreBoard2 : Bukkit.getOnlinePlayers()) {
                if (game.getTeamA().getPlayers().contains((Object)scoreBoard2) || game.getTeamB().getPlayers().contains((Object)scoreBoard2)) {
                    scoreBoard2.showPlayer(player);
                    continue;
                }
                player.hidePlayer((Player)scoreBoard2);
            }
        }
    }

    public void removePlayer(Game game, Player player, boolean bl, boolean bl2) {
        Item item;
        Grenade grenade;
        MySQL mySQL;
        game.removeFromQueue(player);
        game.getTeamA().removePlayer(player);
        game.getTeamB().removePlayer(player);
        game.getSpectators().remove((Object)player);
        if (!game.isGameEnding()) {
            mySQL = this.main.getGrenades().iterator();
            while (mySQL.hasNext()) {
                grenade = (Grenade)mySQL.next();
                grenade.removePlayer(player);
            }
        }
        if ((mySQL = this.main.getMySQL()) != null && game.getState() != GameState.WAITING) {
            mySQL.addInQueue((PlayerStatus)game.getStats().get((Object)player.getUniqueId()));
        }
        if (!bl && game.getState() == GameState.IN_GAME && game.getBomb().getCarrier() == player) {
            grenade = ItemBuilder.create((Material)Material.QUARTZ, (int)1, (String)("\u00a7e\u9276\u00a7a " + Messages.ITEM_BOMB_NAME), (boolean)false);
            item = player.getWorld().dropItemNaturally(player.getLocation(), (ItemStack)grenade);
            game.getDrops().put((Object)item, (Object)1);
            game.getBomb().setDrop(item);
        }
        if (!(bl || game.getState() == GameState.WAITING || game.getState() == GameState.END || game.isGameEnding() || game.getTeamA().size() != 0 && game.getTeamB().size() != 0)) {
            this.stopGame(game, true);
            game.broadcast(Messages.PREFIX + Messages.GAME_NO_PLAYERS.toString());
        }
        if (game.getBar() != null) {
            game.getBar().removePlayer(player);
        }
        if (bl) {
            if (!this.bungee || !this.main.randomMap()) {
                player.teleport(game.getLobby());
            }
            this.clearPlayer(player);
            grenade = (ScoreBoard)game.getStatus().get((Object)player.getUniqueId());
            grenade.getStatus().reset();
            this.updateStatus(game, grenade.getStatus());
            player.getInventory().setItem(0, ItemBuilder.create((Material)Material.LEATHER, (Integer)1, (String)("&a" + Messages.SELECTOR_NAME + " &8(&e" + Messages.ITEM_RIGHT_CLICK + "&8)"), (String)Messages.SELECTOR_LORE.toString()));
            player.getInventory().setItem(8, ItemBuilder.create((Material)Material.RED_BED, (Integer)1, (String)(Messages.ITEM_LEFTGAME_NAME + " &8(&e" + Messages.ITEM_RIGHT_CLICK + "&8)"), (String)Messages.ITEM_LEFTGAME_LORE.toString()));
        } else {
            this.updateSigns(game);
            boolean bl3 = this.spawn == null;
            game.getStats().remove((Object)player.getUniqueId());
            if (!bl3) {
                player.teleport(this.spawn);
            }
            ((PlayerData)this.data.remove((Object)player.getUniqueId())).restore(bl3);
            item = (ScoreBoard)game.getStatus().remove((Object)player.getUniqueId());
            if (game.getState() != GameState.WAITING) {
                for (ScoreBoard scoreBoard : game.getStatus().values()) {
                    if (item == scoreBoard || scoreBoard.getTeams() == null) continue;
                    scoreBoard.getTeams().remove(game, player);
                }
            }
            item.remove();
            if (!bl2) {
                for (ScoreBoard scoreBoard : Bukkit.getOnlinePlayers()) {
                    player.showPlayer((Player)scoreBoard);
                }
                for (ScoreBoard scoreBoard : game.getTeamA().getPlayers()) {
                    scoreBoard.hidePlayer(player);
                }
                for (ScoreBoard scoreBoard : game.getTeamB().getPlayers()) {
                    scoreBoard.hidePlayer(player);
                }
            }
            if (bl2 && game.getState() == GameState.WAITING) {
                game.broadcast(Messages.PREFIX + Messages.GAME_LEAVE.toString().replace((CharSequence)"%name%", (CharSequence)player.getName()).replace((CharSequence)"%size%", (CharSequence)String.valueOf((int)(game.getTeamA().size() + game.getTeamB().size()))).replace((CharSequence)"%maxsize%", (CharSequence)String.valueOf((int)game.getMaxPlayers())));
            }
            this.main.getVersionInterface().setHandSpeed(player, 4.0);
            if (!bl || !this.main.randomMap()) {
                Iterator iterator = new GameLeaveEvent(player);
                this.main.getServer().getPluginManager().callEvent((Event)iterator);
            }
        }
        player.updateInventory();
    }

    public void addGame(Game game) {
        this.games.add((Object)game);
    }

    public void updateSigns(Game game) {
        for (Location location : game.getSigns()) {
            if (!(location.getBlock().getState() instanceof Sign)) continue;
            Sign sign = (Sign)location.getBlock().getState();
            sign.setLine(0, Messages.SIGN_FIRST.toString().replace((CharSequence)"%prefix%", (CharSequence)Messages.PREFIX.toString()).replace((CharSequence)"%name%", (CharSequence)game.getName()).replace((CharSequence)"%state%", (CharSequence)game.getState().getState()).replace((CharSequence)"%min%", (CharSequence)(game.getTeamA().size() + game.getTeamB().size() + "")).replace((CharSequence)"%max%", (CharSequence)(game.getMaxPlayers() + "")));
            sign.setLine(1, Messages.SIGN_SECOND.toString().replace((CharSequence)"%prefix%", (CharSequence)Messages.PREFIX.toString()).replace((CharSequence)"%name%", (CharSequence)game.getName()).replace((CharSequence)"%state%", (CharSequence)game.getState().getState()).replace((CharSequence)"%min%", (CharSequence)(game.getTeamA().size() + game.getTeamB().size() + "")).replace((CharSequence)"%max%", (CharSequence)(game.getMaxPlayers() + "")));
            sign.setLine(2, Messages.SIGN_THIRD.toString().replace((CharSequence)"%prefix%", (CharSequence)Messages.PREFIX.toString()).replace((CharSequence)"%name%", (CharSequence)game.getName()).replace((CharSequence)"%state%", (CharSequence)game.getState().getState()).replace((CharSequence)"%min%", (CharSequence)(game.getTeamA().size() + game.getTeamB().size() + "")).replace((CharSequence)"%max%", (CharSequence)(game.getMaxPlayers() + "")));
            sign.setLine(3, Messages.SIGN_FOURTH.toString().replace((CharSequence)"%prefix%", (CharSequence)Messages.PREFIX.toString()).replace((CharSequence)"%name%", (CharSequence)game.getName()).replace((CharSequence)"%state%", (CharSequence)game.getState().getState()).replace((CharSequence)"%min%", (CharSequence)(game.getTeamA().size() + game.getTeamB().size() + "")).replace((CharSequence)"%max%", (CharSequence)(game.getMaxPlayers() + "")));
            sign.update();
        }
    }

    public void updateTitle(Game game) {
        for (ScoreBoard scoreBoard : game.getStatus().values()) {
            if (game.getState() == GameState.WAITING) {
                scoreBoard.getStatus().setTitle(Messages.SCOREBOARD_TITLE.toString());
                continue;
            }
            if (game.getState() == GameState.ROUND || game.getState() == GameState.IN_GAME) {
                int n = game.getScoreTeamA();
                int n2 = game.getScoreTeamB();
                GameTeam.Role role = game.getTeamA().getRole();
                scoreBoard.getStatus().setTitle("\u00a73" + (role == GameTeam.Role.COUNTERTERRORIST ? n : n2) + " \u9290 \u00a77" + Messages.SPLITTER + " \u00a74\u9291 " + (role == GameTeam.Role.TERRORIST ? n : n2));
                continue;
            }
            scoreBoard.getStatus().setTitle(Messages.TITLE_GAME_OVER.toString());
        }
    }

    public void updateStatus(Game game, ScoreBoardStatus scoreBoardStatus) {
        Player player = scoreBoardStatus.getPlayer();
        if (game.getState() == GameState.WAITING || game.isGameEnding()) {
            scoreBoardStatus.updateLine(7, "");
            scoreBoardStatus.updateLine(6, Messages.SCOREBOARD_LOBBY_NAME + " \u00a7a" + game.getName());
            scoreBoardStatus.updateLine(5, Messages.SCOREBOARD_LOBBY_PLAYERS + " \u00a7a" + (game.getTeamA().size() + game.getTeamB().size()) + "/" + game.getMaxPlayers());
            scoreBoardStatus.updateLine(4, "");
            if (game.isGameStarted()) {
                scoreBoardStatus.updateLine(3, Messages.SCOREBOARD_LOBBY_GAME_START + " \u00a7c" + game.getTimer());
            } else {
                scoreBoardStatus.updateLine(3, Messages.SCOREBOARD_LOBBY_WAITING.toString());
            }
            scoreBoardStatus.updateLine(2, "");
            scoreBoardStatus.updateLine(1, Messages.SCOREBOARD_LOBBY_SERVER.toString());
        } else if (game.getState() != GameState.END || game.getState() != GameState.DISABLED) {
            String string;
            int n;
            scoreBoardStatus.updateLine(15, "");
            if (this.getTeam(game, scoreBoardStatus.getPlayer()) == GameTeam.Role.COUNTERTERRORIST) {
                if (game.getBomb().isPlanted()) {
                    scoreBoardStatus.updateLine(14, "\u00a72[\u927b " + Messages.SCOREBOARD_GAME_OBJECTIVE.toString() + "]");
                    scoreBoardStatus.updateLine(13, Messages.SCOREBOARD_GAME_DEFUSE.toString());
                } else {
                    scoreBoardStatus.updateLine(14, "\u00a72[\u9260 " + Messages.SCOREBOARD_GAME_OBJECTIVE.toString() + "]");
                    scoreBoardStatus.updateLine(13, Messages.SCOREBOARD_GAME_PROTECT.toString());
                }
            } else if (game.getBomb().isPlanted()) {
                scoreBoardStatus.updateLine(14, "\u00a72[\u9275 " + Messages.SCOREBOARD_GAME_OBJECTIVE.toString() + "]");
                scoreBoardStatus.updateLine(13, Messages.SCOREBOARD_GAME_PROTECT_BOMB.toString());
            } else if (game.getBomb().getCarrier() == player) {
                scoreBoardStatus.updateLine(14, "\u00a72[\u9274 " + Messages.SCOREBOARD_GAME_OBJECTIVE.toString() + "]");
                scoreBoardStatus.updateLine(13, Messages.SCOREBOARD_GAME_PLANT_BOMB.toString());
            } else {
                scoreBoardStatus.updateLine(14, "\u00a72[\u9276 " + Messages.SCOREBOARD_GAME_OBJECTIVE.toString() + "]");
                scoreBoardStatus.updateLine(13, Messages.SCOREBOARD_GAME_ESCORT_CARRIER.toString());
            }
            if (game.getState() == GameState.IN_GAME && !game.isRoundEnding()) {
                n = game.getTimer();
                string = game.getBomb().isPlanted() ? (n % 2 == 0 ? "\u00a7c" : "") : "";
                scoreBoardStatus.updateLine(12, string + (n % 3600 / 60 < 10 ? "0" : "") + n % 3600 / 60 + ":" + (n % 3600 % 60 < 10 ? "0" : "") + n % 3600 % 60);
            } else if (game.isRoundEnding() && !game.getBomb().isPlanted()) {
                scoreBoardStatus.updateLine(12, "00:00");
            } else {
                n = game.getBomb().isPlanted() ? game.getBomb().getTimer() : this.main.getRoundTime();
                scoreBoardStatus.updateLine(12, (n % 3600 / 60 < 10 ? "0" : "") + n % 3600 / 60 + ":" + (n % 3600 % 60 < 10 ? "0" : "") + n % 3600 % 60);
            }
            scoreBoardStatus.updateLine(11, "");
            scoreBoardStatus.updateLine(10, "\u00a76[\u9280 " + Messages.SCOREBOARD_GAME_STATUS.toString() + "]");
            scoreBoardStatus.updateLine(9, Messages.SCOREBOARD_GAME_MONEY.toString() + "\u00a76$" + game.getMoney(player));
            ItemStack itemStack = player.getInventory().getHelmet();
            string = player.getInventory().getChestplate();
            scoreBoardStatus.updateLine(8, Messages.SCOREBOARD_GAME_ARMOR.toString() + (itemStack != null && itemStack.getType() != Material.LEATHER_HELMET ? "\u00a7a\u927f" : "\u00a77\u927f") + (string != null && string.getType() != Material.LEATHER_CHESTPLATE ? "\u00a7a\u927e" : "\u00a77\u927e"));
            PlayerStatus playerStatus = (PlayerStatus)game.getStats().get((Object)player.getUniqueId());
            scoreBoardStatus.updateLine(7, Messages.SCOREBOARD_GAME_DEATHS.toString() + "\u00a73" + playerStatus.getDeaths());
            scoreBoardStatus.updateLine(6, Messages.SCOREBOARD_GAME_KILLS.toString() + "\u00a73" + playerStatus.getKills());
            scoreBoardStatus.updateLine(5, "");
            scoreBoardStatus.updateLine(4, "\u00a74\u9291\u00a7f " + Messages.SCOREBOARD_GAME_ALIVE.toString() + "\u00a74" + this.getAlivePlayers(game, this.getTeam(game, GameTeam.Role.TERRORIST)));
            scoreBoardStatus.updateLine(3, "\u00a73\u9290\u00a7f " + Messages.SCOREBOARD_GAME_ALIVE.toString() + "\u00a73" + this.getAlivePlayers(game, this.getTeam(game, GameTeam.Role.COUNTERTERRORIST)));
            scoreBoardStatus.updateLine(2, "");
            String string2 = this.getTeam(game, player) == GameTeam.Role.TERRORIST ? "\u9291 " + Messages.TEAM_TERRORIST_NAME : "\u9290 " + Messages.TEAM_COUNTERTERRORIST_NAME;
            String string3 = this.getTeam(game, player) == GameTeam.Role.TERRORIST ? "\u00a74" : "\u00a73";
            scoreBoardStatus.updateLine(1, Messages.TEAM_NAME + " " + (this.getTeam(game, GameTeam.Role.TERRORIST).getPlayers().contains((Object)player) ? string3 + Messages.TEAM_SECOND + " - " + string2 : string3 + Messages.TEAM_FIRST + " - " + string2));
        }
    }

    public void stopGame(Game game, boolean bl) {
        Player player2;
        game.stop();
        game.isGameEnding(true);
        this.endRound(game);
        for (ScoreBoard scoreBoard : game.getStatus().values()) {
            scoreBoard.getStatus().reset();
        }
        Iterator iterator = new ArrayList();
        if (bl) {
            for (Player player2 : game.getTeamA().getPlayers()) {
                iterator.add((Object)player2);
            }
            for (Player player2 : game.getTeamB().getPlayers()) {
                iterator.add((Object)player2);
            }
        }
        if (game.getTeamA().size() > 0) {
            for (int i = 0; i < game.getTeamA().size(); ++i) {
                player2 = game.getTeamA().getPlayer(i);
                this.removePlayer(game, player2, bl, false);
                --i;
            }
        }
        if (game.getTeamB().size() > 0) {
            for (int i = 0; i < game.getTeamB().size(); ++i) {
                player2 = game.getTeamB().getPlayer(i);
                this.removePlayer(game, player2, bl, false);
                --i;
            }
        }
        if (this.bungee && this.main.randomMap()) {
            ++this.bungee_map;
            if (this.bungee_map >= this.games.size()) {
                this.bungee_map = 0;
            }
            game.setGameTimer(this.main.getLobbyTime());
            game.setState(GameState.WAITING);
            game.isGameEnding(false);
            for (Player player2 : iterator) {
                Game game2 = (Game)this.main.getManager().getGames().get(this.bungee_map);
                this.addPlayer(player2, game2);
            }
            iterator.clear();
            return;
        }
        if (bl) {
            for (Player player2 : iterator) {
                game.addRandomTeam(player2);
            }
            for (Player player2 : game.getStatus().values()) {
                player2.removeHealth();
                player2.removeTeam();
                this.updateStatus(game, player2.getStatus());
            }
            iterator.clear();
        }
        if (bl && game.getTeamA().size() + game.getTeamB().size() >= game.getMinPlayers()) {
            game.start();
        }
        game.setGameTimer(this.main.getLobbyTime());
        game.setState(GameState.WAITING);
        game.isGameEnding(false);
    }

    public void endRound(Game game) {
        for (Grenade grenade : this.main.getGrenades()) {
            grenade.remove(game);
        }
        for (Grenade grenade : game.getDrops().keySet()) {
            grenade.remove();
        }
        game.getDrops().clear();
        if (game.getState() == GameState.ROUND) {
            game.getSpectators().forEach(player -> player.setGameMode(GameMode.SURVIVAL));
        }
        for (Grenade grenade : game.restoreBlocks()) {
            grenade.update(true);
        }
        for (Grenade grenade : game.getStats().values()) {
            grenade.resetRound();
        }
        game.setRoundWinner(null);
        game.resetDefusers();
        game.getBomb().reset();
        game.getSpectators().clear();
        game.setRoundEnding(false);
    }

    public Game getGame(int n) {
        for (Game game : this.games) {
            if (game.getID() != n) continue;
            return game;
        }
        return null;
    }

    public boolean isBungeeMode() {
        return this.bungee;
    }

    public PlayerData getData(Player player) {
        return (PlayerData)this.data.get((Object)player.getUniqueId());
    }

    public boolean sameTeam(Game game, Player player, Player player2) {
        if (game.getTeamA().getPlayers().contains((Object)player) && game.getTeamA().getPlayers().contains((Object)player2)) {
            return true;
        }
        return game.getTeamB().getPlayers().contains((Object)player) && game.getTeamB().getPlayers().contains((Object)player2);
    }

    public boolean isAtSpawn(Game game, Player player) {
        if (game.getMain().getManager().getTeam(game, player) == GameTeam.Role.TERRORIST) {
            for (Location location : game.getTerroristLoc()) {
                if (!(player.getLocation().distance(location) <= 7.0)) continue;
                return true;
            }
        } else {
            for (Location location : game.getCounterTerroristLoc()) {
                if (!(player.getLocation().distance(location) <= 7.0)) continue;
                return true;
            }
        }
        return false;
    }

    public boolean isInBombArea(Game game, Location location) {
        for (Location location2 : game.getBombLoc()) {
            if (!(location2.distance(location) <= 4.0)) continue;
            return true;
        }
        return false;
    }

    public GameTeam.Role getTeam(Game game, Player player) {
        if (game.getTeamA().getPlayers().contains((Object)player)) {
            return game.getTeamA().getRole();
        }
        return game.getTeamB().getRole();
    }

    public GameTeam getTeam(Game game, GameTeam.Role role) {
        if (game.getTeamA().getRole() == role) {
            return game.getTeamA();
        }
        return game.getTeamB();
    }

    public PlayerStatus getTop(Game game, GameTeam.Role role) {
        PlayerStatus playerStatus = null;
        for (Player player : this.getTeam(game, role).getPlayers()) {
            PlayerStatus playerStatus2 = (PlayerStatus)game.getStats().get((Object)player.getUniqueId());
            if (playerStatus == null) {
                playerStatus = playerStatus2;
                continue;
            }
            if (playerStatus2.getRoundKills() <= playerStatus.getRoundKills()) continue;
            playerStatus = playerStatus2;
        }
        return playerStatus;
    }

    public int getAlivePlayers(Game game, GameTeam gameTeam) {
        int n = 0;
        for (Player player : gameTeam.getPlayers()) {
            if (game.getSpectators().contains((Object)player)) continue;
            ++n;
        }
        return n;
    }

    public Game getGame(Player player) {
        for (Game game : this.games) {
            if (!game.getTeamA().getPlayers().contains((Object)player) && !game.getTeamB().getPlayers().contains((Object)player)) continue;
            return game;
        }
        return null;
    }

    public List<Game> getGames() {
        return this.games;
    }

    public List<Location> getQuickJoinSigns() {
        return this.quick_join;
    }

    public void clearPlayer(Player player) {
        player.setExp(0.0f);
        player.setLevel(0);
        player.setHealth(20.0);
        player.setFireTicks(0);
        player.setFoodLevel(20);
        player.setFlying(false);
        player.setFlySpeed(0.2f);
        player.setWalkSpeed(0.2f);
        player.setFallDistance(0.0f);
        player.setAllowFlight(false);
        player.getInventory().clear();
        player.setGameMode(GameMode.SURVIVAL);
        player.getInventory().setArmorContents(null);
        if (player.isInsideVehicle()) {
            player.leaveVehicle();
        }
        for (PotionEffect potionEffect : player.getActivePotionEffects()) {
            player.removePotionEffect(potionEffect.getType());
        }
        player.closeInventory();
    }

    public void resetPlayers(Game game) {
        Player player8;
        Player player22;
        int n;
        Location location2;
        for (Location location2 : game.getTerroristLoc()) {
            location2.getChunk().load(true);
        }
        for (Location location2 : game.getCounterTerroristLoc()) {
            location2.getChunk().load(true);
        }
        for (n = 0; n < this.getTeam(game, GameTeam.Role.COUNTERTERRORIST).size(); ++n) {
            location2 = this.getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayer(n);
            location2.setHealth(20.0);
            location2.closeInventory();
            for (Player player22 : game.getTeamA().getPlayers()) {
                ((ScoreBoard)game.getStatus().get((Object)player22.getUniqueId())).getHealth().update((Player)location2);
            }
            player8 = game.getTeamB().getPlayers().iterator();
            while (player8.hasNext()) {
                player22 = (Player)player8.next();
                ((ScoreBoard)game.getStatus().get((Object)player22.getUniqueId())).getHealth().update((Player)location2);
            }
            location2.sendMessage(Messages.LINE_SPLITTER.toString());
            location2.sendMessage(Messages.LINE_PREFIX.toString());
            location2.sendMessage("");
            for (Player player3 : player8 = Messages.COP_START_MESSAGE.toString().split("#")) {
                location2.sendMessage("\u27a2 " + (String)player3);
            }
            location2.sendMessage(Messages.LINE_SPLITTER.toString());
            if (game.getRound() == 0) {
                game.setMoney((Player)location2, 800);
                location2.getInventory().setItem(0, null);
                location2.getInventory().setItem(2, ItemBuilder.create((Material)this.main.getDefaultCopKnife(), (int)1, (String)("&a" + Messages.ITEM_KNIFE_NAME + " &7\u928c"), (boolean)true));
            } else if (game.getRound() == this.main.getRoundToSwitch()) {
                game.setMoney((Player)location2, 800);
                location2.getInventory().setItem(0, null);
                location2.getInventory().setItem(3, null);
                location2.getInventory().setItem(4, null);
                location2.getInventory().setItem(7, null);
                location2.getInventory().setItem(5, ItemBuilder.create((Material)Material.GOLD_NUGGET, (int)1, (String)("&a" + Messages.ITEM_SHEAR_NAME + " &7\u927b"), (boolean)false));
                player22 = this.main.getGun(this.main.getCopsDefaultWeapon());
                location2.getInventory().setItem(1, ItemBuilder.create((Material)player22.getItem().getType(), (int)player22.getAmount(), (int)player22.getItem().getData(), (String)(player22.getItem().getName() + " &7" + player22.getSymbol())));
                location2.getInventory().setItem(2, ItemBuilder.create((Material)this.main.getDefaultCopKnife(), (int)1, (String)("&a" + Messages.ITEM_KNIFE_NAME + " &7\u928c"), (boolean)true));
            }
            if (location2.getInventory().getItem(1) == null) {
                player22 = this.main.getGun(this.main.getCopsDefaultWeapon());
                location2.getInventory().setItem(1, ItemBuilder.create((Material)player22.getItem().getType(), (int)player22.getAmount(), (int)player22.getItem().getData(), (String)(player22.getItem().getName() + " &7" + player22.getSymbol())));
            }
            if (location2.getInventory().getItem(2) == null) {
                location2.getInventory().setItem(2, ItemBuilder.create((Material)this.main.getDefaultCopKnife(), (int)1, (String)("&a" + Messages.ITEM_KNIFE_NAME + " &7\u928c"), (boolean)true));
            }
            if (location2.getInventory().getItem(5) == null) {
                location2.getInventory().setItem(5, ItemBuilder.create((Material)Material.GOLD_NUGGET, (int)1, (String)("&a" + Messages.ITEM_SHEAR_NAME + " &7\u927b"), (boolean)false));
            }
            for (int i = 0; i <= 1; ++i) {
                Gun gun = this.main.getGun(location2.getInventory().getItem(i));
                if (gun == null) continue;
                location2.setExp(0.0f);
                gun.resetPlayer((Player)location2);
                location2.getInventory().setItem(i, ItemBuilder.create((Material)gun.getItem().getType(), (int)gun.getAmount(), (int)gun.getItem().getData(), (String)(gun.getItem().getName() + " &7" + gun.getSymbol())));
            }
            player22 = (ScoreBoard)game.getStatus().get((Object)location2.getUniqueId());
            for (Player player4 : game.getTeamA().getPlayers()) {
                player22.getTeams().update(game, player4);
            }
            for (Player player5 : game.getTeamB().getPlayers()) {
                player22.getTeams().update(game, player5);
            }
            this.main.getVersionInterface().sendInvisibility(player22.getScoreboard(), game.getTeamA().getPlayers(), game.getSpectators());
            this.main.getVersionInterface().sendInvisibility(player22.getScoreboard(), game.getTeamB().getPlayers(), game.getSpectators());
            location2.getInventory().setItem(8, ItemBuilder.create((Material)Material.GHAST_TEAR, (int)1, (String)("&a" + Messages.ITEM_SHOP_NAME), (boolean)false));
            location2.teleport((Location)game.getCounterTerroristLoc().get(n));
            location2.playSound(location2.getEyeLocation(), SpigotSound.NOTE_PLING.getSound(), 2.0f, 2.0f);
            if (game.getRound() == this.main.getRoundToSwitch()) {
                location2.playSound(location2.getLocation(), "cs.gamesounds.swappingsides", 1.0f, 1.0f);
            }
            if (location2.getInventory().getHeldItemSlot() == 2) {
                location2.setWalkSpeed(0.25f);
            } else {
                location2.setWalkSpeed(0.2f);
            }
            if (location2.getInventory().getHelmet() == null || game.getRound() == this.main.getRoundToSwitch()) {
                location2.getInventory().setHelmet(ItemBuilder.createItem((Material)Material.LEATHER_HELMET, (Color)Color.BLUE, (String)this.main.getDefaultHelmetName()));
            }
            if (location2.getInventory().getChestplate() != null && game.getRound() != this.main.getRoundToSwitch()) continue;
            location2.getInventory().setChestplate(ItemBuilder.createItem((Material)Material.LEATHER_CHESTPLATE, (Color)Color.BLUE, (String)this.main.getDefaultChestplateName()));
        }
        for (n = 0; n < this.getTeam(game, GameTeam.Role.TERRORIST).size(); ++n) {
            location2 = this.getTeam(game, GameTeam.Role.TERRORIST).getPlayer(n);
            location2.setHealth(20.0);
            location2.closeInventory();
            for (Player player22 : game.getTeamA().getPlayers()) {
                ((ScoreBoard)game.getStatus().get((Object)player22.getUniqueId())).getHealth().update((Player)location2);
            }
            for (Player player22 : game.getTeamB().getPlayers()) {
                ((ScoreBoard)game.getStatus().get((Object)player22.getUniqueId())).getHealth().update((Player)location2);
            }
            if (game.getRound() == 0) {
                game.setMoney((Player)location2, 800);
                location2.getInventory().setItem(0, null);
                location2.getInventory().setItem(2, ItemBuilder.create((Material)this.main.getDefaultCrimKnife(), (int)1, (String)("&a" + Messages.ITEM_KNIFE_NAME + " &7\u928c"), (boolean)true));
            } else if (game.getRound() == this.main.getRoundToSwitch()) {
                game.setMoney((Player)location2, 800);
                location2.getInventory().setItem(0, null);
                location2.getInventory().setItem(3, null);
                location2.getInventory().setItem(4, null);
                location2.getInventory().setArmorContents(null);
                location2.getInventory().setItem(2, ItemBuilder.create((Material)this.main.getDefaultCrimKnife(), (int)1, (String)("&a" + Messages.ITEM_KNIFE_NAME + " &7\u928c"), (boolean)true));
                player8 = this.main.getGun(this.main.getCrimsDefaultWeapon());
                location2.getInventory().setItem(1, ItemBuilder.create((Material)player8.getItem().getType(), (int)player8.getAmount(), (int)player8.getItem().getData(), (String)(player8.getItem().getName() + " &7" + player8.getSymbol())));
            }
            location2.getInventory().setItem(5, null);
            if (location2.getInventory().getItem(1) == null) {
                player8 = this.main.getGun(this.main.getCrimsDefaultWeapon());
                location2.getInventory().setItem(1, ItemBuilder.create((Material)player8.getItem().getType(), (int)player8.getAmount(), (int)player8.getItem().getData(), (String)(player8.getItem().getName() + " &7" + player8.getSymbol())));
            }
            if (location2.getInventory().getItem(2) == null) {
                location2.getInventory().setItem(2, ItemBuilder.create((Material)this.main.getDefaultCrimKnife(), (int)1, (String)("&a" + Messages.ITEM_KNIFE_NAME + " &7\u928c"), (boolean)true));
            }
            for (int i = 0; i <= 1; ++i) {
                player22 = this.main.getGun(location2.getInventory().getItem(i));
                if (player22 == null) continue;
                location2.setExp(0.0f);
                player22.resetPlayer((Player)location2);
                location2.getInventory().setItem(i, ItemBuilder.create((Material)player22.getItem().getType(), (int)player22.getAmount(), (int)player22.getItem().getData(), (String)(player22.getItem().getName() + " &7" + player22.getSymbol())));
            }
            player8 = (ScoreBoard)game.getStatus().get((Object)location2.getUniqueId());
            for (Player player6 : game.getTeamA().getPlayers()) {
                player8.getTeams().update(game, player6);
            }
            player22 = game.getTeamB().getPlayers().iterator();
            while (player22.hasNext()) {
                Player player6;
                player6 = (Player)player22.next();
                player8.getTeams().update(game, player6);
            }
            this.main.getVersionInterface().sendInvisibility(player8.getScoreboard(), game.getTeamA().getPlayers(), game.getSpectators());
            this.main.getVersionInterface().sendInvisibility(player8.getScoreboard(), game.getTeamB().getPlayers(), game.getSpectators());
            if (this.main.hasCompass()) {
                location2.getInventory().setItem(7, ItemBuilder.create((Material)Material.COMPASS, (int)1, (String)("&5" + Messages.ITEM_BOMB_LOCATOR), (boolean)false));
            }
            location2.getInventory().setItem(8, ItemBuilder.create((Material)Material.GHAST_TEAR, (int)1, (String)("&a" + Messages.ITEM_SHOP_NAME), (boolean)false));
            location2.teleport((Location)game.getTerroristLoc().get(n));
            location2.playSound(location2.getEyeLocation(), SpigotSound.NOTE_PLING.getSound(), 2.0f, 2.0f);
            if (game.getRound() == this.main.getRoundToSwitch()) {
                location2.playSound(location2.getLocation(), "cs.gamesounds.swappingsides", 1.0f, 1.0f);
            }
            if (location2.getInventory().getHeldItemSlot() == 2) {
                location2.setWalkSpeed(0.25f);
            } else {
                location2.setWalkSpeed(0.2f);
            }
            if (location2.getInventory().getHelmet() == null || game.getRound() == this.main.getRoundToSwitch()) {
                location2.getInventory().setHelmet(ItemBuilder.createItem((Material)Material.LEATHER_HELMET, (Color)Color.RED, (String)this.main.getDefaultHelmetName()));
            }
            if (location2.getInventory().getChestplate() != null && game.getRound() != this.main.getRoundToSwitch()) continue;
            location2.getInventory().setChestplate(ItemBuilder.createItem((Material)Material.LEATHER_CHESTPLATE, (Color)Color.RED, (String)this.main.getDefaultChestplateName()));
        }
        Player player7 = this.getTeam(game, GameTeam.Role.TERRORIST).getPlayer(MathUtils.random().nextInt(this.getTeam(game, GameTeam.Role.TERRORIST).size()));
        game.getBomb().setCarrier(player7);
        player7.getInventory().setItem(5, ItemBuilder.create((Material)Material.QUARTZ, (int)1, (String)("\u00a7e\u9276\u00a7a " + Messages.ITEM_BOMB_NAME), (boolean)false));
        for (Player player8 : this.getTeam(game, GameTeam.Role.TERRORIST).getPlayers()) {
            player8.setCompassTarget(player7.getLocation());
            if (player7.getUniqueId() == player8.getUniqueId()) {
                player8.sendMessage(Messages.LINE_SPLITTER.toString());
                player8.sendMessage(Messages.LINE_PREFIX.toString());
                player8.sendMessage("");
                for (Player player9 : player22 = Messages.CRIMS_START_MESSAGE_HAS_BOMB.toString().split("#")) {
                    player8.sendMessage("\u27a2 " + (String)player9);
                }
                player8.sendMessage(Messages.LINE_SPLITTER.toString());
                continue;
            }
            player8.sendMessage(Messages.LINE_SPLITTER.toString());
            player8.sendMessage(Messages.LINE_PREFIX.toString());
            player8.sendMessage("");
            for (Player player9 : player22 = Messages.CRIMS_START_MESSAGE_NO_BOMB.toString().split("#")) {
                player8.sendMessage("\u27a2 " + (String)player9);
            }
            player8.sendMessage(Messages.LINE_SPLITTER.toString());
        }
    }

    public boolean damage(Game game, Player player, Player player2, double d, String string) {
        if (d <= 0.0) {
            return false;
        }
        if (player2.getHealth() <= d) {
            PlayerStatus playerStatus;
            ItemStack itemStack2;
            player2.setHealth(5.0);
            player2.damage(4.0);
            player2.setHealth(20.0);
            player2.closeInventory();
            game.getSpectators().add((Object)player2);
            for (ItemStack itemStack2 : player2.getInventory().getContents()) {
                Player player32;
                Grenade grenade;
                Item item;
                if (itemStack2 == null) continue;
                Gun gun = this.main.getGun(itemStack2);
                if (gun != null) {
                    int n = itemStack2.getAmount() - 1;
                    itemStack2.setAmount(1);
                    item = player2.getWorld().dropItemNaturally(player2.getLocation(), itemStack2);
                    game.getDrops().put((Object)item, (Object)n);
                    player2.getInventory().remove(itemStack2);
                }
                if ((grenade = this.main.getGrenade(itemStack2)) != null) {
                    itemStack2.setAmount(1);
                    item = player2.getWorld().dropItemNaturally(player2.getLocation(), itemStack2);
                    game.getDrops().put((Object)item, (Object)1);
                    player2.getInventory().remove(itemStack2);
                }
                if (itemStack2.getType() == Material.SHEARS) {
                    item = player2.getWorld().dropItemNaturally(player2.getLocation(), itemStack2);
                    game.getDrops().put((Object)item, (Object)1);
                    item.setItemStack(itemStack2);
                }
                if (itemStack2.getType() == Material.QUARTZ) {
                    item = player2.getWorld().dropItemNaturally(player2.getLocation(), itemStack2);
                    game.getDrops().put((Object)item, (Object)1);
                    item.setItemStack(itemStack2);
                    game.getBomb().setDrop(item);
                    for (Player player32 : this.main.getManager().getTeam(game, GameTeam.Role.TERRORIST).getPlayers()) {
                        player32.playSound(player32.getLocation(), "cs.gamesounds.bombdroppedyourteam", 1.0f, 1.0f);
                    }
                    for (Player player32 : this.main.getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                        player32.playSound(player32.getLocation(), "cs.gamesounds.bombdroppedenemyteam", 1.0f, 1.0f);
                    }
                }
                if (itemStack2.getType() != Material.GOLDEN_APPLE) continue;
                item = player2.getWorld().dropItemNaturally(player2.getLocation(), itemStack2);
                game.getDrops().put((Object)item, (Object)1);
                ItemMeta itemMeta = itemStack2.getItemMeta();
                itemMeta.setDisplayName("\u00a7e\u9276\u00a7a Bomb");
                itemStack2.setItemMeta(itemMeta);
                itemStack2.setType(Material.QUARTZ);
                item.setItemStack(itemStack2);
                game.getBomb().setDrop(item);
                for (Player player4 : this.main.getManager().getTeam(game, GameTeam.Role.TERRORIST).getPlayers()) {
                    player4.playSound(player4.getLocation(), "cs.gamesounds.bombdroppedyourteam", 1.0f, 1.0f);
                }
                player32 = this.main.getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayers().iterator();
                while (player32.hasNext()) {
                    Player player4;
                    player4 = (Player)player32.next();
                    player4.playSound(player4.getLocation(), "cs.gamesounds.bombdroppedenemyteam", 1.0f, 1.0f);
                }
            }
            if (player != null) {
                playerStatus = (PlayerStatus)game.getStats().get((Object)player.getUniqueId());
                playerStatus.addKill();
                if (this.main.getKillCommand() != null && !this.main.getKillCommand().equalsIgnoreCase("none")) {
                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)this.main.getKillCommand().replace((CharSequence)"%player%", (CharSequence)player.getName()));
                }
            }
            playerStatus = (PlayerStatus)game.getStats().get((Object)player2.getUniqueId());
            playerStatus.addDeath();
            for (Player player5 : game.getTeamA().getPlayers()) {
                itemStack2 = (ScoreBoard)game.getStatus().get((Object)player5.getUniqueId());
                if (player != null) {
                    itemStack2.getTeams().update(game, player);
                }
                itemStack2.getTeams().update(game, player2);
                this.main.getVersionInterface().sendInvisibility(itemStack2.getScoreboard(), game.getTeamA().getPlayers(), game.getSpectators());
                this.main.getVersionInterface().sendInvisibility(itemStack2.getScoreboard(), game.getTeamB().getPlayers(), game.getSpectators());
            }
            for (Player player6 : game.getTeamB().getPlayers()) {
                itemStack2 = (ScoreBoard)game.getStatus().get((Object)player6.getUniqueId());
                if (player != null) {
                    itemStack2.getTeams().update(game, player);
                }
                itemStack2.getTeams().update(game, player2);
                this.main.getVersionInterface().sendInvisibility(itemStack2.getScoreboard(), game.getTeamA().getPlayers(), game.getSpectators());
                this.main.getVersionInterface().sendInvisibility(itemStack2.getScoreboard(), game.getTeamB().getPlayers(), game.getSpectators());
            }
            if (this.main.corpseSupport()) {
                // empty if block
            }
            this.clearPlayer(player2);
            player2.updateInventory();
            player2.setGameMode(GameMode.SPECTATOR);
            if (player != null) {
                game.setMoney(player, game.getMoney(player) + 150);
                int n = this.getTeam(game, player) == GameTeam.Role.TERRORIST ? 4 : 3;
                int n2 = this.getTeam(game, player2) == GameTeam.Role.TERRORIST ? 4 : 3;
                game.broadcast("&" + n + player.getName() + " &f" + string + " &" + n2 + player2.getName());
                this.main.getVersionInterface().sendTitle(player2, 0, 100, 0, Messages.ALREADY_DEAD.toString(), "\u00a7" + n + player.getName() + " \u00a7f" + string + " \u00a7" + n2 + player2.getName());
            } else {
                int n = this.getTeam(game, player2) == GameTeam.Role.TERRORIST ? 4 : 3;
                game.broadcast("&f" + string + " &" + n + player2.getName());
                this.main.getVersionInterface().sendTitle(player2, 0, 100, 0, Messages.ALREADY_DEAD.toString(), "\u00a7f" + string + " \u00a7" + n + player2.getName());
            }
            return true;
        }
        if (player2.getNoDamageTicks() < 1) {
            double d2 = player2.getHealth();
            player2.setHealth(5.0);
            player2.damage(4.0);
            player2.setHealth(d2);
            player2.setNoDamageTicks(1);
        }
        player2.setHealth(player2.getHealth() - d);
        for (Player player7 : game.getTeamA().getPlayers()) {
            ((ScoreBoard)game.getStatus().get((Object)player7.getUniqueId())).getHealth().update(player2);
        }
        for (Player player7 : game.getTeamB().getPlayers()) {
            ((ScoreBoard)game.getStatus().get((Object)player7.getUniqueId())).getHealth().update(player2);
        }
        return false;
    }

    public void removeGame(Game game) {
        for (Location location : game.getSigns()) {
            if (!(location.getBlock().getState() instanceof Sign)) continue;
            Sign sign = (Sign)location.getBlock().getState();
            sign.setLine(0, "");
            sign.setLine(1, "");
            sign.setLine(2, "");
            sign.setLine(3, "");
            sign.update();
            List list = this.main.getGameDatabase().getStringList("Signs");
            list.remove((Object)(game.getID() + "," + sign.getWorld().getName() + "," + sign.getLocation().getBlockX() + "," + sign.getLocation().getBlockY() + "," + sign.getLocation().getBlockZ()));
            this.main.getGameDatabase().set("Signs", (Object)list);
        }
        game.getShops().clear();
        game.getFireworks().clear();
        game.getBombLoc().clear();
        game.getTerroristLoc().clear();
        game.getCounterTerroristLoc().clear();
        this.games.remove((Object)game);
    }
}
