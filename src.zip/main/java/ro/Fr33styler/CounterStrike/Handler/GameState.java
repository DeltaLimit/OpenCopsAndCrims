/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  ro.Fr33styler.CounterStrike.Messages
 */
package ro.Fr33styler.CounterStrike.Handler;

import ro.Fr33styler.CounterStrike.Messages;

public enum GameState {
    WAITING(Messages.STATE_WAITING),
    ROUND(Messages.STATE_IN_GAME),
    IN_GAME(Messages.STATE_IN_GAME),
    END(Messages.STATE_ENDING),
    DISABLED(Messages.STATE_DISABLED);

    private Messages state;

    private GameState(Messages messages) {
        this.state = messages;
    }

    public String getState() {
        return this.state.toString();
    }
}
