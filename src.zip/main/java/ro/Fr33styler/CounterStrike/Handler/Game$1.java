/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  ro.Fr33styler.CounterStrike.Handler.GameState
 */
package ro.Fr33styler.CounterStrike.Handler;

import ro.Fr33styler.CounterStrike.Handler.GameState;

static class Game.1 {
    static final /* synthetic */ int[] $SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState;

    static {
        $SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState = new int[GameState.values().length];
        try {
            Game.1.$SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState[GameState.END.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Game.1.$SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState[GameState.ROUND.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Game.1.$SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState[GameState.WAITING.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Game.1.$SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState[GameState.IN_GAME.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Game.1.$SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState[GameState.DISABLED.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
