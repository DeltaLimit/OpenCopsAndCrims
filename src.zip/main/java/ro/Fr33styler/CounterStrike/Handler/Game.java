/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map$Entry
 *  java.util.UUID
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.block.BlockState
 *  org.bukkit.boss.BarColor
 *  org.bukkit.boss.BarFlag
 *  org.bukkit.boss.BarStyle
 *  org.bukkit.boss.BossBar
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.inventory.Inventory
 *  ro.Fr33styler.CounterStrike.Api.BombExplodeEvent
 *  ro.Fr33styler.CounterStrike.Api.GameStateChangeEvent
 *  ro.Fr33styler.CounterStrike.Cache.Defuse
 *  ro.Fr33styler.CounterStrike.Cache.PlayerShop
 *  ro.Fr33styler.CounterStrike.Cache.PlayerStatus
 *  ro.Fr33styler.CounterStrike.Cache.ShopType
 *  ro.Fr33styler.CounterStrike.Grenades.Grenade
 *  ro.Fr33styler.CounterStrike.Handler.Game$1
 *  ro.Fr33styler.CounterStrike.Handler.GameBomb
 *  ro.Fr33styler.CounterStrike.Handler.GameState
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam$Role
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.Messages
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard
 *  ro.Fr33styler.CounterStrike.Utils.ItemBuilder
 *  ro.Fr33styler.CounterStrike.Version.MathUtils
 *  ro.Fr33styler.CounterStrike.Version.SpigotSound
 */
package ro.Fr33styler.CounterStrike.Handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.BlockState;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.inventory.Inventory;
import ro.Fr33styler.CounterStrike.Api.BombExplodeEvent;
import ro.Fr33styler.CounterStrike.Api.GameStateChangeEvent;
import ro.Fr33styler.CounterStrike.Cache.Defuse;
import ro.Fr33styler.CounterStrike.Cache.PlayerShop;
import ro.Fr33styler.CounterStrike.Cache.PlayerStatus;
import ro.Fr33styler.CounterStrike.Cache.ShopType;
import ro.Fr33styler.CounterStrike.Grenades.Grenade;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameBomb;
import ro.Fr33styler.CounterStrike.Handler.GameState;
import ro.Fr33styler.CounterStrike.Handler.GameTeam;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.Messages;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard;
import ro.Fr33styler.CounterStrike.Utils.ItemBuilder;
import ro.Fr33styler.CounterStrike.Version.MathUtils;
import ro.Fr33styler.CounterStrike.Version.SpigotSound;

public class Game {
    private final int id;
    private int round = 0;
    private final int min;
    private final int max;
    private int timer = 10;
    private BossBar bar;
    private final Main main;
    private GameTeam.Role round_winner;
    private final String name;
    private int scoreTeamA = 0;
    private int scoreTeamB = 0;
    private boolean isGameEnding;
    private final Location lobby;
    private boolean isGameStarted;
    private final Location mid;
    private boolean roundEnding = false;
    private final List<Location> fireworks;
    private GameBomb bomb = new GameBomb();
    private final List<Location> bombsiteLoc;
    private final List<Location> TerroristLoc;
    private GameState state = GameState.WAITING;
    private final List<Location> CounterTerroristLoc;
    private List<Location> signs = new ArrayList();
    private List<Player> spectators = new ArrayList();
    private GameTeam TeamA = new GameTeam((List)new ArrayList());
    private GameTeam TeamB = new GameTeam((List)new ArrayList());
    private List<BlockState> blockrestore = new ArrayList();
    private HashMap<Item, Integer> drops = new HashMap();
    private HashMap<UUID, Integer> money = new HashMap();
    private HashMap<UUID, Inventory> shops = new HashMap();
    private HashMap<Player, Defuse> defusing = new HashMap();
    private HashMap<UUID, ScoreBoard> status = new HashMap();
    private HashMap<String, GameTeam> queue = new HashMap();
    private HashMap<UUID, PlayerStatus> stats = new HashMap();

    public Game(Main main, int n, Location location, String string, int n2, List<Location> list, List<Location> list2, List<Location> list3, List<Location> list4) {
        this.id = n;
        this.min = n2;
        this.main = main;
        this.name = string;
        this.timer = main.getLobbyTime();
        this.CounterTerroristLoc = list;
        this.lobby = location;
        this.bombsiteLoc = list3;
        this.TerroristLoc = list2;
        this.fireworks = list4;
        this.max = list2.size() + list.size();
        this.bar = main.enableBoss() ? Bukkit.createBossBar((String)Messages.BAR_WAITING.toString().replace((CharSequence)"%name%", (CharSequence)string), (BarColor)BarColor.WHITE, (BarStyle)BarStyle.SOLID, (BarFlag[])new BarFlag[0]) : null;
        this.mid = ((Location)list.get(0)).clone().add(((Location)list.get(0)).clone().subtract((Location)list2.get(0)).multiply(0.5));
        if (main.corpseSupport()) {
            // empty if block
        }
    }

    public int getID() {
        return this.id;
    }

    public BossBar getBar() {
        return this.bar;
    }

    public Main getMain() {
        return this.main;
    }

    public Location getLobby() {
        return this.lobby;
    }

    public boolean inQueue(Player player) {
        return this.queue.containsKey((Object)player.getName());
    }

    public String getName() {
        return this.name;
    }

    public int getMinPlayers() {
        return this.min;
    }

    public int getMaxPlayers() {
        return this.max;
    }

    public GameTeam getTeamA() {
        return this.TeamA;
    }

    public GameTeam getTeamB() {
        return this.TeamB;
    }

    public int getTimer() {
        return this.timer;
    }

    public int getRound() {
        return this.round;
    }

    public int getScoreTeamA() {
        return this.scoreTeamA;
    }

    public int getScoreTeamB() {
        return this.scoreTeamB;
    }

    public List<BlockState> restoreBlocks() {
        return this.blockrestore;
    }

    public void setScoreTeamA(int n) {
        this.scoreTeamA = n;
        this.main.getManager().updateTitle(this);
    }

    public void setScoreTeamB(int n) {
        this.scoreTeamB = n;
        this.main.getManager().updateTitle(this);
    }

    public void removeFromQueue(Player player) {
        this.queue.remove((Object)player.getName());
    }

    public List<Location> getFireworks() {
        return this.fireworks;
    }

    public List<Location> getSigns() {
        return this.signs;
    }

    public List<Location> getBombLoc() {
        return this.bombsiteLoc;
    }

    public List<Location> getTerroristLoc() {
        return this.TerroristLoc;
    }

    public List<Location> getCounterTerroristLoc() {
        return this.CounterTerroristLoc;
    }

    public HashMap<Item, Integer> getDrops() {
        return this.drops;
    }

    public List<Player> getSpectators() {
        return this.spectators;
    }

    public void addSign(Location location) {
        this.signs.add((Object)location);
    }

    public GameBomb getBomb() {
        return this.bomb;
    }

    public Location getMid() {
        return this.mid;
    }

    public void setMoney(Player player, int n) {
        this.money.put((Object)player.getUniqueId(), (Object)n);
    }

    public int getMoney(Player player) {
        return (Integer)this.money.get((Object)player.getUniqueId());
    }

    public HashMap<UUID, PlayerStatus> getStats() {
        return this.stats;
    }

    public void addDefuser(Player player, int n) {
        this.defusing.put((Object)player, (Object)new Defuse(n));
    }

    public boolean isDefusing(Player player) {
        return this.defusing.get((Object)player) != null;
    }

    public void resetDefusers() {
        this.defusing.clear();
    }

    public boolean isGameStarted() {
        return this.isGameStarted;
    }

    public boolean isGameEnding() {
        return this.isGameEnding;
    }

    public void isGameEnding(boolean bl) {
        this.isGameEnding = bl;
    }

    public GameState getState() {
        return this.state;
    }

    public boolean isRoundEnding() {
        return this.roundEnding;
    }

    public void setRoundEnding(boolean bl) {
        this.roundEnding = bl;
    }

    public void setGameTimer(int n) {
        this.timer = n;
    }

    public HashMap<UUID, Inventory> getShops() {
        return this.shops;
    }

    public void setRoundWinner(GameTeam.Role role) {
        this.round_winner = role;
    }

    public HashMap<UUID, ScoreBoard> getStatus() {
        return this.status;
    }

    public void setState(GameState gameState) {
        this.state = gameState;
        GameStateChangeEvent gameStateChangeEvent = new GameStateChangeEvent(this, gameState);
        this.main.getServer().getPluginManager().callEvent((Event)gameStateChangeEvent);
        this.main.getManager().updateSigns(this);
        this.main.getManager().updateTitle(this);
        if (this.bar != null) {
            switch (1.$SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState[gameState.ordinal()]) {
                case 1: {
                    this.bar.setTitle("\u00a78[\u00a73" + Messages.TEAM_NAME + " " + Messages.TEAM_FIRST + "\u00a78]\u00a7f " + this.scoreTeamA + "\u00a77 " + Messages.SPLITTER + " \u00a78[\u00a74" + Messages.TEAM_NAME + " " + Messages.TEAM_SECOND + "\u00a78]\u00a7f " + this.scoreTeamB);
                    this.bar.setProgress(1.0);
                    break;
                }
                case 2: {
                    this.bar.setTitle(Messages.BAR_INGAME.toString().replace((CharSequence)"%name%", (CharSequence)this.name).replace((CharSequence)"%timer%", (CharSequence)(this.main.getRoundTime() + "")));
                    this.bar.setProgress(1.0);
                    break;
                }
                case 3: {
                    this.bar.setTitle(Messages.BAR_WAITING.toString().replace((CharSequence)"%name%", (CharSequence)this.name));
                    this.bar.setProgress(1.0);
                    break;
                }
            }
        }
    }

    public void addRandomTeam(Player player) {
        this.TeamA.removePlayer(player);
        this.TeamB.removePlayer(player);
        if (MathUtils.random().nextBoolean()) {
            this.TeamA.addPlayer(player);
        } else {
            this.TeamB.addPlayer(player);
        }
    }

    public void addTeamA(Player player) {
        this.TeamB.removePlayer(player);
        this.TeamA.removePlayer(player);
        this.TeamA.addPlayer(player);
    }

    public void addTeamB(Player player) {
        this.TeamB.removePlayer(player);
        this.TeamA.removePlayer(player);
        this.TeamB.addPlayer(player);
    }

    public void start() {
        this.isGameStarted = true;
        if (MathUtils.random().nextBoolean()) {
            this.TeamA.setRole(GameTeam.Role.COUNTERTERRORIST);
            this.TeamB.setRole(GameTeam.Role.TERRORIST);
        } else {
            this.TeamA.setRole(GameTeam.Role.TERRORIST);
            this.TeamB.setRole(GameTeam.Role.COUNTERTERRORIST);
        }
    }

    public void addinQueue(Player player) {
        if (this.TeamA.size() <= this.TeamB.size()) {
            this.queue.put((Object)player.getName(), (Object)this.TeamA);
            player.teleport(this.TeamA.getPlayer(MathUtils.random().nextInt(this.TeamA.size())).getLocation());
            this.TeamA.addPlayer(player);
        } else {
            this.queue.put((Object)player.getName(), (Object)this.TeamB);
            player.teleport(this.TeamB.getPlayer(MathUtils.random().nextInt(this.TeamB.size())).getLocation());
            this.TeamB.addPlayer(player);
        }
        this.spectators.add((Object)player);
        this.stats.put((Object)player.getUniqueId(), (Object)new PlayerStatus(player.getName(), player.getUniqueId()));
    }

    public void broadcast(String string) {
        for (Player player : this.TeamA.getPlayers()) {
            player.sendMessage(string.replace((CharSequence)"&", (CharSequence)"\u00a7"));
        }
        for (Player player : this.TeamB.getPlayers()) {
            player.sendMessage(string.replace((CharSequence)"&", (CharSequence)"\u00a7"));
        }
    }

    public void stop() {
        this.round = 0;
        this.setScoreTeamA(0);
        this.setScoreTeamB(0);
        this.TeamA.setRole(null);
        this.TeamB.setRole(null);
        this.isGameStarted = false;
    }

    public void run() {
        if (this.isGameStarted) {
            switch (1.$SwitchMap$ro$Fr33styler$CounterStrike$Handler$GameState[this.state.ordinal()]) {
                case 1: {
                    if (this.timer != 0) break;
                    this.main.getManager().stopGame(this, this.main.autoJoin());
                    if (!this.main.shutdown()) break;
                    this.main.getServer().shutdown();
                    break;
                }
                case 4: {
                    String string;
                    String string22;
                    Player player4;
                    Iterator iterator2;
                    if (this.bar != null && !this.roundEnding) {
                        this.bar.setTitle(Messages.BAR_INGAME.toString().replace((CharSequence)"%name%", (CharSequence)this.name).replace((CharSequence)"%timer%", (CharSequence)(this.timer + "")));
                        this.bar.setProgress(this.bomb.isPlanted() ? (double)(this.timer / 45) : (double)this.timer / (double)this.main.getRoundTime());
                    }
                    if (this.timer == 90) {
                        for (Player player2 : this.TeamA.getPlayers()) {
                            if (player2.getOpenInventory() == null || !player2.getOpenInventory().getTitle().equals((Object)Messages.ITEM_SHOP_NAME.toString())) continue;
                            player2.closeInventory();
                            player2.sendMessage(Messages.SHOP_AFTER_30_SECONDS.toString());
                        }
                        for (Player player2 : this.TeamB.getPlayers()) {
                            if (player2.getOpenInventory() == null || !player2.getOpenInventory().getTitle().equals((Object)Messages.ITEM_SHOP_NAME.toString())) continue;
                            player2.closeInventory();
                            player2.sendMessage(Messages.SHOP_AFTER_30_SECONDS.toString());
                        }
                    }
                    if (this.timer == 30) {
                        for (Player player2 : this.TeamA.getPlayers()) {
                            player2.playSound(player2.getLocation(), "cs.gamesounds.secondsremain", 1.0f, 1.0f);
                        }
                        for (Player player2 : this.TeamB.getPlayers()) {
                            player2.playSound(player2.getLocation(), "cs.gamesounds.secondsremain", 1.0f, 1.0f);
                        }
                    }
                    for (Player player2 : this.spectators) {
                        if (this.timer % 4 == 0) {
                            this.main.getVersionInterface().sendActionBar(player2, Messages.BAR_RESPAWN_SECOND.toString());
                            continue;
                        }
                        if (this.timer % 2 != 0) continue;
                        this.main.getVersionInterface().sendActionBar(player2, Messages.BAR_RESPAWN_FIRST.toString());
                    }
                    if (this.bomb.isPlanted()) {
                        Player player2;
                        this.bomb.setTimer(this.bomb.getTimer() - 1);
                        int n = this.bomb.getTimer();
                        if (n % 4 == 0) {
                            for (Iterator iterator2 : this.main.getManager().getTeam(this, GameTeam.Role.TERRORIST).getPlayers()) {
                                if (this.spectators.contains((Object)iterator2)) continue;
                                this.main.getVersionInterface().sendActionBar((Player)iterator2, Messages.BAR_BOMB_PLANTED_CRIMS_SECOND.toString());
                            }
                            for (Iterator iterator2 : this.main.getManager().getTeam(this, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                                if (this.spectators.contains((Object)iterator2)) continue;
                                this.main.getVersionInterface().sendActionBar((Player)iterator2, Messages.BAR_BOMB_PLANTED_COPS_SECOND.toString());
                            }
                        } else if (n % 2 == 0) {
                            for (Iterator iterator2 : this.main.getManager().getTeam(this, GameTeam.Role.TERRORIST).getPlayers()) {
                                if (this.spectators.contains((Object)iterator2)) continue;
                                this.main.getVersionInterface().sendActionBar((Player)iterator2, Messages.BAR_BOMB_PLANTED_CRIMS_FIRST.toString());
                            }
                            for (Iterator iterator2 : this.main.getManager().getTeam(this, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                                if (this.spectators.contains((Object)iterator2)) continue;
                                this.main.getVersionInterface().sendActionBar((Player)iterator2, Messages.BAR_BOMB_PLANTED_COPS_FIRST.toString());
                            }
                        }
                        if (n > 0 && (n <= 10 || n % 2 == 0)) {
                            for (Iterator iterator2 : this.TeamA.getPlayers()) {
                                iterator2.playSound(this.bomb.getLocation(), "cs.gamesounds.bombbeep", 1.0f, 1.0f);
                            }
                            for (Iterator iterator2 : this.TeamB.getPlayers()) {
                                iterator2.playSound(this.bomb.getLocation(), "cs.gamesounds.bombbeep", 1.0f, 1.0f);
                            }
                        }
                        if (n >= 0 && n <= 5) {
                            for (Iterator iterator2 : this.TeamA.getPlayers()) {
                                if (this.defusing.containsKey((Object)iterator2)) continue;
                                this.main.getVersionInterface().sendTitle((Player)iterator2, 0, 23, 0, "", "\u00a7c" + n);
                            }
                            for (Iterator iterator2 : this.TeamB.getPlayers()) {
                                if (this.defusing.containsKey((Object)iterator2)) continue;
                                this.main.getVersionInterface().sendTitle((Player)iterator2, 0, 23, 0, "", "\u00a7c" + n);
                            }
                        }
                        player2 = this.defusing.entrySet().iterator();
                        while (player2.hasNext()) {
                            int n2;
                            iterator2 = (Map.Entry)player2.next();
                            player4 = (Player)iterator2.getKey();
                            if (this.spectators.contains(iterator2.getKey()) || !this.isGameStarted) {
                                player2.remove();
                                break;
                            }
                            if (player4.getLocation().distance(this.bomb.getLocation()) > 2.0) {
                                this.main.getVersionInterface().sendTitle(player4, 0, 40, 0, "", Messages.BOMB_DEFUSING_CANCELED.toString());
                                player2.remove();
                                break;
                            }
                            string22 = "\u00a7a";
                            string = "\u00a77";
                            for (n2 = 0; n2 < ((Defuse)iterator2.getValue()).getMax() - ((Defuse)iterator2.getValue()).getTime(); ++n2) {
                                string22 = string22 + '\u2503';
                            }
                            for (n2 = 0; n2 < ((Defuse)iterator2.getValue()).getTime(); ++n2) {
                                string = string + '\u2503';
                            }
                            this.main.getVersionInterface().sendTitle(player4, 0, 40, 0, Messages.BOMB_DEFUSING.toString(), "\u00a78[" + string22 + string + "\u00a78] \u00a7c" + ((Defuse)iterator2.getValue()).getTime());
                            if (((Defuse)iterator2.getValue()).getTime() == -1 && !this.roundEnding) {
                                PlayerStatus playerStatus;
                                PlayerStatus playerStatus2;
                                ++this.round;
                                for (Player player3 : this.TeamA.getPlayers()) {
                                    player3.playSound(player3.getLocation(), "cs.gamesounds.bombdefused", 1.0f, 1.0f);
                                    this.main.getVersionInterface().sendTitle(player3, 0, 60, 0, Messages.BOMB_DEFUSED.toString(), "\u00a7f\u927b \u00a73" + player4.getName());
                                    player3.sendMessage(Messages.LINE_SPLITTER.toString());
                                    player3.sendMessage(Messages.LINE_PREFIX.toString());
                                    player3.sendMessage("");
                                    player3.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_WINNER_COP);
                                    playerStatus2 = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                                    player3.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)playerStatus2.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + playerStatus2.getRoundKills())));
                                    playerStatus = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                                    player3.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)playerStatus.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + playerStatus.getRoundKills())));
                                    player3.sendMessage(Messages.LINE_SPLITTER.toString());
                                }
                                for (Player player3 : this.TeamB.getPlayers()) {
                                    player3.playSound(player3.getLocation(), "cs.gamesounds.bombdefused", 1.0f, 1.0f);
                                    this.main.getVersionInterface().sendTitle(player3, 0, 60, 0, Messages.BOMB_DEFUSED.toString(), "\u00a7f\u927b \u00a73" + player4.getName());
                                    player3.sendMessage(Messages.LINE_SPLITTER.toString());
                                    player3.sendMessage(Messages.LINE_PREFIX.toString());
                                    player3.sendMessage("");
                                    player3.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_WINNER_COP);
                                    playerStatus2 = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                                    player3.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)playerStatus2.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + playerStatus2.getRoundKills())));
                                    playerStatus = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                                    player3.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)playerStatus.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + playerStatus.getRoundKills())));
                                    player3.sendMessage(Messages.LINE_SPLITTER.toString());
                                }
                                this.timer = 8;
                                this.round_winner = GameTeam.Role.COUNTERTERRORIST;
                                if (this.TeamA.getRole() == GameTeam.Role.COUNTERTERRORIST) {
                                    this.setScoreTeamA(this.scoreTeamA + 1);
                                } else {
                                    this.setScoreTeamB(this.scoreTeamB + 1);
                                }
                                player2.remove();
                                this.bomb.reset();
                                for (Player player3 : this.main.getGrenades()) {
                                    player3.remove(this);
                                }
                                this.roundEnding = true;
                                break;
                            }
                            ((Defuse)iterator2.getValue()).setTime(((Defuse)iterator2.getValue()).getTime() - 1);
                        }
                        if (n == 0 && this.bomb.isPlanted()) {
                            ++this.round;
                            this.timer = 8;
                            this.round_winner = GameTeam.Role.TERRORIST;
                            if (this.TeamA.getRole() == GameTeam.Role.TERRORIST) {
                                this.setScoreTeamA(this.scoreTeamA + 1);
                            } else {
                                this.setScoreTeamB(this.scoreTeamB + 1);
                            }
                            this.bomb.getLocation().getBlock().setType(Material.AIR);
                            iterator2 = new BombExplodeEvent(this.bomb.getLocation());
                            this.main.getServer().getPluginManager().callEvent((Event)iterator2);
                            this.bomb.getLocation().getWorld().playSound(this.bomb.getLocation(), SpigotSound.EXPLODE.getSound(), 5.0f, 5.0f);
                            this.bomb.getLocation().getWorld().spawnParticle(Particle.EXPLOSION_LARGE, this.bomb.getLocation(), 5);
                            for (String string22 : this.bomb.getNearbyPlayers(this, 15)) {
                                if (this.spectators.contains((Object)string22)) continue;
                                this.main.getManager().damage(this, null, (Player)string22, 20.0, "\u9276");
                            }
                            if (!this.roundEnding) {
                                for (String string22 : this.TeamA.getPlayers()) {
                                    string22.playSound(this.bomb.getLocation(), "cs.gamesounds.wilhelm", 1.0f, 1.0f);
                                    string22.sendMessage(Messages.LINE_SPLITTER.toString());
                                    string22.sendMessage(Messages.LINE_PREFIX.toString());
                                    string22.sendMessage("");
                                    string22.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_WINNER_CRIMS);
                                    string = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                                    string22.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)string.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + string.getRoundKills())));
                                    PlayerStatus playerStatus = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                                    string22.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)playerStatus.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + playerStatus.getRoundKills())));
                                    string22.sendMessage(Messages.LINE_SPLITTER.toString());
                                }
                                for (String string22 : this.TeamB.getPlayers()) {
                                    string22.playSound(this.bomb.getLocation(), "cs.gamesounds.wilhelm", 1.0f, 1.0f);
                                    string22.sendMessage(Messages.LINE_SPLITTER.toString());
                                    string22.sendMessage(Messages.LINE_PREFIX.toString());
                                    string22.sendMessage("");
                                    string22.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_WINNER_CRIMS);
                                    string = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                                    string22.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)string.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + string.getRoundKills())));
                                    PlayerStatus playerStatus = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                                    string22.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)playerStatus.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + playerStatus.getRoundKills())));
                                    string22.sendMessage(Messages.LINE_SPLITTER.toString());
                                }
                            }
                            this.bomb.reset();
                            this.roundEnding = true;
                        }
                    }
                    if (this.roundEnding) {
                        if (this.main.getRoundToWin() <= this.scoreTeamA || this.main.getRoundToWin() <= this.scoreTeamB) {
                            this.timer = 10;
                            this.setState(GameState.END);
                            String string3 = this.scoreTeamA > this.scoreTeamB ? Messages.TEAM_NAME.toString().replace((CharSequence)":", (CharSequence)"") + " " + Messages.TEAM_FIRST : Messages.TEAM_NAME.toString().replace((CharSequence)":", (CharSequence)"") + " " + Messages.TEAM_SECOND;
                            for (Iterator iterator2 : this.TeamA.getPlayers()) {
                                if (!this.spectators.contains((Object)iterator2)) {
                                    this.main.getManager().clearPlayer((Player)iterator2);
                                }
                                if (this.scoreTeamA > this.scoreTeamB) {
                                    if (this.main.getEndGameCommandWin() != null && !this.main.getEndGameCommandWin().equalsIgnoreCase("none")) {
                                        Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)this.main.getEndGameCommandWin().replace((CharSequence)"%player%", (CharSequence)iterator2.getName()));
                                    }
                                } else if (this.main.getEndGameCommandLose() != null && !this.main.getEndGameCommandLose().equalsIgnoreCase("none")) {
                                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)this.main.getEndGameCommandLose().replace((CharSequence)"%player%", (CharSequence)iterator2.getName()));
                                }
                                iterator2.sendMessage(Messages.LINE_SPLITTER.toString());
                                iterator2.sendMessage(Messages.LINE_PREFIX.toString());
                                iterator2.sendMessage("");
                                iterator2.sendMessage("\u27a2 \u00a7e" + Messages.WINNER.toString() + "\u00a7f: \u00a7c" + string3);
                                iterator2.sendMessage(Messages.LINE_SPLITTER.toString());
                                this.main.getVersionInterface().sendTitle((Player)iterator2, 0, 200, 0, Messages.TITLE_GAME_OVER.toString(), "\u00a78[\u00a73" + Messages.TEAM_NAME + " " + Messages.TEAM_FIRST + "\u00a78]\u00a7f " + this.scoreTeamA + "\u00a77 " + Messages.SPLITTER + " \u00a78[\u00a74" + Messages.TEAM_NAME + " " + Messages.TEAM_SECOND + "\u00a78]\u00a7f " + this.scoreTeamB);
                            }
                            for (Iterator iterator2 : this.TeamB.getPlayers()) {
                                if (!this.spectators.contains((Object)iterator2)) {
                                    this.main.getManager().clearPlayer((Player)iterator2);
                                }
                                if (this.scoreTeamB > this.scoreTeamA) {
                                    if (this.main.getEndGameCommandWin() != null && !this.main.getEndGameCommandWin().equalsIgnoreCase("none")) {
                                        Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)this.main.getEndGameCommandWin().replace((CharSequence)"%player%", (CharSequence)iterator2.getName()));
                                    }
                                } else if (this.main.getEndGameCommandLose() != null && !this.main.getEndGameCommandLose().equalsIgnoreCase("none")) {
                                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)this.main.getEndGameCommandLose().replace((CharSequence)"%player%", (CharSequence)iterator2.getName()));
                                }
                                iterator2.sendMessage(Messages.LINE_SPLITTER.toString());
                                iterator2.sendMessage(Messages.LINE_PREFIX.toString());
                                iterator2.sendMessage("");
                                iterator2.sendMessage("\u27a2 \u00a7e" + Messages.WINNER.toString() + "\u00a7f: \u00a7c" + string3);
                                iterator2.sendMessage(Messages.LINE_SPLITTER.toString());
                                this.main.getVersionInterface().sendTitle((Player)iterator2, 0, 200, 0, Messages.TITLE_GAME_OVER.toString(), "\u00a78[\u00a73" + Messages.TEAM_NAME + " " + Messages.TEAM_FIRST + "\u00a78]\u00a7f " + this.scoreTeamA + "\u00a77 " + Messages.SPLITTER + " \u00a78[\u00a74" + Messages.TEAM_NAME + " " + Messages.TEAM_SECOND + "\u00a78]\u00a7f " + this.scoreTeamB);
                            }
                            this.main.getManager().endRound(this);
                            break;
                        }
                        if (this.timer != 0) break;
                        this.timer = 11;
                        if (this.round == this.main.getRoundToSwitch()) {
                            this.timer = 16;
                            if (this.TeamA.getRole() == GameTeam.Role.TERRORIST) {
                                this.TeamB.setRole(GameTeam.Role.TERRORIST);
                                this.TeamA.setRole(GameTeam.Role.COUNTERTERRORIST);
                            } else {
                                this.TeamA.setRole(GameTeam.Role.TERRORIST);
                                this.TeamB.setRole(GameTeam.Role.COUNTERTERRORIST);
                            }
                            for (Player player2 : this.status.values()) {
                                player2.removeTeam();
                                player2.showTeams(this);
                            }
                            for (Player player2 : this.main.getManager().getTeam(this, GameTeam.Role.TERRORIST).getPlayers()) {
                                iterator2 = (Inventory)this.shops.get((Object)player2.getUniqueId());
                                iterator2.clear();
                                for (String string22 : this.main.getShops()) {
                                    if (string22.getType() == ShopType.GRENADE) {
                                        string = this.main.getGrenade(string22.getWeaponName());
                                        iterator2.setItem(string22.getSlot(), ItemBuilder.create((Material)string.getItem().getType(), (int)1, (int)string.getItem().getData(), (String)string22.getName().replace('&', '\u00a7'), (String)string22.getLore()));
                                        continue;
                                    }
                                    if (string22.getType() == ShopType.GUN && (string22.getRole() == null || string22.getRole() == GameTeam.Role.TERRORIST)) {
                                        if (this.main.hideVipGuns() && string22.hasPermission() && !player2.hasPermission("cs.weapon." + string22.getWeaponName())) continue;
                                        string = this.main.getGun(string22.getWeaponName());
                                        iterator2.setItem(string22.getSlot(), ItemBuilder.create((Material)string.getItem().getType(), (int)1, (int)string.getItem().getData(), (String)string22.getName().replace('&', '\u00a7'), (String)string22.getLore()));
                                        continue;
                                    }
                                    if (string22.getRole() != null && string22.getRole() != GameTeam.Role.TERRORIST) continue;
                                    iterator2.setItem(string22.getSlot(), ItemBuilder.create((Material)string22.getMaterial(), (Integer)1, (String)string22.getName().replace('&', '\u00a7'), (String)string22.getLore()));
                                }
                            }
                            for (Player player2 : this.main.getManager().getTeam(this, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                                iterator2 = (Inventory)this.shops.get((Object)player2.getUniqueId());
                                iterator2.clear();
                                for (String string22 : this.main.getShops()) {
                                    if (string22.getType() == ShopType.GRENADE) {
                                        string = this.main.getGrenade(string22.getWeaponName());
                                        iterator2.setItem(string22.getSlot(), ItemBuilder.create((Material)string.getItem().getType(), (int)1, (int)string.getItem().getData(), (String)string22.getName().replace('&', '\u00a7'), (String)string22.getLore()));
                                        continue;
                                    }
                                    if (string22.getType() == ShopType.GUN && (string22.getRole() == null || string22.getRole() == GameTeam.Role.COUNTERTERRORIST)) {
                                        if (this.main.hideVipGuns() && string22.hasPermission() && !player2.hasPermission("cs.weapon." + string22.getWeaponName())) continue;
                                        string = this.main.getGun(string22.getWeaponName());
                                        iterator2.setItem(string22.getSlot(), ItemBuilder.create((Material)string.getItem().getType(), (int)1, (int)string.getItem().getData(), (String)string22.getName().replace('&', '\u00a7'), (String)string22.getLore()));
                                        continue;
                                    }
                                    if (string22.getRole() != null && string22.getRole() != GameTeam.Role.COUNTERTERRORIST) continue;
                                    iterator2.setItem(string22.getSlot(), ItemBuilder.create((Material)string22.getMaterial(), (Integer)1, (String)string22.getName().replace('&', '\u00a7'), (String)string22.getLore()));
                                }
                            }
                        } else {
                            this.timer = 11;
                            if (this.round_winner == this.TeamA.getRole()) {
                                for (Player player2 : this.TeamA.getPlayers()) {
                                    this.setMoney(player2, this.getMoney(player2) + this.main.getRoundWinMoney());
                                }
                                for (Player player2 : this.TeamB.getPlayers()) {
                                    this.setMoney(player2, this.getMoney(player2) + this.main.getRoundLoseMoney());
                                }
                            } else if (this.round_winner == this.TeamB.getRole()) {
                                for (Player player2 : this.TeamB.getPlayers()) {
                                    this.setMoney(player2, this.getMoney(player2) + this.main.getRoundWinMoney());
                                }
                                for (Player player2 : this.TeamA.getPlayers()) {
                                    this.setMoney(player2, this.getMoney(player2) + this.main.getRoundLoseMoney());
                                }
                            }
                        }
                        for (Player player2 : this.TeamA.getPlayers()) {
                            if (this.queue.size() <= 0) continue;
                            player2.sendMessage(Messages.NEW_COMBATANTS.toString());
                            for (Player player4 : this.queue.entrySet()) {
                                string22 = ((GameTeam)player4.getValue()).getRole() == GameTeam.Role.TERRORIST ? "\u00a74\u9291" : "\u00a73\u9290";
                                player2.sendMessage(string22 + " " + (String)player4.getKey());
                            }
                        }
                        for (Player player2 : this.TeamB.getPlayers()) {
                            if (this.queue.size() <= 0) continue;
                            player2.sendMessage(Messages.NEW_COMBATANTS.toString());
                            for (Player player4 : this.queue.entrySet()) {
                                string22 = ((GameTeam)player4.getValue()).getRole() == GameTeam.Role.TERRORIST ? "\u00a74\u9291" : "\u00a73\u9290";
                                player2.sendMessage(string22 + " " + (String)player4.getKey());
                            }
                        }
                        this.queue.clear();
                        this.setState(GameState.ROUND);
                        this.main.getManager().endRound(this);
                        this.main.getManager().resetPlayers(this);
                        break;
                    }
                    if (!this.bomb.isPlanted()) {
                        for (Player player2 : this.main.getManager().getTeam(this, GameTeam.Role.TERRORIST).getPlayers()) {
                            if (this.bomb.getCarrier() == player2) {
                                player2.setCompassTarget(this.bomb.getLocation());
                                this.main.getVersionInterface().sendActionBar(player2, Messages.BAR_BOMB_PLANT.toString());
                                continue;
                            }
                            if (this.spectators.contains((Object)player2)) continue;
                            player2.setCompassTarget(this.bomb.getLocation());
                            this.main.getVersionInterface().sendActionBar(player2, Messages.BAR_BOMB_PROTECTOR.toString());
                        }
                        for (Player player2 : this.main.getManager().getTeam(this, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                            if (this.spectators.contains((Object)player2)) continue;
                            this.main.getVersionInterface().sendActionBar(player2, Messages.BAR_BOMB_DEFEND.toString());
                        }
                    }
                    if (this.spectators.containsAll((Collection)this.main.getManager().getTeam(this, GameTeam.Role.COUNTERTERRORIST).getPlayers())) {
                        for (Player player2 : this.TeamA.getPlayers()) {
                            player2.sendMessage(Messages.LINE_SPLITTER.toString());
                            player2.sendMessage(Messages.LINE_PREFIX.toString());
                            player2.sendMessage("");
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_WINNER_CRIMS);
                            player2.playSound(player2.getLocation(), "cs.gamesounds.criminalswinthegame", 1.0f, 1.0f);
                            iterator2 = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)iterator2.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + iterator2.getRoundKills())));
                            player4 = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)player4.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + player4.getRoundKills())));
                            player2.sendMessage(Messages.LINE_SPLITTER.toString());
                        }
                        for (Player player2 : this.TeamB.getPlayers()) {
                            player2.sendMessage(Messages.LINE_SPLITTER.toString());
                            player2.sendMessage(Messages.LINE_PREFIX.toString());
                            player2.sendMessage("");
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_WINNER_CRIMS);
                            player2.playSound(player2.getLocation(), "cs.gamesounds.criminalswinthegame", 1.0f, 1.0f);
                            iterator2 = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)iterator2.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + iterator2.getRoundKills())));
                            player4 = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)player4.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + player4.getRoundKills())));
                            player2.sendMessage(Messages.LINE_SPLITTER.toString());
                        }
                        ++this.round;
                        this.timer = 8;
                        this.round_winner = GameTeam.Role.TERRORIST;
                        if (this.TeamA.getRole() == GameTeam.Role.TERRORIST) {
                            this.setScoreTeamA(this.scoreTeamA + 1);
                        } else {
                            this.setScoreTeamB(this.scoreTeamB + 1);
                        }
                        for (Player player2 : this.main.getGrenades()) {
                            player2.remove(this);
                        }
                        this.roundEnding = true;
                        break;
                    }
                    if (this.spectators.containsAll((Collection)this.main.getManager().getTeam(this, GameTeam.Role.TERRORIST).getPlayers()) && !this.bomb.isPlanted()) {
                        ++this.round;
                        for (Player player2 : this.TeamA.getPlayers()) {
                            player2.sendMessage(Messages.LINE_SPLITTER.toString());
                            player2.sendMessage(Messages.LINE_PREFIX.toString());
                            player2.sendMessage("");
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_WINNER_COP);
                            player2.playSound(player2.getLocation(), "cs.gamesounds.copswinthegame", 1.0f, 1.0f);
                            iterator2 = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)iterator2.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + iterator2.getRoundKills())));
                            player4 = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)player4.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + player4.getRoundKills())));
                            player2.sendMessage(Messages.LINE_SPLITTER.toString());
                        }
                        for (Player player2 : this.TeamB.getPlayers()) {
                            player2.sendMessage(Messages.LINE_SPLITTER.toString());
                            player2.sendMessage(Messages.LINE_PREFIX.toString());
                            player2.sendMessage("");
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_WINNER_COP);
                            player2.playSound(player2.getLocation(), "cs.gamesounds.copswinthegame", 1.0f, 1.0f);
                            iterator2 = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)iterator2.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + iterator2.getRoundKills())));
                            player4 = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                            player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)player4.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + player4.getRoundKills())));
                            player2.sendMessage(Messages.LINE_SPLITTER.toString());
                        }
                        this.timer = 8;
                        this.round_winner = GameTeam.Role.COUNTERTERRORIST;
                        if (this.TeamA.getRole() == GameTeam.Role.COUNTERTERRORIST) {
                            this.setScoreTeamA(this.scoreTeamA + 1);
                        } else {
                            this.setScoreTeamB(this.scoreTeamB + 1);
                        }
                        for (Player player2 : this.main.getGrenades()) {
                            player2.remove(this);
                        }
                        this.roundEnding = true;
                        break;
                    }
                    if (this.timer != 0) break;
                    ++this.round;
                    for (Player player2 : this.TeamA.getPlayers()) {
                        player2.sendMessage(Messages.LINE_SPLITTER.toString());
                        player2.sendMessage(Messages.LINE_PREFIX.toString());
                        player2.sendMessage("");
                        iterator2 = Messages.WINNER_TIMES_OUT.toString().split("#");
                        for (Player player5 : iterator2) {
                            player2.sendMessage(Messages.GAME_MARKER.toString() + (String)player5);
                        }
                        player2.playSound(player2.getLocation(), "cs.gamesounds.copswinthegame", 1.0f, 1.0f);
                        player4 = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                        player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)player4.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + player4.getRoundKills())));
                        string22 = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                        player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)string22.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + string22.getRoundKills())));
                        player2.sendMessage(Messages.LINE_SPLITTER.toString());
                    }
                    for (Player player2 : this.TeamB.getPlayers()) {
                        player2.sendMessage(Messages.LINE_SPLITTER.toString());
                        player2.sendMessage(Messages.LINE_PREFIX.toString());
                        player2.sendMessage("");
                        iterator2 = Messages.WINNER_TIMES_OUT.toString().split("#");
                        for (Player player6 : iterator2) {
                            player2.sendMessage(Messages.GAME_MARKER.toString() + (String)player6);
                        }
                        player2.playSound(player2.getLocation(), "cs.gamesounds.copswinthegame", 1.0f, 1.0f);
                        player4 = this.main.getManager().getTop(this, GameTeam.Role.COUNTERTERRORIST);
                        player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_TOP_COP.toString().replace((CharSequence)"%player%", (CharSequence)player4.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + player4.getRoundKills())));
                        string22 = this.main.getManager().getTop(this, GameTeam.Role.TERRORIST);
                        player2.sendMessage(Messages.GAME_MARKER.toString() + Messages.ROUND_MOST_WANTED.toString().replace((CharSequence)"%player%", (CharSequence)string22.getName()).replace((CharSequence)"%kills%", (CharSequence)("" + string22.getRoundKills())));
                        player2.sendMessage(Messages.LINE_SPLITTER.toString());
                    }
                    this.timer = 8;
                    this.round_winner = GameTeam.Role.COUNTERTERRORIST;
                    if (this.TeamA.getRole() == GameTeam.Role.COUNTERTERRORIST) {
                        this.setScoreTeamA(this.scoreTeamA + 1);
                    } else {
                        this.setScoreTeamB(this.scoreTeamB + 1);
                    }
                    for (Player player2 : this.main.getGrenades()) {
                        player2.remove(this);
                    }
                    this.roundEnding = true;
                    break;
                }
                case 2: {
                    if (this.round == this.main.getRoundToSwitch() && this.timer >= 11) {
                        for (Player player : this.main.getManager().getTeam(this, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                            this.main.getVersionInterface().sendTitle(player, 0, 40, 0, Messages.TEAM_SWAP.toString(), Messages.TEAM_SWAP_COPS.toString());
                        }
                        for (Player player : this.main.getManager().getTeam(this, GameTeam.Role.TERRORIST).getPlayers()) {
                            this.main.getVersionInterface().sendTitle(player, 0, 40, 0, Messages.TEAM_SWAP.toString(), Messages.TEAM_SWAP_CRIMS.toString());
                        }
                    } else if (this.timer >= 11) {
                        for (Player player : this.TeamA.getPlayers()) {
                            this.main.getVersionInterface().sendTitle(player, 0, 40, 0, Messages.PREFIX.toString(), Messages.ROUND_FIRST.toString());
                        }
                        for (Player player : this.TeamB.getPlayers()) {
                            this.main.getVersionInterface().sendTitle(player, 0, 40, 0, Messages.PREFIX.toString(), Messages.ROUND_FIRST.toString());
                        }
                    } else {
                        if (this.timer == 0) {
                            for (Player player : this.TeamA.getPlayers()) {
                                this.main.getVersionInterface().sendTitle(player, 0, 30, 0, Messages.ROUND_START.toString(), Messages.OPEN_SHOP.toString());
                                player.playSound(player.getLocation(), "cs.gamesounds.roundstart", 1.0f, 1.0f);
                            }
                            for (Player player : this.TeamB.getPlayers()) {
                                this.main.getVersionInterface().sendTitle(player, 0, 30, 0, Messages.ROUND_START.toString(), Messages.OPEN_SHOP.toString());
                                player.playSound(player.getLocation(), "cs.gamesounds.roundstart", 1.0f, 1.0f);
                            }
                            this.timer = this.main.getRoundTime();
                            this.setState(GameState.IN_GAME);
                            break;
                        }
                        String string = this.timer >= 7 ? "\u00a7a" + this.timer : (this.timer < 7 && this.timer >= 4 ? "\u00a7e" + this.timer : "\u00a7c" + this.timer);
                        for (Player player : this.TeamA.getPlayers()) {
                            this.main.getVersionInterface().sendTitle(player, 0, 30, 0, string, Messages.OPEN_SHOP.toString());
                        }
                        for (Player player : this.TeamB.getPlayers()) {
                            this.main.getVersionInterface().sendTitle(player, 0, 30, 0, string, Messages.OPEN_SHOP.toString());
                        }
                    }
                    break;
                }
                case 3: {
                    if (this.TeamA.getPlayers().size() + this.TeamB.getPlayers().size() < this.min) {
                        this.stop();
                        for (Player player : this.TeamA.getPlayers()) {
                            player.sendMessage(Messages.PREFIX + Messages.NOT_ENOUGH_PLAYERS.toString());
                        }
                        for (Player player : this.TeamB.getPlayers()) {
                            player.sendMessage(Messages.PREFIX + Messages.NOT_ENOUGH_PLAYERS.toString());
                        }
                        this.timer = this.main.getLobbyTime();
                        for (Player player : this.status.values()) {
                            this.main.getManager().updateStatus(this, player.getStatus());
                        }
                    } else {
                        if (this.timer == 0) {
                            Grenade grenade;
                            Inventory inventory;
                            while (true) {
                                Player player;
                                if (this.TeamA.size() <= this.max / 2 && this.TeamB.size() <= this.max / 2) {
                                    if (MathUtils.abs((int)(this.TeamA.size() - this.TeamB.size())) <= 1) break;
                                    if (this.TeamA.size() < this.TeamB.size()) {
                                        player = this.TeamB.getPlayer(MathUtils.random().nextInt(this.TeamB.size()));
                                        this.TeamB.removePlayer(player);
                                        this.TeamA.addPlayer(player);
                                        continue;
                                    }
                                    if (this.TeamB.size() >= this.TeamA.size()) continue;
                                    player = this.TeamA.getPlayer(MathUtils.random().nextInt(this.TeamA.size()));
                                    this.TeamA.removePlayer(player);
                                    this.TeamB.addPlayer(player);
                                    continue;
                                }
                                if (this.TeamA.size() > this.max / 2) {
                                    player = this.TeamA.getPlayer(MathUtils.random().nextInt(this.TeamA.size()));
                                    this.TeamA.removePlayer(player);
                                    this.TeamB.addPlayer(player);
                                    continue;
                                }
                                if (this.TeamB.size() <= this.max / 2) continue;
                                player = this.TeamB.getPlayer(MathUtils.random().nextInt(this.TeamB.size()));
                                this.TeamB.removePlayer(player);
                                this.TeamA.addPlayer(player);
                            }
                            for (Player player : this.main.getManager().getTeam(this, GameTeam.Role.TERRORIST).getPlayers()) {
                                inventory = Bukkit.createInventory(null, (int)54, (String)Messages.ITEM_SHOP_NAME.toString());
                                for (PlayerShop playerShop : this.main.getShops()) {
                                    if (playerShop.getType() == ShopType.GRENADE) {
                                        grenade = this.main.getGrenade(playerShop.getWeaponName());
                                        inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)grenade.getItem().getType(), (int)1, (int)grenade.getItem().getData(), (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
                                        continue;
                                    }
                                    if (playerShop.getType() == ShopType.GUN && (playerShop.getRole() == null || playerShop.getRole() == GameTeam.Role.TERRORIST)) {
                                        if (this.main.hideVipGuns() && playerShop.hasPermission() && !player.hasPermission("cs.weapon." + playerShop.getWeaponName())) continue;
                                        grenade = this.main.getGun(playerShop.getWeaponName());
                                        inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)grenade.getItem().getType(), (int)1, (int)grenade.getItem().getData(), (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
                                        continue;
                                    }
                                    if (playerShop.getRole() != null && playerShop.getRole() != GameTeam.Role.TERRORIST) continue;
                                    inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)playerShop.getMaterial(), (Integer)1, (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
                                }
                                this.shops.put((Object)player.getUniqueId(), (Object)inventory);
                                ((ScoreBoard)this.status.get((Object)player.getUniqueId())).showTeams(this);
                                ((ScoreBoard)this.status.get((Object)player.getUniqueId())).showHealth(this);
                            }
                            for (Player player : this.main.getManager().getTeam(this, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                                inventory = Bukkit.createInventory(null, (int)54, (String)Messages.ITEM_SHOP_NAME.toString());
                                for (PlayerShop playerShop : this.main.getShops()) {
                                    if (playerShop.getType() == ShopType.GRENADE) {
                                        grenade = this.main.getGrenade(playerShop.getWeaponName());
                                        inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)grenade.getItem().getType(), (int)1, (int)grenade.getItem().getData(), (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
                                        continue;
                                    }
                                    if (playerShop.getType() == ShopType.GUN && (playerShop.getRole() == null || playerShop.getRole() == GameTeam.Role.COUNTERTERRORIST)) {
                                        if (this.main.hideVipGuns() && playerShop.hasPermission() && !player.hasPermission("cs.weapon." + playerShop.getWeaponName())) continue;
                                        grenade = this.main.getGun(playerShop.getWeaponName());
                                        inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)grenade.getItem().getType(), (int)1, (int)grenade.getItem().getData(), (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
                                        continue;
                                    }
                                    if (playerShop.getRole() != null && playerShop.getRole() != GameTeam.Role.COUNTERTERRORIST) continue;
                                    inventory.setItem(playerShop.getSlot(), ItemBuilder.create((Material)playerShop.getMaterial(), (Integer)1, (String)playerShop.getName().replace('&', '\u00a7'), (String)playerShop.getLore()));
                                }
                                this.shops.put((Object)player.getUniqueId(), (Object)inventory);
                                ((ScoreBoard)this.status.get((Object)player.getUniqueId())).showTeams(this);
                                ((ScoreBoard)this.status.get((Object)player.getUniqueId())).showHealth(this);
                            }
                            this.timer = 15;
                            this.main.getManager().resetPlayers(this);
                            for (Player player : this.status.values()) {
                                player.getStatus().reset();
                            }
                            this.setState(GameState.ROUND);
                            break;
                        }
                        for (Player player : this.TeamA.getPlayers()) {
                            if (this.timer <= 5) {
                                player.playSound(player.getEyeLocation(), SpigotSound.NOTE_PLING.getSound(), 1.0f, 0.5f);
                                player.sendMessage(Messages.PREFIX + Messages.GAME_START.toString().replace((CharSequence)"%timer%", (CharSequence)(this.timer + "")));
                                continue;
                            }
                            if (this.timer % 10 != 0) continue;
                            player.sendMessage(Messages.PREFIX + Messages.GAME_START.toString().replace((CharSequence)"%timer%", (CharSequence)(this.timer + "")));
                        }
                        for (Player player : this.TeamB.getPlayers()) {
                            if (this.timer <= 5) {
                                player.playSound(player.getEyeLocation(), SpigotSound.NOTE_PLING.getSound(), 1.0f, 0.5f);
                                player.sendMessage(Messages.PREFIX.toString() + Messages.GAME_START.toString().replace((CharSequence)"%timer%", (CharSequence)(this.timer + "")));
                                continue;
                            }
                            if (this.timer % 10 != 0) continue;
                            player.sendMessage(Messages.PREFIX.toString() + Messages.GAME_START.toString().replace((CharSequence)"%timer%", (CharSequence)(this.timer + "")));
                        }
                    }
                    break;
                }
            }
            --this.timer;
        }
    }
}
