/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 *  ro.Fr33styler.CounterStrike.Cache.PlayerStatus
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam$Role
 *  ro.Fr33styler.CounterStrike.Main
 */
package ro.Fr33styler.CounterStrike.ScoreBoard;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import ro.Fr33styler.CounterStrike.Cache.PlayerStatus;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameTeam;
import ro.Fr33styler.CounterStrike.Main;

public class ScoreBoardTeam {
    private Main main;
    private Scoreboard board;
    private List<Team> teams = new ArrayList();

    public ScoreBoardTeam(Main main, Game game, Scoreboard scoreboard) {
        boolean bl;
        PlayerStatus playerStatus;
        Team team;
        this.main = main;
        this.board = scoreboard;
        for (Player player : game.getMain().getManager().getTeam(game, GameTeam.Role.TERRORIST).getPlayers()) {
            team = scoreboard.registerNewTeam(player.getName());
            playerStatus = (PlayerStatus)game.getStats().get((Object)player.getUniqueId());
            bl = game.getSpectators().contains((Object)player);
            team.setPrefix("\u00a78[\u00a74\u9291\u00a78] " + (bl ? "\u00a77\u00a7o" : "\u00a74"));
            team.setSuffix(" \u00a78[\u00a7e" + playerStatus.getKills() + "-" + playerStatus.getDeaths() + "\u00a78]");
            main.getVersionInterface().hideNameTag(team);
            team.addEntry(player.getName());
            this.teams.add((Object)team);
        }
        for (Player player : game.getMain().getManager().getTeam(game, GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
            team = scoreboard.registerNewTeam(player.getName());
            playerStatus = (PlayerStatus)game.getStats().get((Object)player.getUniqueId());
            bl = game.getSpectators().contains((Object)player);
            team.setPrefix("\u00a78[\u00a73\u9290\u00a78] " + (bl ? "\u00a77\u00a7o" : "\u00a73"));
            team.setSuffix(" \u00a78[\u00a7e" + playerStatus.getKills() + "-" + playerStatus.getDeaths() + "\u00a78]");
            main.getVersionInterface().hideNameTag(team);
            team.addEntry(player.getName());
            this.teams.add((Object)team);
        }
    }

    public void add(Game game, Player player) {
        Team team = this.board.registerNewTeam(player.getName());
        PlayerStatus playerStatus = (PlayerStatus)game.getStats().get((Object)player.getUniqueId());
        boolean bl = game.getSpectators().contains((Object)player);
        team.setPrefix(game.getMain().getManager().getTeam(game, player) == GameTeam.Role.TERRORIST ? "\u00a78[\u00a74\u9291\u00a78] " + (bl ? "\u00a77\u00a7o" : "\u00a74") : "\u00a78[\u00a73\u9290\u00a78] " + (bl ? "\u00a77\u00a7o" : "\u00a73"));
        team.setSuffix(" \u00a78[\u00a7e" + playerStatus.getKills() + "-" + playerStatus.getDeaths() + "\u00a78]");
        this.main.getVersionInterface().hideNameTag(team);
        team.addEntry(player.getName());
        this.teams.add((Object)team);
    }

    public void remove(Game game, Player player) {
        Team team = this.board.getTeam(player.getName());
        if (team != null) {
            this.teams.remove((Object)team);
            team.unregister();
        }
    }

    public List<Team> getTeams() {
        return this.teams;
    }

    public void update(Game game, Player player) {
        Team team = this.board.getTeam(player.getName());
        boolean bl = game.getSpectators().contains((Object)player);
        PlayerStatus playerStatus = (PlayerStatus)game.getStats().get((Object)player.getUniqueId());
        team.setPrefix(game.getMain().getManager().getTeam(game, player) == GameTeam.Role.TERRORIST ? "\u00a78[\u00a74\u9291\u00a78] " + (bl ? "\u00a77\u00a7o" : "\u00a74") : "\u00a78[\u00a73\u9290\u00a78] \u00a73" + (bl ? "\u00a77\u00a7o" : "\u00a73"));
        team.setSuffix(" \u00a78[\u00a7e" + playerStatus.getKills() + "-" + playerStatus.getDeaths() + "\u00a78]");
        this.main.getVersionInterface().hideNameTag(team);
    }
}
