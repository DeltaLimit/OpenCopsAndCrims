/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.DisplaySlot
 *  org.bukkit.scoreboard.Objective
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardLine
 */
package ro.Fr33styler.CounterStrike.ScoreBoard;

import java.util.HashMap;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardLine;

public class ScoreBoardStatus {
    private Main main;
    private Player p;
    private Objective obj;
    private ScoreBoard board;
    private HashMap<Integer, ScoreBoardLine> entries = new HashMap();

    public ScoreBoardStatus(Main main, Player player, ScoreBoard scoreBoard) {
        this.p = player;
        this.main = main;
        this.board = scoreBoard;
        this.obj = scoreBoard.getScoreboard().registerNewObjective("status", "dummy");
        this.obj.setDisplaySlot(DisplaySlot.SIDEBAR);
    }

    public Player getPlayer() {
        return this.p;
    }

    public Objective getObjective() {
        return this.obj;
    }

    public void setTitle(String string) {
        this.obj.setDisplayName(string);
    }

    public void reset() {
        for (ScoreBoardLine scoreBoardLine : this.entries.values()) {
            scoreBoardLine.unregister();
            this.board.getScoreboard().resetScores(scoreBoardLine.getScore().getEntry());
        }
        this.entries.clear();
    }

    public void updateLine(int n, String string) {
        if (this.entries.get((Object)n) != null) {
            ((ScoreBoardLine)this.entries.get((Object)n)).update(string);
        } else {
            this.entries.put((Object)n, (Object)new ScoreBoardLine(this.main, this.board, string, n));
        }
    }
}
