/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.bukkit.ChatColor
 *  org.bukkit.scoreboard.Score
 *  org.bukkit.scoreboard.Team
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard
 */
package ro.Fr33styler.CounterStrike.ScoreBoard;

import org.bukkit.ChatColor;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Team;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard;

public class ScoreBoardLine {
    private Main main;
    private Team team;
    private Score score;
    private String name;

    public ScoreBoardLine(Main main, ScoreBoard scoreBoard, String string, int n) {
        String string2 = ChatColor.values()[n - 1] + "\u00a7r";
        this.team = scoreBoard.getScoreboard().registerNewTeam(string2);
        this.score = scoreBoard.getStatus().getObjective().getScore(string2);
        this.score.setScore(n);
        this.team.addEntry(string2);
        this.main = main;
        this.update(string);
    }

    public void unregister() {
        if (this.team != null) {
            this.team.unregister();
            this.team = null;
        }
    }

    public Score getScore() {
        return this.score;
    }

    public void update(String string) {
        if (this.main.placeholderSupport()) {
            // empty if block
        }
        if (!string.equals((Object)this.name)) {
            this.name = string;
            String string2 = string.length() >= 16 ? string.substring(0, 16) : string;
            boolean bl = false;
            if (string2.length() > 0 && string2.charAt(string2.length() - 1) == '\u00a7') {
                string2 = string2.substring(0, string2.length() - 1);
                bl = true;
            }
            this.team.setPrefix(string2);
            if (string.length() > 16) {
                String string3 = bl ? "" : ChatColor.getLastColors((String)string2);
                if ((string3 = string3 + string.substring(string2.length(), string.length())).length() <= 16) {
                    this.team.setSuffix(string3);
                } else {
                    this.team.setSuffix(string3.substring(0, 16));
                }
            } else {
                this.team.setSuffix("");
            }
        }
    }
}
