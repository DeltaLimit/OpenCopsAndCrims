/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.Objective
 *  org.bukkit.scoreboard.Score
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardHealth
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardStatus
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardTeam
 */
package ro.Fr33styler.CounterStrike.ScoreBoard;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardHealth;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardStatus;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoardTeam;

public class ScoreBoard {
    private Main main;
    private Scoreboard board;
    private ScoreBoardTeam team;
    private ScoreBoardHealth health;
    private ScoreBoardStatus status;

    public ScoreBoard(Main main, Game game, Player player) {
        this.main = main;
        this.board = Bukkit.getScoreboardManager().getNewScoreboard();
        this.status = new ScoreBoardStatus(main, player, this);
        player.setScoreboard(this.board);
    }

    public Scoreboard getScoreboard() {
        return this.board;
    }

    public ScoreBoardTeam getTeams() {
        return this.team;
    }

    public ScoreBoardStatus getStatus() {
        return this.status;
    }

    public ScoreBoardHealth getHealth() {
        return this.health;
    }

    public void showTeams(Game game) {
        this.team = new ScoreBoardTeam(this.main, game, this.board);
        this.main.getVersionInterface().sendInvisibility(this.board, game.getTeamA().getPlayers(), game.getSpectators());
        this.main.getVersionInterface().sendInvisibility(this.board, game.getTeamB().getPlayers(), game.getSpectators());
    }

    public void showHealth(Game game) {
        this.health = new ScoreBoardHealth(game, this);
    }

    public void removeTeam() {
        if (this.team != null) {
            for (Team team : this.team.getTeams()) {
                team.unregister();
            }
            this.team.getTeams().clear();
            this.team = null;
        }
    }

    public void removeHealth() {
        if (this.health != null) {
            for (Score score : this.health.getScores()) {
                this.board.resetScores(score.getEntry());
            }
            this.health.getObjective().unregister();
            this.health = null;
        }
    }

    public void remove() {
        this.removeTeam();
        this.removeHealth();
        for (Objective objective : this.board.getObjectives()) {
            objective.unregister();
        }
    }
}
