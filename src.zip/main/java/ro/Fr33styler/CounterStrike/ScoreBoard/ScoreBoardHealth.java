/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.DisplaySlot
 *  org.bukkit.scoreboard.Objective
 *  org.bukkit.scoreboard.Score
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard
 */
package ro.Fr33styler.CounterStrike.ScoreBoard;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard;

public class ScoreBoardHealth {
    private Objective obj;
    private List<Score> scores = new ArrayList();

    public ScoreBoardHealth(Game game, ScoreBoard scoreBoard) {
        Score score;
        this.obj = scoreBoard.getScoreboard().registerNewObjective("health", "dummy");
        this.obj.setDisplaySlot(DisplaySlot.BELOW_NAME);
        this.obj.setDisplayName("\u9280");
        for (Player player : game.getTeamA().getPlayers()) {
            score = this.obj.getScore(player.getName());
            score.setScore((int)(player.getHealth() / player.getMaxHealth() * 100.0));
            this.scores.add((Object)score);
        }
        for (Player player : game.getTeamB().getPlayers()) {
            score = this.obj.getScore(player.getName());
            score.setScore((int)(player.getHealth() / player.getMaxHealth() * 100.0));
            this.scores.add((Object)score);
        }
    }

    public List<Score> getScores() {
        return this.scores;
    }

    public Objective getObjective() {
        return this.obj;
    }

    public void update(Player player) {
        this.obj.getScore(player.getName()).setScore((int)(player.getHealth() / player.getMaxHealth() * 100.0));
    }
}
