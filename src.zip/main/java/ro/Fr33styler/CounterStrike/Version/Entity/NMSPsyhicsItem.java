/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.bukkit.Location
 */
package ro.Fr33styler.CounterStrike.Version.Entity;

import org.bukkit.Location;

public interface NMSPsyhicsItem {
    public void remove();

    public boolean isRemoved();

    public Location getLocation();
}
