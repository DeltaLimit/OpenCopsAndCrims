/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.bukkit.Sound
 */
package ro.Fr33styler.CounterStrike.Version;

import org.bukkit.Sound;

public enum SpigotSound {
    SPLASH("SPLASH", "ENTITY_BOBBER_SPLASH"),
    ANVIL_USE("ANVIL_USE", "BLOCK_ANVIL_USE"),
    ORB_PICKUP("ORB_PICKUP", "ENTITY_EXPERIENCE_ORB_PICKUP"),
    GHAST_FIREBALL("GHAST_FIREBALL", "ENTITY_GHAST_SHOOT"),
    LEVEL_UP("LEVEL_UP", "ENTITY_PLAYER_LEVELUP"),
    CLICK("CLICK", "UI_BUTTON_CLICK"),
    EXPLODE("EXPLODE", "ENTITY_GENERIC_EXPLODE"),
    NOTE_STICKS("NOTE_STICKS", "BLOCK_NOTE_SNARE"),
    ENTITY_LIGHTNING_IMPACT("AMBIENCE_THUNDER", "ENTITY_LIGHTNING_IMPACT"),
    ENDERMAN_TELEPORT("ENDERMAN_TELEPORT", "ENTITY_ENDERMEN_TELEPORT"),
    ITEM_PICKUP("ITEM_PICKUP", "ENTITY_ITEM_PICKUP"),
    NOTE_PLING("NOTE_PLING", "BLOCK_NOTE_PLING"),
    SLIME_WALK("SLIME_WALK", "ENTITY_SLIME_JUMP");

    private Sound sound;

    private SpigotSound(String ... stringArray) {
        block0: for (String string2 : stringArray) {
            for (Sound sound : Sound.values()) {
                if (!sound.name().equals((Object)string2)) continue;
                this.sound = sound;
                continue block0;
            }
        }
    }

    public Sound getSound() {
        return this.sound;
    }
}
