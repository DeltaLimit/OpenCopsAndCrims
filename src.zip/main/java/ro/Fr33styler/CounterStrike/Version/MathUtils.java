/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.security.SecureRandom
 */
package ro.Fr33styler.CounterStrike.Version;

import java.security.SecureRandom;

public class MathUtils {
    private static SecureRandom random = new SecureRandom();
    private static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    public static String randomString(int n) {
        char[] cArray = new char[n];
        for (int i = 0; i < n; ++i) {
            cArray[i] = AB.charAt(random.nextInt(AB.length()));
        }
        return new String(cArray);
    }

    public static SecureRandom random() {
        return random;
    }

    public static int randomRange(int n, int n2) {
        return n + random.nextInt(n2 - n + 1);
    }

    public static double toDegrees(double d) {
        return d > 179.9 ? -180.0 + (d - 179.9) : d;
    }

    public static int abs(int n) {
        return n < 0 ? -n : n;
    }
}
