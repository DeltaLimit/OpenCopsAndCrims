/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.util.List
 *  net.md_5.bungee.api.ChatMessageType
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Firework
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 *  ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem
 */
package ro.Fr33styler.CounterStrike.Version;

import java.lang.reflect.Field;
import java.util.List;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.block.Block;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem;

public interface VersionInterface {
    public void hideNameTag(Team var1);

    public void sendFakeItem(Player var1, int var2, ItemStack var3);

    default public void sendActionBar(Player p, String message) {
        p.spigot().sendMessage(ChatMessageType.ACTION_BAR, (BaseComponent)new TextComponent(message));
    }

    public void setHandSpeed(Player var1, double var2);

    public void sendInvisibility(Scoreboard var1, List<Player> var2, List<Player> var3);

    public void setFireworkExplode(Field var1, Firework var2);

    public void sendTitle(Player var1, int var2, int var3, int var4, String var5, String var6);

    public NMSPsyhicsItem spawnPsyhicsItem(Player var1, ItemStack var2, double var3);

    public double getHandSpeed(Player var1);

    public boolean hasHitboxAt(Block var1, double var2, double var4, double var6);
}
