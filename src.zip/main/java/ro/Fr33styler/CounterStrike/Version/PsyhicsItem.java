/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  org.bukkit.Location
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem
 *  ro.Fr33styler.CounterStrike.Version.MathUtils
 */
package ro.Fr33styler.CounterStrike.Version;

import org.bukkit.Location;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem;
import ro.Fr33styler.CounterStrike.Version.MathUtils;

public class PsyhicsItem
implements NMSPsyhicsItem {
    private Item item;
    private boolean removed = false;

    public PsyhicsItem(Player player, ItemStack itemStack, double d) {
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(MathUtils.randomString((int)15));
        itemStack.setItemMeta(itemMeta);
        this.item = player.getWorld().dropItem(player.getEyeLocation(), itemStack);
        this.item.setPickupDelay(Integer.MAX_VALUE);
        this.item.setVelocity(player.getEyeLocation().getDirection().multiply(d));
    }

    public void remove() {
        this.item.remove();
        this.removed = true;
    }

    public boolean isRemoved() {
        return this.removed;
    }

    public Location getLocation() {
        return this.item.getLocation();
    }
}
