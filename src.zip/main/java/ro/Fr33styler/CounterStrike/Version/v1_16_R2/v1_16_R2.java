/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.util.List
 *  net.minecraft.server.v1_16_R2.EntityFireworks
 *  net.minecraft.server.v1_16_R2.EntityPlayer
 *  net.minecraft.server.v1_16_R2.IBlockAccess
 *  net.minecraft.server.v1_16_R2.IChatBaseComponent
 *  net.minecraft.server.v1_16_R2.IChatBaseComponent$ChatSerializer
 *  net.minecraft.server.v1_16_R2.IChatMutableComponent
 *  net.minecraft.server.v1_16_R2.Packet
 *  net.minecraft.server.v1_16_R2.PacketPlayOutScoreboardTeam
 *  net.minecraft.server.v1_16_R2.PacketPlayOutSetSlot
 *  net.minecraft.server.v1_16_R2.PacketPlayOutTitle
 *  net.minecraft.server.v1_16_R2.PacketPlayOutTitle$EnumTitleAction
 *  net.minecraft.server.v1_16_R2.PlayerConnection
 *  net.minecraft.server.v1_16_R2.ScoreboardTeam
 *  net.minecraft.server.v1_16_R2.ScoreboardTeamBase$EnumNameTagVisibility
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.block.Block
 *  org.bukkit.craftbukkit.v1_16_R2.block.CraftBlock
 *  org.bukkit.craftbukkit.v1_16_R2.entity.CraftFirework
 *  org.bukkit.craftbukkit.v1_16_R2.entity.CraftPlayer
 *  org.bukkit.craftbukkit.v1_16_R2.inventory.CraftItemStack
 *  org.bukkit.craftbukkit.v1_16_R2.scoreboard.CraftScoreboard
 *  org.bukkit.entity.Firework
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 *  ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem
 *  ro.Fr33styler.CounterStrike.Version.PsyhicsItem
 *  ro.Fr33styler.CounterStrike.Version.VersionInterface
 */
package ro.Fr33styler.CounterStrike.Version.v1_16_R2;

import java.lang.reflect.Field;
import java.util.List;
import net.minecraft.server.v1_16_R2.EntityFireworks;
import net.minecraft.server.v1_16_R2.EntityPlayer;
import net.minecraft.server.v1_16_R2.IBlockAccess;
import net.minecraft.server.v1_16_R2.IChatBaseComponent;
import net.minecraft.server.v1_16_R2.IChatMutableComponent;
import net.minecraft.server.v1_16_R2.Packet;
import net.minecraft.server.v1_16_R2.PacketPlayOutScoreboardTeam;
import net.minecraft.server.v1_16_R2.PacketPlayOutSetSlot;
import net.minecraft.server.v1_16_R2.PacketPlayOutTitle;
import net.minecraft.server.v1_16_R2.PlayerConnection;
import net.minecraft.server.v1_16_R2.ScoreboardTeam;
import net.minecraft.server.v1_16_R2.ScoreboardTeamBase;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_16_R2.block.CraftBlock;
import org.bukkit.craftbukkit.v1_16_R2.entity.CraftFirework;
import org.bukkit.craftbukkit.v1_16_R2.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_16_R2.inventory.CraftItemStack;
import org.bukkit.craftbukkit.v1_16_R2.scoreboard.CraftScoreboard;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem;
import ro.Fr33styler.CounterStrike.Version.PsyhicsItem;
import ro.Fr33styler.CounterStrike.Version.VersionInterface;

public class v1_16_R2
implements VersionInterface {
    public void sendFakeItem(Player player, int n, ItemStack itemStack) {
        EntityPlayer entityPlayer = ((CraftPlayer)player).getHandle();
        entityPlayer.playerConnection.sendPacket((Packet)new PacketPlayOutSetSlot(entityPlayer.defaultContainer.windowId, n, CraftItemStack.asNMSCopy((ItemStack)itemStack)));
    }

    public void setFireworkExplode(Field field, Firework firework) {
        EntityFireworks entityFireworks = ((CraftFirework)firework).getHandle();
        try {
            field.set((Object)entityFireworks, (Object)(entityFireworks.expectedLifespan - 1));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void sendTitle(Player player, int n, int n2, int n3, String string, String string2) {
        PacketPlayOutTitle packetPlayOutTitle;
        IChatMutableComponent iChatMutableComponent;
        PlayerConnection playerConnection = ((CraftPlayer)player).getHandle().playerConnection;
        PacketPlayOutTitle packetPlayOutTitle2 = new PacketPlayOutTitle(PacketPlayOutTitle.EnumTitleAction.TIMES, null, n, n2, n3);
        playerConnection.sendPacket((Packet)packetPlayOutTitle2);
        if (string2 != null) {
            iChatMutableComponent = IChatBaseComponent.ChatSerializer.a((String)("{\"text\": \"" + string2 + "\"}"));
            packetPlayOutTitle = new PacketPlayOutTitle(PacketPlayOutTitle.EnumTitleAction.SUBTITLE, (IChatBaseComponent)iChatMutableComponent);
            playerConnection.sendPacket((Packet)packetPlayOutTitle);
        }
        if (string != null) {
            iChatMutableComponent = IChatBaseComponent.ChatSerializer.a((String)("{\"text\": \"" + string + "\"}"));
            packetPlayOutTitle = new PacketPlayOutTitle(PacketPlayOutTitle.EnumTitleAction.TITLE, (IChatBaseComponent)iChatMutableComponent);
            playerConnection.sendPacket((Packet)packetPlayOutTitle);
        }
    }

    public void sendInvisibility(Scoreboard scoreboard, List<Player> list, List<Player> list2) {
        for (Player player : list) {
            Field field;
            if (list2.contains((Object)player)) continue;
            ScoreboardTeam scoreboardTeam = ((CraftScoreboard)scoreboard).getHandle().getTeam(player.getName());
            try {
                field = scoreboardTeam.getClass().getDeclaredField("i");
                field.setAccessible(true);
                field.set((Object)scoreboardTeam, (Object)ScoreboardTeamBase.EnumNameTagVisibility.ALWAYS);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            field = new PacketPlayOutScoreboardTeam(scoreboardTeam, 2);
            for (Player player2 : list) {
                ((CraftPlayer)player2).getHandle().playerConnection.sendPacket((Packet)field);
            }
        }
    }

    public NMSPsyhicsItem spawnPsyhicsItem(Player player, ItemStack itemStack, double d) {
        return new PsyhicsItem(player, itemStack, d);
    }

    public void setHandSpeed(Player player, double d) {
        player.getAttribute(Attribute.GENERIC_ATTACK_SPEED).setBaseValue(d);
    }

    public double getHandSpeed(Player player) {
        return player.getAttribute(Attribute.GENERIC_ATTACK_SPEED).getBaseValue();
    }

    public void hideNameTag(Team team) {
        ScoreboardTeam scoreboardTeam = ((CraftScoreboard)team.getScoreboard()).getHandle().getTeam(team.getName());
        scoreboardTeam.setNameTagVisibility(ScoreboardTeamBase.EnumNameTagVisibility.NEVER);
    }

    public boolean hasHitboxAt(Block block, double d, double d2, double d3) {
        CraftBlock craftBlock = (CraftBlock)block;
        boolean[] blArray = new boolean[]{false};
        craftBlock.getNMS().getShape((IBlockAccess)craftBlock.getCraftWorld().getHandle(), craftBlock.getPosition()).b((d4, d5, d6, d7, d8, d9) -> {
            if (d - (double)block.getX() >= d4 && d - (double)block.getX() < d7 && d2 - (double)block.getY() >= d5 && d2 - (double)block.getY() < d8 && d3 - (double)block.getZ() >= d6 && d3 - (double)block.getZ() < d9) {
                blArray[0] = true;
                return;
            }
        });
        return blArray[0];
    }
}
