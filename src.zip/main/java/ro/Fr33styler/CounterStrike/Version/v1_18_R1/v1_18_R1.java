/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.util.List
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.PacketPlayOutScoreboardTeam
 *  net.minecraft.network.protocol.game.PacketPlayOutSetSlot
 *  net.minecraft.server.level.EntityPlayer
 *  net.minecraft.world.entity.projectile.EntityFireworks
 *  net.minecraft.world.level.IBlockAccess
 *  net.minecraft.world.scores.ScoreboardTeam
 *  net.minecraft.world.scores.ScoreboardTeamBase$EnumNameTagVisibility
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.block.Block
 *  org.bukkit.craftbukkit.v1_18_R1.block.CraftBlock
 *  org.bukkit.craftbukkit.v1_18_R1.entity.CraftFirework
 *  org.bukkit.craftbukkit.v1_18_R1.entity.CraftPlayer
 *  org.bukkit.craftbukkit.v1_18_R1.inventory.CraftItemStack
 *  org.bukkit.craftbukkit.v1_18_R1.scoreboard.CraftScoreboard
 *  org.bukkit.entity.Firework
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 *  ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem
 *  ro.Fr33styler.CounterStrike.Version.PsyhicsItem
 *  ro.Fr33styler.CounterStrike.Version.VersionInterface
 */
package ro.Fr33styler.CounterStrike.Version.v1_18_R1;

import java.lang.reflect.Field;
import java.util.List;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.PacketPlayOutScoreboardTeam;
import net.minecraft.network.protocol.game.PacketPlayOutSetSlot;
import net.minecraft.server.level.EntityPlayer;
import net.minecraft.world.entity.projectile.EntityFireworks;
import net.minecraft.world.level.IBlockAccess;
import net.minecraft.world.scores.ScoreboardTeam;
import net.minecraft.world.scores.ScoreboardTeamBase;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_18_R1.block.CraftBlock;
import org.bukkit.craftbukkit.v1_18_R1.entity.CraftFirework;
import org.bukkit.craftbukkit.v1_18_R1.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_18_R1.inventory.CraftItemStack;
import org.bukkit.craftbukkit.v1_18_R1.scoreboard.CraftScoreboard;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem;
import ro.Fr33styler.CounterStrike.Version.PsyhicsItem;
import ro.Fr33styler.CounterStrike.Version.VersionInterface;

public class v1_18_R1
implements VersionInterface {
    public void sendFakeItem(Player player, int n, ItemStack itemStack) {
        EntityPlayer entityPlayer = ((CraftPlayer)player).getHandle();
        entityPlayer.b.a((Packet)new PacketPlayOutSetSlot(entityPlayer.bV.j, entityPlayer.bV.k(), n, CraftItemStack.asNMSCopy((ItemStack)itemStack)));
    }

    public void setFireworkExplode(Field field, Firework firework) {
        EntityFireworks entityFireworks = ((CraftFirework)firework).getHandle();
        try {
            field.set((Object)entityFireworks, (Object)(entityFireworks.f - 1));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void sendTitle(Player player, int n, int n2, int n3, String string, String string2) {
        player.sendTitle(string, string2, n, n2, n3);
    }

    public void sendInvisibility(Scoreboard scoreboard, List<Player> list, List<Player> list2) {
        for (Player player : list) {
            Field field;
            if (list2.contains((Object)player)) continue;
            ScoreboardTeam scoreboardTeam = ((CraftScoreboard)scoreboard).getHandle().f(player.getName());
            try {
                field = scoreboardTeam.getClass().getDeclaredField("k");
                field.setAccessible(true);
                field.set((Object)scoreboardTeam, (Object)ScoreboardTeamBase.EnumNameTagVisibility.a);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            field = PacketPlayOutScoreboardTeam.a((ScoreboardTeam)scoreboardTeam, (boolean)false);
            for (Player player2 : list) {
                ((CraftPlayer)player2).getHandle().b.a((Packet)field);
            }
        }
    }

    public NMSPsyhicsItem spawnPsyhicsItem(Player player, ItemStack itemStack, double d) {
        return new PsyhicsItem(player, itemStack, d);
    }

    public void setHandSpeed(Player player, double d) {
        player.getAttribute(Attribute.GENERIC_ATTACK_SPEED).setBaseValue(d);
    }

    public double getHandSpeed(Player player) {
        return player.getAttribute(Attribute.GENERIC_ATTACK_SPEED).getBaseValue();
    }

    public void hideNameTag(Team team) {
        ScoreboardTeam scoreboardTeam = ((CraftScoreboard)team.getScoreboard()).getHandle().f(team.getName());
        scoreboardTeam.a(ScoreboardTeamBase.EnumNameTagVisibility.b);
    }

    public boolean hasHitboxAt(Block block, double d, double d2, double d3) {
        CraftBlock craftBlock = (CraftBlock)block;
        boolean[] blArray = new boolean[]{false};
        craftBlock.getNMS().c((IBlockAccess)craftBlock.getCraftWorld().getHandle(), craftBlock.getPosition()).b((d4, d5, d6, d7, d8, d9) -> {
            if (d - (double)block.getX() >= d4 && d - (double)block.getX() < d7 && d2 - (double)block.getY() >= d5 && d2 - (double)block.getY() < d8 && d3 - (double)block.getZ() >= d6 && d3 - (double)block.getZ() < d9) {
                blArray[0] = true;
                return;
            }
        });
        return blArray[0];
    }
}
