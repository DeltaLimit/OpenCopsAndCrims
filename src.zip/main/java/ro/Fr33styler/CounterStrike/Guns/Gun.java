/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map$Entry
 *  java.util.UUID
 *  org.bukkit.Bukkit
 *  org.bukkit.Effect
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.inventory.ItemStack
 *  ro.Fr33styler.CounterStrike.Api.GunDamageEvent
 *  ro.Fr33styler.CounterStrike.Cache.PlayerStatus
 *  ro.Fr33styler.CounterStrike.Guns.GunCache
 *  ro.Fr33styler.CounterStrike.Guns.GunReload
 *  ro.Fr33styler.CounterStrike.Guns.GunType
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.Utils.Item
 *  ro.Fr33styler.CounterStrike.Version.MathUtils
 */
package ro.Fr33styler.CounterStrike.Guns;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;
import ro.Fr33styler.CounterStrike.Api.GunDamageEvent;
import ro.Fr33styler.CounterStrike.Cache.PlayerStatus;
import ro.Fr33styler.CounterStrike.Guns.GunCache;
import ro.Fr33styler.CounterStrike.Guns.GunReload;
import ro.Fr33styler.CounterStrike.Guns.GunType;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.Utils.Item;
import ro.Fr33styler.CounterStrike.Version.MathUtils;

public class Gun {
    private final Main main;
    private final Item item;
    private final String name;
    private final GunType type;
    private int duration;
    private int amount;
    private float accuracy;
    private double damage;
    private int bullets;
    private String symbol;
    private boolean snipe;
    private int delayshot;
    private int rounds;
    private final String shotsound;
    private int distance;
    private int delayrounds;
    private int RoundsPerYaw;
    private int MaxRoundsPerPitch;
    private int module;
    private final String reloadsound_end;
    private final String reloadsound_start;
    private final HashMap<UUID, Long> delay = new HashMap();
    private final HashMap<UUID, Integer> delayBlood = new HashMap();
    private final HashMap<UUID, GunCache> cache = new HashMap();
    private final HashMap<UUID, GunReload> inReloading = new HashMap();

    public Gun(Main main, String string, Item item, GunType gunType, String string2, String string3, String string4) {
        this.main = main;
        this.name = string;
        this.item = item;
        this.type = gunType;
        this.shotsound = string2;
        this.reloadsound_end = string4;
        this.reloadsound_start = string3;
    }

    public void shot(Game game, Player player) {
        if (player.getInventory().getHeldItemSlot() == this.type.getID().intValue()) {
            long l = System.currentTimeMillis() / 49L;
            if (this.delay.get((Object)player.getUniqueId()) == null) {
                this.delay.put((Object)player.getUniqueId(), (Object)l);
            } else if (l - (Long)this.delay.get((Object)player.getUniqueId()) <= (long)this.delayshot) {
                return;
            }
            GunCache gunCache = (GunCache)this.cache.get((Object)player.getUniqueId());
            if (gunCache == null) {
                this.cache.put((Object)player.getUniqueId(), (Object)new GunCache(game, player.isSneaking() ? 1 : this.rounds));
            } else {
                gunCache.setRounds(player.isSneaking() ? 1 : this.rounds);
            }
            this.delay.put((Object)player.getUniqueId(), (Object)l);
        }
    }

    public void reload(Player player, int n) {
        ItemStack itemStack = player.getInventory().getItem(n);
        if (this.item.equals(itemStack, this.symbol) && itemStack.getAmount() < this.amount && !this.inReloading.containsKey((Object)player.getUniqueId())) {
            player.playSound(player.getEyeLocation(), this.reloadsound_start, 5.0f, 1.0f);
            int n2 = this.duration;
            if (player.hasPermission("cs.weapon.faster_reload70")) {
                n2 = (int)((double)n2 * 0.7);
            } else if (player.hasPermission("cs.weapon.faster_reload50")) {
                n2 = (int)((double)n2 * 0.5);
            }
            this.inReloading.put((Object)player.getUniqueId(), (Object)new GunReload(n2));
        }
    }

    public String getSymbol() {
        return this.symbol;
    }

    public void setRoundsPerYaw(int n) {
        this.RoundsPerYaw = n;
    }

    public void setMaxRoundsPerPitch(int n) {
        this.MaxRoundsPerPitch = n;
    }

    public void setDelayRounds(int n) {
        this.delayrounds = n;
    }

    public void setRounds(int n) {
        this.rounds = n;
    }

    public void setDistance(int n) {
        this.distance = n;
    }

    public void setDamage(double d) {
        this.damage = d;
    }

    public void setDuration(int n) {
        this.duration = n;
    }

    public int getModule() {
        return this.module;
    }

    public void setSymbol(String string) {
        this.symbol = string;
    }

    public void setModule(int n) {
        this.module = n;
    }

    public void setAccuracy(float f) {
        this.accuracy = f;
    }

    public void setDelay(int n) {
        this.delayshot = n;
    }

    public void setBullets(int n) {
        this.bullets = n;
    }

    public void setAmount(int n) {
        this.amount = n;
    }

    public void resetPlayer(Player player) {
        this.inReloading.remove((Object)player.getUniqueId());
        this.cache.remove((Object)player.getUniqueId());
    }

    public int getAmount() {
        return this.amount;
    }

    public void hasSnipe(boolean bl) {
        this.snipe = bl;
    }

    public boolean hasSnipe() {
        return this.snipe;
    }

    public String getName() {
        return this.name;
    }

    public Item getItem() {
        return this.item;
    }

    public GunType getGunType() {
        return this.type;
    }

    public void resetDelay(Player player) {
        this.delay.remove((Object)player.getUniqueId());
    }

    public void tick() {
        Player player;
        Map.Entry entry;
        Iterator iterator;
        if (!this.inReloading.isEmpty()) {
            iterator = this.inReloading.entrySet().iterator();
            while (iterator.hasNext()) {
                entry = (Map.Entry)iterator.next();
                player = Bukkit.getPlayer((UUID)((UUID)entry.getKey()));
                if (player != null && !player.isDead() && player.isOnline() && this.main.getManager().getGame(player) != null) {
                    if (this.item.equals(player.getInventory().getItemInHand(), this.symbol)) {
                        if (this.module == 2) {
                            player.setExp((float)(1.0 - ((GunReload)entry.getValue()).getLeft() / (double)((GunReload)entry.getValue()).getMaxTime()));
                            if (((GunReload)entry.getValue()).getLeft() <= 0.0) {
                                iterator.remove();
                                player.setExp(0.0f);
                                player.getInventory().getItemInHand().setAmount(this.amount);
                                player.playSound(player.getEyeLocation(), this.reloadsound_end, 5.0f, 1.0f);
                            }
                        } else {
                            player.getInventory().getItemInHand().setDurability((short)(((GunReload)entry.getValue()).getLeft() / (double)((GunReload)entry.getValue()).getMaxTime() * (double)player.getInventory().getItemInHand().getType().getMaxDurability()));
                            if (((GunReload)entry.getValue()).getLeft() <= 0.0) {
                                iterator.remove();
                                player.getInventory().getItemInHand().setAmount(this.amount);
                                player.getInventory().getItemInHand().setDurability((short)0);
                                player.playSound(player.getEyeLocation(), this.reloadsound_end, 5.0f, 1.0f);
                            }
                        }
                        ((GunReload)entry.getValue()).setLeft((int)((GunReload)entry.getValue()).getLeft() - 1);
                        continue;
                    }
                    iterator.remove();
                    continue;
                }
                iterator.remove();
            }
        }
        if (!this.delayBlood.isEmpty()) {
            iterator = this.delayBlood.entrySet().iterator();
            while (iterator.hasNext()) {
                entry = (Map.Entry)iterator.next();
                if ((Integer)entry.getValue() > 0) {
                    entry.setValue((Object)((Integer)entry.getValue() - 1));
                    continue;
                }
                iterator.remove();
            }
        }
        if (!this.delay.isEmpty()) {
            iterator = this.delay.entrySet().iterator();
            while (iterator.hasNext()) {
                entry = (Map.Entry)iterator.next();
                player = Bukkit.getPlayer((UUID)((UUID)entry.getKey()));
                long l = System.currentTimeMillis() / 49L;
                if (player != null && !player.isDead() && player.isOnline() && this.main.getManager().getGame(player) != null && l - (Long)entry.getValue() <= (long)this.delayshot) continue;
                iterator.remove();
            }
        }
        if (!this.cache.isEmpty()) {
            iterator = this.cache.entrySet().iterator();
            while (iterator.hasNext()) {
                entry = (Map.Entry)iterator.next();
                player = Bukkit.getPlayer((UUID)((UUID)entry.getKey()));
                GunCache gunCache = (GunCache)entry.getValue();
                if (!this.inReloading.containsKey(entry.getKey())) {
                    if (player != null && !player.isDead() && player.isOnline() && gunCache.getGame() != null) {
                        if (!gunCache.getGame().getSpectators().contains((Object)player)) {
                            gunCache.setTicksLeft(gunCache.getTicksLeft() - 1);
                            if (gunCache.getRounds() > 0 && this.item.equals(player.getInventory().getItemInHand(), this.symbol)) {
                                gunCache.setTicks(gunCache.getTicks() + 1);
                                if (gunCache.isFirstShot()) {
                                    gunCache.setFirstShot(false);
                                } else if (gunCache.getTicks() % this.delayrounds != 0) {
                                    return;
                                }
                                if (player.getInventory().getItemInHand().getAmount() <= 1) {
                                    iterator.remove();
                                    this.reload(player, this.type.getID());
                                    for (Player player2 : gunCache.getGame().getTeamA().getPlayers()) {
                                        player2.playSound(player.getLocation(), "cs.gamesounds.reloading", 1.0f, 1.0f);
                                    }
                                    for (Player player2 : gunCache.getGame().getTeamB().getPlayers()) {
                                        player2.playSound(player.getLocation(), "cs.gamesounds.reloading", 1.0f, 1.0f);
                                    }
                                    return;
                                }
                                gunCache.setRounds(gunCache.getRounds() - 1);
                                player.getInventory().getItemInHand().setAmount(player.getInventory().getItemInHand().getAmount() - 1);
                                Iterator iterator2 = player.getEyeLocation();
                                if (player.isSneaking()) {
                                    iterator2.subtract(0.0, 0.03, 0.0);
                                } else {
                                    iterator2.subtract(0.0, 0.01, 0.0);
                                }
                                for (Player player3 : gunCache.getGame().getTeamA().getPlayers()) {
                                    player3.playSound((Location)iterator2, this.shotsound, 1.0f, 1.0f);
                                }
                                for (Player player3 : gunCache.getGame().getTeamB().getPlayers()) {
                                    player3.playSound((Location)iterator2, this.shotsound, 1.0f, 1.0f);
                                }
                                if (this.accuracy == 0.0f) {
                                    gunCache.setAccuracyYaw(0.0f);
                                    gunCache.setAccuracyPitch(0.0f);
                                }
                                float f = iterator2.getYaw();
                                float f2 = iterator2.getPitch();
                                double d = iterator2.getX();
                                double d2 = iterator2.getY();
                                double d3 = iterator2.getZ();
                                for (int i = 0; i < this.bullets; ++i) {
                                    if (this.snipe && player.isSneaking()) {
                                        gunCache.setAccuracyYaw(0.0f);
                                        gunCache.setAccuracyPitch(0.0f);
                                    } else if (this.snipe && !player.isSneaking()) {
                                        gunCache.setAccuracyYaw((float)MathUtils.randomRange((int)((int)(-this.accuracy)), (int)((int)this.accuracy)) + 0.5f);
                                        gunCache.setAccuracyPitch((float)MathUtils.randomRange((int)((int)(-this.accuracy)), (int)((int)this.accuracy)) + 0.5f);
                                    } else if (this.bullets > 1) {
                                        gunCache.setAccuracyYaw((float)MathUtils.randomRange((int)((int)(-this.accuracy)), (int)((int)this.accuracy)) + 0.5f);
                                        gunCache.setAccuracyPitch((float)MathUtils.randomRange((int)((int)(-this.accuracy)), (int)((int)this.accuracy)) + 0.5f);
                                    } else if (this.accuracy == 0.0f && player.isSprinting()) {
                                        gunCache.setAccuracyYaw((float)MathUtils.randomRange((int)-2, (int)2) + 0.5f);
                                        gunCache.setAccuracyPitch((float)MathUtils.randomRange((int)-2, (int)2) + 0.5f);
                                    } else if (gunCache.getAccuracyPitch() >= -this.accuracy * (float)this.MaxRoundsPerPitch && !gunCache.isFirstShot()) {
                                        if (this.RoundsPerYaw == 0) {
                                            gunCache.setAccuracyPitch(gunCache.getAccuracyPitch() - this.accuracy);
                                        } else if (gunCache.getYawDirection() == 0) {
                                            gunCache.setYawDirection(1);
                                            gunCache.setAccuracyYaw(this.accuracy);
                                        } else if (gunCache.getAccuracyYaw() / this.accuracy == (float)this.RoundsPerYaw) {
                                            gunCache.setYawDirection(-1);
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() - this.accuracy);
                                        } else if (gunCache.getAccuracyYaw() / this.accuracy == (float)(-this.RoundsPerYaw)) {
                                            gunCache.setAccuracyYaw(0.0f);
                                            gunCache.setYawDirection(1);
                                            gunCache.setAccuracyPitch(gunCache.getAccuracyPitch() - this.accuracy);
                                        } else if (gunCache.getYawDirection() > 0 && gunCache.getAccuracyYaw() / this.accuracy < (float)this.RoundsPerYaw) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() + this.accuracy);
                                        } else if (gunCache.getYawDirection() < 0 && gunCache.getAccuracyYaw() / this.accuracy < (float)this.RoundsPerYaw) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() - this.accuracy);
                                        }
                                    } else if (gunCache.getAccuracyPitch() <= -this.accuracy * (float)this.MaxRoundsPerPitch && player.getInventory().getItemInHand().getAmount() >= 1 && this.RoundsPerYaw == 0) {
                                        if (gunCache.getYawDirection() == 0) {
                                            gunCache.setYawDirection(1);
                                            gunCache.setAccuracyYaw(2.0f);
                                        } else if (gunCache.getAccuracyYaw() / 2.0f <= -2.0f) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() + 2.0f);
                                            gunCache.setYawDirection(1);
                                        } else if (gunCache.getAccuracyYaw() / 2.0f >= 2.0f) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() - 2.0f);
                                            gunCache.setYawDirection(-1);
                                        } else if (gunCache.getYawDirection() > 0 && gunCache.getAccuracyYaw() / 2.0f < 2.0f) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() + 2.0f);
                                        } else if (gunCache.getYawDirection() < 0 && gunCache.getAccuracyYaw() / 2.0f < 2.0f) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() - 2.0f);
                                        }
                                    } else if (gunCache.getAccuracyPitch() <= -this.accuracy * (float)this.MaxRoundsPerPitch && player.getInventory().getItemInHand().getAmount() >= 1) {
                                        if (gunCache.getYawDirection() == 0) {
                                            gunCache.setYawDirection(1);
                                            gunCache.setAccuracyYaw(this.accuracy);
                                        } else if (gunCache.getAccuracyYaw() / this.accuracy == (float)this.RoundsPerYaw) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() - this.accuracy);
                                            gunCache.setYawDirection(-1);
                                        } else if (gunCache.getAccuracyYaw() / this.accuracy == (float)(-this.RoundsPerYaw)) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() + this.accuracy);
                                            gunCache.setYawDirection(1);
                                        } else if (gunCache.getYawDirection() > 0 && gunCache.getAccuracyYaw() / this.accuracy < (float)this.RoundsPerYaw) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() + this.accuracy);
                                        } else if (gunCache.getYawDirection() < 0 && gunCache.getAccuracyYaw() / this.accuracy < (float)this.RoundsPerYaw) {
                                            gunCache.setAccuracyYaw(gunCache.getAccuracyYaw() - this.accuracy);
                                        }
                                    }
                                    double d4 = Math.toRadians((double)(MathUtils.toDegrees((double)f) + (double)gunCache.getAccuracyYaw() + 90.0));
                                    double d5 = Math.toRadians((double)(f2 + gunCache.getAccuracyPitch() + 90.0f));
                                    double d6 = Math.sin((double)d5) * Math.cos((double)d4);
                                    double d7 = Math.cos((double)d5);
                                    double d8 = Math.sin((double)d5) * Math.sin((double)d4);
                                    for (double d9 = 0.5; d9 < (double)this.distance; d9 += 0.25) {
                                        GunDamageEvent gunDamageEvent;
                                        Block block;
                                        iterator2.setX(d + d9 * d6);
                                        iterator2.setY(d2 + d9 * d7);
                                        iterator2.setZ(d3 + d9 * d8);
                                        if (d9 % 1.5 == 0.0) {
                                            player.spawnParticle(Particle.FLAME, (Location)iterator2, 1, 0.0, 0.0, 0.0, 0.0);
                                        }
                                        if (d9 == 0.5) {
                                            player.spawnParticle(Particle.SNOWBALL, (Location)iterator2, 1, 0.0, 0.0, 0.0, 0.0);
                                            player.spawnParticle(Particle.SNOWBALL, (Location)iterator2, 1, 0.0, 0.0, 0.0, 0.0);
                                        }
                                        if ((block = iterator2.getBlock()).getType() != Material.WHEAT && this.main.getVersionInterface().hasHitboxAt(block, iterator2.getX(), iterator2.getY(), iterator2.getZ())) {
                                            if (block.getType().name().contains((CharSequence)"GLASS")) {
                                                iterator2.getWorld().playEffect((Location)iterator2, Effect.STEP_SOUND, (Object)block.getType());
                                                gunCache.getGame().restoreBlocks().add((Object)iterator2.getBlock().getState());
                                                block.setType(Material.AIR);
                                            } else {
                                                player.getWorld().playEffect((Location)iterator2, Effect.STEP_SOUND, (Object)block.getType());
                                                break;
                                            }
                                        }
                                        Player player4 = null;
                                        for (Player player5 : gunCache.getGame().getTeamA().getPlayers()) {
                                            if (player == player5 || gunCache.getGame().getSpectators().contains((Object)player5) || this.main.getManager().sameTeam(gunCache.getGame(), player, player5) || !(player5.getLocation().add(0.0, 0.2, 0.0).distance((Location)iterator2) <= 0.4 + this.main.hitAddition()) && !(player5.getLocation().add(0.0, 1.0, 0.0).distance((Location)iterator2) <= 0.5 + this.main.hitAddition()) && !(player5.getEyeLocation().distance((Location)iterator2) <= 0.35) || player5.isDead()) continue;
                                            player4 = player5;
                                            break;
                                        }
                                        for (Player player5 : gunCache.getGame().getTeamB().getPlayers()) {
                                            if (player == player5 || gunCache.getGame().getSpectators().contains((Object)player5) || this.main.getManager().sameTeam(gunCache.getGame(), player, player5) || player5.getLocation().getWorld() != iterator2.getWorld() || !(player5.getLocation().add(0.0, 0.2, 0.0).distance((Location)iterator2) <= 0.4 + this.main.hitAddition()) && !(player5.getLocation().add(0.0, 1.0, 0.0).distance((Location)iterator2) <= 0.5 + this.main.hitAddition()) && !(player5.getEyeLocation().distance((Location)iterator2) <= 0.35) || player5.isDead()) continue;
                                            player4 = player5;
                                            break;
                                        }
                                        if (player4 == null) continue;
                                        if (this.main.enableBlood() && this.delayBlood.get((Object)player4.getUniqueId()) == null) {
                                            player4.getWorld().playEffect((Location)iterator2, Effect.STEP_SOUND, (Object)Material.REDSTONE_WIRE);
                                            this.delayBlood.put((Object)player4.getUniqueId(), (Object)this.delayshot);
                                        }
                                        if (!player4.isSneaking() && iterator2.getY() - player4.getLocation().getY() > 1.35 && iterator2.getY() - player4.getLocation().getY() < 1.9 || iterator2.getY() - player4.getLocation().getY() > 1.27 && iterator2.getY() - player4.getLocation().getY() < 1.82) {
                                            double d10 = player4.getInventory().getHelmet().getType() == Material.LEATHER_HELMET ? 0.5 : 0.25;
                                            gunDamageEvent = new GunDamageEvent(this.damage + d10 * this.damage, true, player, player4);
                                            this.main.getServer().getPluginManager().callEvent((Event)gunDamageEvent);
                                            if (this.main.getManager().damage(gunCache.getGame(), player, player4, this.damage + d10 * this.damage, this.symbol + "\u9270")) {
                                                player.playSound(player.getLocation(), "cs.gamesounds.headshotkill", 1.0f, 1.0f);
                                                ((PlayerStatus)gunCache.getGame().getStats().get((Object)player.getUniqueId())).addHeadshotKill();
                                                break;
                                            }
                                            player.playSound(player.getLocation(), "cs.random.headshot_shooter", 1.0f, 1.0f);
                                            player4.playSound(player.getLocation(), "cs.random.headshot_victim", 1.0f, 1.0f);
                                            break;
                                        }
                                        double d11 = player4.getInventory().getChestplate().getType() == Material.LEATHER_CHESTPLATE ? 0.0 : 0.15;
                                        gunDamageEvent = new GunDamageEvent(this.damage - d11 * this.damage, false, player, player4);
                                        this.main.getServer().getPluginManager().callEvent((Event)gunDamageEvent);
                                        this.main.getManager().damage(gunCache.getGame(), player, player4, this.damage - d11 * this.damage, this.symbol);
                                        break;
                                    }
                                    iterator2.setX(d);
                                    iterator2.setY(d2);
                                    iterator2.setZ(d8);
                                }
                                continue;
                            }
                            if (gunCache.getTicksLeft() > 0) continue;
                            iterator.remove();
                            continue;
                        }
                        iterator.remove();
                        continue;
                    }
                    iterator.remove();
                    continue;
                }
                iterator.remove();
            }
        }
    }
}
