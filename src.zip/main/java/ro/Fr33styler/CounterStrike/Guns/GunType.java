/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 */
package ro.Fr33styler.CounterStrike.Guns;

public enum GunType {
    PRIMARY(0),
    SECONDARY(1);

    private final int id;

    private GunType(int n2) {
        this.id = n2;
    }

    public Integer getID() {
        return this.id;
    }
}
