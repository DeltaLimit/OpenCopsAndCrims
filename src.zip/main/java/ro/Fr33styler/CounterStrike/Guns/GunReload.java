/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ro.Fr33styler.CounterStrike.Guns;

public class GunReload {
    private int time;
    private double left;

    public GunReload(int n) {
        this.time = n;
        this.left = n;
    }

    public int getMaxTime() {
        return this.time;
    }

    public double getLeft() {
        return this.left;
    }

    public void setLeft(int n) {
        this.left = n;
    }
}
