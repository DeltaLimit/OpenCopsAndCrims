/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  ro.Fr33styler.CounterStrike.Handler.Game
 */
package ro.Fr33styler.CounterStrike.Guns;

import ro.Fr33styler.CounterStrike.Handler.Game;

public class GunCache {
    private int ticks = 0;
    private int rounds = 0;
    private final Game game;
    private int ticks_left = 30;
    private int yaw_direction = 0;
    private float accuracy_yaw = 0.0f;
    private float accuracy_pitch = 0.0f;
    private boolean firstShot = true;

    public GunCache(Game game, int n) {
        this.game = game;
        this.rounds = n;
    }

    public Game getGame() {
        return this.game;
    }

    public float getAccuracyYaw() {
        return this.accuracy_yaw;
    }

    public float getAccuracyPitch() {
        return this.accuracy_pitch;
    }

    public int getYawDirection() {
        return this.yaw_direction;
    }

    public void setYawDirection(int n) {
        this.yaw_direction = n;
    }

    public int getRounds() {
        return this.rounds;
    }

    public int getTicks() {
        return this.ticks;
    }

    public int getTicksLeft() {
        return this.ticks_left;
    }

    public void setTicksLeft(int n) {
        this.ticks_left = n;
    }

    public boolean isFirstShot() {
        return this.firstShot;
    }

    public void setTicks(int n) {
        this.ticks = n;
    }

    public void setRounds(int n) {
        this.rounds = n;
    }

    public void setFirstShot(boolean bl) {
        this.firstShot = bl;
    }

    public void setAccuracyYaw(float f) {
        this.accuracy_yaw = f;
    }

    public void setAccuracyPitch(float f) {
        this.accuracy_pitch = f;
    }
}
