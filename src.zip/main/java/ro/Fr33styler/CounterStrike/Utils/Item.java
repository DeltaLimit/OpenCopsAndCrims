/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package ro.Fr33styler.CounterStrike.Utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class Item {
    private String name;
    private int data;
    private Material material;

    public Item(ItemStack itemStack) {
        this.material = itemStack.getType();
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            this.data = itemMeta.getCustomModelData();
            this.name = itemMeta.getDisplayName();
        }
    }

    public Item(Material material, int n, String string) {
        this.material = material;
        this.data = n;
        this.name = string;
    }

    public boolean equals(ItemStack itemStack) {
        return itemStack != null && itemStack.getItemMeta() != null && itemStack.getType() == this.material && itemStack.getItemMeta().getDisplayName().contains((CharSequence)this.name);
    }

    public boolean equals(ItemStack itemStack, String string) {
        return itemStack != null && itemStack.getItemMeta() != null && itemStack.getType() == this.material && itemStack.getItemMeta().getDisplayName().equals((Object)(this.name + " \u00a77" + string));
    }

    public Material getType() {
        return this.material;
    }

    public String getName() {
        return this.name;
    }

    public int getData() {
        return this.data;
    }
}
