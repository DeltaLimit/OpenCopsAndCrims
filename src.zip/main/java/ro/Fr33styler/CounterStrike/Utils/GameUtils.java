/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 */
package ro.Fr33styler.CounterStrike.Utils;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;

public class GameUtils {
    private static String version = Bukkit.getServer().getClass().getPackage().getName().replace((CharSequence)".", (CharSequence)",").split(",")[3];

    public static String getServerVersion() {
        return version;
    }

    public static List<Location> getDeserializedLocations(List<String> list) {
        ArrayList arrayList = new ArrayList();
        for (String string : list) {
            arrayList.add((Object)GameUtils.getDeserializedLocation(string));
        }
        return arrayList;
    }

    public static List<String> getSerializedLocations(List<Location> list) {
        ArrayList arrayList = new ArrayList();
        for (Location location : list) {
            arrayList.add((Object)GameUtils.getSerializedLocation(location));
        }
        return arrayList;
    }

    public static boolean containsIgnoreCase(List<String> list, String string) {
        for (String string2 : list) {
            if (!string.equalsIgnoreCase(string2)) continue;
            return true;
        }
        return false;
    }

    public static String getSerializedLocation(Location location) {
        return location.getWorld().getName() + "," + ((double)location.getBlockX() + 0.5) + "," + location.getBlockY() + "," + ((double)location.getBlockZ() + 0.5) + "," + location.getYaw() + "," + location.getPitch();
    }

    public static Location getDeserializedLocation(String string) {
        if (string == null) {
            return null;
        }
        String[] stringArray = string.split(",");
        return new Location(Bukkit.getWorld((String)stringArray[0]), Double.parseDouble((String)stringArray[1]), Double.parseDouble((String)stringArray[2]) + 1.0, Double.parseDouble((String)stringArray[3]), Float.parseFloat((String)stringArray[4]), Float.parseFloat((String)stringArray[5]));
    }
}
