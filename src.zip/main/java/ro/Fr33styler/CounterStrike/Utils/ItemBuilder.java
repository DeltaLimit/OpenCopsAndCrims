/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  org.bukkit.Color
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.LeatherArmorMeta
 */
package ro.Fr33styler.CounterStrike.Utils;

import java.util.Arrays;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;

public class ItemBuilder {
    public static ItemStack create(Material material, Integer n, String string, String string2) {
        ItemStack itemStack = new ItemStack(material, n.intValue());
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(string.replace((CharSequence)"&", (CharSequence)"\u00a7"));
        if (string2 != null) {
            itemMeta.setLore(Arrays.asList((Object[])string2.replace((CharSequence)"&", (CharSequence)"\u00a7").split("#")));
        }
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public static ItemStack create(Material material, int n, String string, boolean bl) {
        ItemStack itemStack = new ItemStack(material, n);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (bl) {
            itemMeta.setUnbreakable(true);
        }
        itemMeta.setDisplayName(string.replace((CharSequence)"&", (CharSequence)"\u00a7"));
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public static ItemStack create(Material material, int n, int n2, String string) {
        ItemStack itemStack = new ItemStack(material, n);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.setCustomModelData(Integer.valueOf((int)n2));
            itemMeta.setDisplayName(string.replace((CharSequence)"&", (CharSequence)"\u00a7"));
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    public static ItemStack createItem(Material material, Color color, String string) {
        ItemStack itemStack = new ItemStack(material);
        LeatherArmorMeta leatherArmorMeta = (LeatherArmorMeta)itemStack.getItemMeta();
        leatherArmorMeta.setColor(color);
        itemStack.setItemMeta((ItemMeta)leatherArmorMeta);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(string.replace((CharSequence)"&", (CharSequence)"\u00a7"));
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public static ItemStack create(Material material, int n, int n2, String string, String string2) {
        ItemStack itemStack = new ItemStack(material, n);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.setCustomModelData(Integer.valueOf((int)n2));
            itemMeta.setDisplayName(string.replace((CharSequence)"&", (CharSequence)"\u00a7"));
            itemMeta.setLore(Arrays.asList((Object[])string2.replace((CharSequence)"&", (CharSequence)"\u00a7").split("#")));
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }
}
