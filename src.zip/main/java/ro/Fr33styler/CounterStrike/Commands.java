/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.bukkit.Location
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameSetup
 *  ro.Fr33styler.CounterStrike.Handler.GameState
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.Messages
 *  ro.Fr33styler.CounterStrike.Utils.GameUtils
 */
package ro.Fr33styler.CounterStrike;

import java.util.List;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameSetup;
import ro.Fr33styler.CounterStrike.Handler.GameState;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.Messages;
import ro.Fr33styler.CounterStrike.Utils.GameUtils;

public class Commands
implements CommandExecutor {
    private Main main;

    public Commands(Main main) {
        this.main = main;
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] stringArray) {
        if (stringArray.length == 0) {
            commandSender.sendMessage(Messages.PREFIX + " \u00a77Plugin made by \u00a7aFr33styler\u00a77.");
            commandSender.sendMessage(Messages.PREFIX + " \u00a77Type \u00a7c/cs help\u00a77 for help.");
        } else if (commandSender instanceof Player) {
            Player player = (Player)commandSender;
            if (commandSender.hasPermission("cs.admin")) {
                if (stringArray[0].equalsIgnoreCase("reload")) {
                    this.main.getServer().getPluginManager().disablePlugin((Plugin)this.main);
                    this.main.getServer().getPluginManager().enablePlugin((Plugin)this.main);
                    commandSender.sendMessage(Messages.PREFIX + " \u00a7aThe plugin has been reloaded succesfuly!");
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("enable")) {
                    if (stringArray.length != 2) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid arguments! Use \u00a7a/cs enable <id>");
                    } else {
                        try {
                            int n = Integer.valueOf((String)stringArray[1]);
                            Game game = this.main.getManager().getGame(n);
                            if (game != null) {
                                if (game.getState() != GameState.DISABLED) {
                                    commandSender.sendMessage("\u00a7cGame already enabled!");
                                } else {
                                    game.setState(GameState.WAITING);
                                    commandSender.sendMessage(Messages.PREFIX + " \u00a77Game \u00a7c" + n + "\u00a77 has been enabled!");
                                }
                            } else {
                                commandSender.sendMessage("\u00a7cGame doesn't exists!");
                            }
                        }
                        catch (NumberFormatException numberFormatException) {
                            commandSender.sendMessage("\u00a7cMust be a number!");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("disable")) {
                    if (stringArray.length != 2) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid arguments! Use \u00a7a/cs disable <id>");
                    } else {
                        try {
                            int n = Integer.valueOf((String)stringArray[1]);
                            Game game = this.main.getManager().getGame(n);
                            if (game != null) {
                                if (game.getState() == GameState.DISABLED) {
                                    commandSender.sendMessage("\u00a7cGame already disabled!");
                                } else {
                                    game.setState(GameState.DISABLED);
                                    commandSender.sendMessage(Messages.PREFIX + " \u00a77Game \u00a7c" + n + "\u00a77 has been disabled!");
                                }
                            } else {
                                commandSender.sendMessage("\u00a7cGame doesn't exists!");
                            }
                        }
                        catch (NumberFormatException numberFormatException) {
                            commandSender.sendMessage("\u00a7cMust be a number!");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("create")) {
                    if (stringArray.length != 5) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid arguments! Use \u00a7a/cs create <id> <name> <min_players> <max_players>");
                    } else {
                        try {
                            int n = Integer.valueOf((String)stringArray[1]);
                            int n2 = Integer.valueOf((String)stringArray[3]);
                            int n3 = Integer.valueOf((String)stringArray[4]);
                            if (this.main.getManager().getGame(n) == null) {
                                if (this.main.getSetup(player) == null) {
                                    if (n3 >= 2) {
                                        if (n3 % 2 == 0) {
                                            this.main.addSetup(player, new GameSetup(n, stringArray[2], n2, n3));
                                            player.sendMessage(Messages.PREFIX + " \u00a77Game made succesfuly. Please use \u00a7a/cs setlobby!");
                                        } else {
                                            player.sendMessage("\u00a7cMax player should be equal for both teams!");
                                        }
                                    } else {
                                        player.sendMessage("\u00a7cMax player number can be at least 2!");
                                    }
                                } else {
                                    player.sendMessage(Messages.PREFIX + " \u00a7aThe setup is already made!");
                                }
                            } else {
                                player.sendMessage("\u00a7cGame already exists!");
                            }
                        }
                        catch (NumberFormatException numberFormatException) {
                            commandSender.sendMessage("\u00a7cMust be a number!");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("setlobby")) {
                    if (stringArray.length != 1) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs setlobby");
                    } else {
                        GameSetup gameSetup = this.main.getSetup(player);
                        if (gameSetup != null) {
                            gameSetup.setLobby(player.getLocation().add(0.0, 1.0, 0.0).clone());
                            player.sendMessage(Messages.PREFIX + " \u00a77Lobby succesfuly created. Please use \u00a7a/cs addcop!");
                        } else {
                            player.sendMessage("\u00a7cYou don't have anything in setup! Use /cs create <id> <name> <min_players> <max_players>");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("addcop")) {
                    if (stringArray.length != 1) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs addcop");
                    } else {
                        GameSetup gameSetup = this.main.getSetup(player);
                        if (gameSetup != null) {
                            int n = gameSetup.getMax() / 2;
                            if (gameSetup.getCops().size() == n) {
                                player.sendMessage(Messages.PREFIX + " \u00a7cYou can't set more cop spawns. Please use \u00a7a/cs addcrim");
                            } else {
                                gameSetup.getCops().add((Object)player.getLocation().add(0.0, 1.0, 0.0).clone());
                                if (gameSetup.getCops().size() == n) {
                                    player.sendMessage(Messages.PREFIX + " \u00a77You made all cop spawns. Please use \u00a7a/cs addcrim");
                                } else {
                                    player.sendMessage(Messages.PREFIX + " \u00a77Spawn number \u00a7e" + gameSetup.getCops().size() + " \u00a77added in game \u00a7a" + gameSetup.getID() + " \u00a78(\u00a7d" + gameSetup.getCops().size() + "/" + n + "\u00a78)");
                                }
                            }
                        } else {
                            player.sendMessage("\u00a7cYou don't have anything in setup! Use /cs create <id> <name> <min_players> <max_players>");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("addcrim")) {
                    if (stringArray.length != 1) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs addcrim");
                    } else {
                        GameSetup gameSetup = this.main.getSetup(player);
                        if (gameSetup != null) {
                            int n = gameSetup.getMax() / 2;
                            if (gameSetup.getCriminals().size() == n) {
                                player.sendMessage(Messages.PREFIX + " \u00a7cYou can't set more crim spawns. Please use \u00a7a/cs addbombsite");
                            } else {
                                gameSetup.getCriminals().add((Object)player.getLocation().add(0.0, 1.0, 0.0).clone());
                                if (gameSetup.getCriminals().size() == n) {
                                    player.sendMessage(Messages.PREFIX + " \u00a77You made all crim spawns. Please use \u00a7a/cs addbombsite");
                                } else {
                                    player.sendMessage(Messages.PREFIX + " \u00a77Spawn number \u00a7e" + gameSetup.getCriminals().size() + " \u00a77added in game \u00a7a" + gameSetup.getID() + " \u00a78(\u00a7d" + gameSetup.getCriminals().size() + "/" + n + "\u00a78)");
                                }
                            }
                        } else {
                            player.sendMessage("\u00a7cYou don't have anything in setup! Use /cs create <id> <name> <min_players> <max_players>");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("addbombsite")) {
                    if (stringArray.length != 1) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs addbombsite");
                    } else {
                        GameSetup gameSetup = this.main.getSetup(player);
                        if (gameSetup != null) {
                            gameSetup.getBombs().add((Object)player.getLocation().clone());
                            if (gameSetup.getBombs().size() == 2) {
                                player.sendMessage(Messages.PREFIX + " \u00a77You made 2 bomb site locations. You can set more or use \u00a7a/cs addfireworks");
                            } else {
                                player.sendMessage(Messages.PREFIX + " \u00a77Location with number \u00a7a" + gameSetup.getBombs().size() + " \u00a77succesfuly added!");
                            }
                        } else {
                            player.sendMessage("\u00a7cYou don't have anything in setup! Use /cs create <id> <name> <min_players> <max_players>");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("addfireworks")) {
                    if (stringArray.length != 1) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs addfireworks");
                    } else {
                        GameSetup gameSetup = this.main.getSetup(player);
                        if (gameSetup != null) {
                            gameSetup.getFireworks().add((Object)player.getLocation().clone());
                            if (gameSetup.getFireworks().size() == 10) {
                                player.sendMessage(Messages.PREFIX + " \u00a77Ten fireworks location has been setup. You can set more, or use \u00a7a/cs finish");
                            } else {
                                player.sendMessage(Messages.PREFIX + " \u00a77The location with number \u00a7a \u00a78(\u00a7d" + gameSetup.getFireworks().size() + "/10\u00a78) \u00a77has been added!");
                            }
                        } else {
                            player.sendMessage("\u00a7cYou don't have anything in setup! Use /cs create <id> <name> <min_players> <max_players>");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("setspawn")) {
                    Location location = player.getLocation().clone().add(0.0, 1.0, 0.0);
                    this.main.getManager().setSpawn(location);
                    this.main.getGameDatabase().set("GameLobby", (Object)GameUtils.getSerializedLocation((Location)location));
                    this.main.saveGameDatabase();
                    commandSender.sendMessage(Messages.PREFIX + " \u00a7aSpawn set succefully!");
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("finish")) {
                    if (stringArray.length != 1) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs finish");
                    } else {
                        GameSetup gameSetup = this.main.getSetup(player);
                        if (gameSetup != null) {
                            int n = gameSetup.getMax() / 2;
                            if (gameSetup.getCops().size() != n) {
                                player.sendMessage(Messages.PREFIX + " \u00a77You must add more cop spawn locations. Please use \u00a7a/cs addcop");
                            } else if (gameSetup.getCriminals().size() != n) {
                                player.sendMessage(Messages.PREFIX + " \u00a77You must add more criminal spawn locations. Please use \u00a7a/cs addcrim");
                            } else if (gameSetup.getLobby() == null) {
                                player.sendMessage("\u00a7cNo lobby has been set-up! Use \u00a7a/cs setlobby");
                            } else if (this.main.getManager().getGame(gameSetup.getID().intValue()) != null) {
                                player.sendMessage("\u00a7cThe game has been already created meanwhile!");
                            } else if (gameSetup.getFireworks().isEmpty()) {
                                player.sendMessage(Messages.PREFIX + " \u00a77You must add at least 1 firework locations. Please use \u00a7a/cs addfireworks");
                            } else {
                                this.main.getManager().addGame(new Game(this.main, gameSetup.getID().intValue(), gameSetup.getLobby(), gameSetup.getName(), gameSetup.getMin(), gameSetup.getCops(), gameSetup.getCriminals(), gameSetup.getBombs(), gameSetup.getFireworks()));
                                this.main.getGameDatabase().set("Game." + gameSetup.getID() + ".Min", (Object)gameSetup.getMin());
                                this.main.getGameDatabase().set("Game." + gameSetup.getID() + ".Name", (Object)gameSetup.getName());
                                this.main.getGameDatabase().set("Game." + gameSetup.getID() + ".Lobby", (Object)GameUtils.getSerializedLocation((Location)gameSetup.getLobby()));
                                this.main.getGameDatabase().set("Game." + gameSetup.getID() + ".CopSpawns", (Object)GameUtils.getSerializedLocations((List)gameSetup.getCops()));
                                this.main.getGameDatabase().set("Game." + gameSetup.getID() + ".CriminalSpawns", (Object)GameUtils.getSerializedLocations((List)gameSetup.getCriminals()));
                                this.main.getGameDatabase().set("Game." + gameSetup.getID() + ".BombSites", (Object)GameUtils.getSerializedLocations((List)gameSetup.getBombs()));
                                this.main.getGameDatabase().set("Game." + gameSetup.getID() + ".Fireworks", (Object)GameUtils.getSerializedLocations((List)gameSetup.getFireworks()));
                                this.main.saveGameDatabase();
                                this.main.removeSetup(player);
                                player.sendMessage(Messages.PREFIX + " \u00a7aGame created succesfuly!");
                            }
                        } else {
                            player.sendMessage("\u00a7cYou don't have anything in setup! Use /cs create <id> <name> <min_players> <max_players>");
                        }
                    }
                    return true;
                }
                if (stringArray[0].equalsIgnoreCase("delete")) {
                    if (stringArray.length != 2) {
                        commandSender.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs delete <id>");
                    } else {
                        try {
                            int n = Integer.parseInt((String)stringArray[1]);
                            Game game = this.main.getManager().getGame(n);
                            if (game != null) {
                                this.main.getManager().stopGame(game, false);
                                this.main.getManager().removeGame(game);
                                player.sendMessage(Messages.PREFIX + " \u00a77Game removed succesfuly.");
                                this.main.getGameDatabase().set("Game." + n, null);
                                this.main.saveGameDatabase();
                            } else {
                                player.sendMessage("\u00a7cGame doesn't exists!");
                            }
                        }
                        catch (NumberFormatException numberFormatException) {
                            player.sendMessage("\u00a7cMust be a number!");
                        }
                    }
                    return true;
                }
            }
            if (stringArray[0].equalsIgnoreCase("setlobby")) {
                if (stringArray.length != 1) {
                    player.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs setlobby");
                }
            } else if (stringArray[0].equalsIgnoreCase("join")) {
                if (stringArray.length != 2) {
                    player.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs join <id>");
                } else {
                    try {
                        int n = Integer.parseInt((String)stringArray[1]);
                        this.main.getManager().addPlayer(player, this.main.getManager().getGame(n));
                    }
                    catch (NumberFormatException numberFormatException) {
                        player.sendMessage("\u00a7cMust be a number!");
                    }
                }
            } else if (stringArray[0].equalsIgnoreCase("quickjoin")) {
                if (stringArray.length != 1) {
                    player.sendMessage(Messages.PREFIX + " \u00a77Invalid argument! Use \u00a7a/cs quickjoin");
                } else {
                    Game game = this.main.getManager().findGame(player);
                    if (game != null) {
                        if (game.getState() == GameState.WAITING) {
                            this.main.getManager().addPlayer(player, game);
                        } else if (game.getState() == GameState.IN_GAME || game.getState() == GameState.ROUND) {
                            this.main.getManager().addQuickPlayer(game, player);
                        }
                    }
                }
            } else if (stringArray[0].equalsIgnoreCase("leave")) {
                Game game = this.main.getManager().getGame(player);
                if (game == null) {
                    player.sendMessage("\u00a7cYou must be in a game to use this command!");
                } else {
                    player.sendMessage(Messages.PREFIX + Messages.GAME_LEFT.toString());
                    this.main.getManager().removePlayer(game, player, false, false);
                }
            } else if (stringArray[0].equalsIgnoreCase("help")) {
                player.sendMessage(Messages.PREFIX + " \u00a77- \u00a7dHelp");
                player.sendMessage("- \u00a78/\u00a7ccs join \u00a78<\u00a7aid\u00a78>");
                player.sendMessage("- \u00a78/\u00a7ccs quickjoin");
                player.sendMessage("- \u00a78/\u00a7ccs leave");
                if (player.hasPermission("cs.admin")) {
                    player.sendMessage("- \u00a78/\u00a7ccs reload");
                    player.sendMessage("- \u00a78/\u00a7ccs setspawn");
                    player.sendMessage("- \u00a78/\u00a7ccs delete \u00a78<\u00a7aid\u00a78>");
                    player.sendMessage("- \u00a78/\u00a7ccs enable \u00a78<\u00a7aid\u00a78>");
                    player.sendMessage("- \u00a78/\u00a7ccs disable \u00a78<\u00a7aid\u00a78>");
                    player.sendMessage("- \u00a78/\u00a7ccs create \u00a78<\u00a7aid\u00a78> \u00a78<\u00a7aname\u00a78> \u00a78<\u00a7amin\u00a78> \u00a78<\u00a7amax\u00a78>");
                }
            } else {
                commandSender.sendMessage("\u00a7eUnknown command, type /cs for help");
            }
        }
        return false;
    }
}
