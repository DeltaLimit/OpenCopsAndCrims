/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.OfflinePlayer
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameState
 *  ro.Fr33styler.CounterStrike.Main
 */
package ro.Fr33styler.CounterStrike.Hooks;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameState;
import ro.Fr33styler.CounterStrike.Main;

public class PlaceholderAPIHook
extends PlaceholderExpansion {
    private Main main;

    public PlaceholderAPIHook(Main main) {
        this.main = main;
    }

    public boolean canRegister() {
        return true;
    }

    public boolean persist() {
        return true;
    }

    public String getAuthor() {
        return "Fr33styler";
    }

    public String getIdentifier() {
        return "cac";
    }

    public String getVersion() {
        return this.main.getDescription().getDescription();
    }

    public String onRequest(OfflinePlayer offlinePlayer, String string) {
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        for (Game game : this.main.getManager().getGames()) {
            int n4 = game.getID();
            int n5 = game.getTeamA().getPlayers().size() + game.getTeamB().getPlayers().size();
            if (string.equals((Object)(n4 + "_status"))) {
                return game.getState().getState();
            }
            if (string.equals((Object)(n4 + "_players"))) {
                return String.valueOf((int)n5);
            }
            n3 += n5;
            if (game.getState() == GameState.WAITING) continue;
            ++n;
        }
        if (string.equals((Object)"totalwins")) {
            return String.valueOf((int)n2);
        }
        if (string.equals((Object)"allplayers")) {
            return String.valueOf((int)n3);
        }
        if (string.equals((Object)"ongoing")) {
            return String.valueOf((int)n);
        }
        return null;
    }
}
