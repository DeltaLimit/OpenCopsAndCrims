/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.sql.Connection
 *  java.sql.DriverManager
 *  java.sql.SQLException
 *  java.sql.Statement
 *  java.util.ArrayList
 *  java.util.List
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  ro.Fr33styler.CounterStrike.Cache.PlayerStatus
 *  ro.Fr33styler.CounterStrike.Main
 */
package ro.Fr33styler.CounterStrike.MySQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import ro.Fr33styler.CounterStrike.Cache.PlayerStatus;
import ro.Fr33styler.CounterStrike.Main;

public class MySQL
extends BukkitRunnable {
    private int amountQueue;
    private Connection connection;
    private List<PlayerStatus> status;

    public MySQL(Main main, String string, String string2, String string3, String string4, int n, int n2) {
        try {
            this.connection = DriverManager.getConnection((String)("jdbc:mysql://" + string + ":" + n + "/" + string2 + "?autoReconnect=true"), (String)string3, (String)string4);
            this.amountQueue = n2;
            this.status = new ArrayList();
            Statement statement = this.connection.createStatement();
            this.runTaskTimerAsynchronously((Plugin)main, 0L, 20L);
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS CounterStrike (id INTEGER NOT NULL AUTO_INCREMENT, UUID VARCHAR(36) UNIQUE, NAME VARCHAR(16), KILLS INTEGER, DEATHS INTEGER, HEADSHOTS INTEGER, BOMBPLANTED INTEGER, PRIMARY KEY (id))");
            statement.close();
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    public List<PlayerStatus> getCache() {
        return this.status;
    }

    public Connection getConnection() {
        return this.connection;
    }

    public void addInQueue(PlayerStatus playerStatus) {
        if (!this.status.contains((Object)playerStatus)) {
            this.status.add((Object)playerStatus);
        }
    }

    public void closeConnection() {
        try {
            Statement statement = this.connection.createStatement();
            for (PlayerStatus playerStatus : this.status) {
                statement.executeUpdate("INSERT INTO CounterStrike (UUID, NAME, KILLS, DEATHS, HEADSHOTS, BOMBPLANTED) VALUES ('" + playerStatus.getUUID() + "', '" + playerStatus.getName() + "', " + playerStatus.getKills() + ", " + playerStatus.getDeaths() + ", " + playerStatus.getHeadshotKill() + ", " + playerStatus.getBombPlanted() + ") ON DUPLICATE KEY UPDATE NAME='" + playerStatus.getName() + "', KILLS=KILLS+" + playerStatus.getKills() + ", DEATHS=DEATHS+" + playerStatus.getDeaths() + ", HEADSHOTS=HEADSHOTS+" + playerStatus.getHeadshotKill() + ", BOMBPLANTED=BOMBPLANTED+" + playerStatus.getBombPlanted() + ";");
            }
            this.status.clear();
            statement.close();
            this.connection.close();
            this.cancel();
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    public void run() {
        if (this.status.size() >= this.amountQueue) {
            try {
                Statement statement = this.connection.createStatement();
                for (PlayerStatus playerStatus : this.status) {
                    try {
                        statement.executeUpdate("INSERT INTO CounterStrike (UUID, NAME, KILLS, DEATHS, HEADSHOTS, BOMBPLANTED) VALUES ('" + playerStatus.getUUID() + "', '" + playerStatus.getName() + "', " + playerStatus.getKills() + ", " + playerStatus.getDeaths() + ", " + playerStatus.getHeadshotKill() + ", " + playerStatus.getBombPlanted() + ") ON DUPLICATE KEY UPDATE NAME='" + playerStatus.getName() + "', KILLS=KILLS+" + playerStatus.getKills() + ", DEATHS=DEATHS+" + playerStatus.getDeaths() + ", HEADSHOTS=HEADSHOTS+" + playerStatus.getHeadshotKill() + ", BOMBPLANTED=BOMBPLANTED+" + playerStatus.getBombPlanted() + ";");
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
                statement.close();
                this.status.clear();
            }
            catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
    }
}
