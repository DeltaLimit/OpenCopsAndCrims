/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map$Entry
 *  java.util.UUID
 *  org.bukkit.Color
 *  org.bukkit.FireworkEffect
 *  org.bukkit.FireworkEffect$Builder
 *  org.bukkit.FireworkEffect$Type
 *  org.bukkit.Location
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Firework
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.meta.FireworkMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  ro.Fr33styler.CounterStrike.Guns.Gun
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameState
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.Messages
 *  ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard
 *  ro.Fr33styler.CounterStrike.Version.MathUtils
 */
package ro.Fr33styler.CounterStrike;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import ro.Fr33styler.CounterStrike.Guns.Gun;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameState;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.Messages;
import ro.Fr33styler.CounterStrike.ScoreBoard.ScoreBoard;
import ro.Fr33styler.CounterStrike.Version.MathUtils;

public class UpdateTask
extends BukkitRunnable {
    private Main main;
    private long ticks = 0L;
    private List<FireworkEffect> effects;
    private HashMap<UUID, Integer> delay = new HashMap();

    public UpdateTask(Main main) {
        this.main = main;
        this.effects = new ArrayList();
        FireworkEffect.Builder builder = FireworkEffect.builder().trail(false).flicker(false);
        builder.withColor(new Color[]{Color.RED, Color.YELLOW, Color.GREEN, Color.BLUE});
        this.effects.add((Object)builder.with(FireworkEffect.Type.BALL).build());
        this.effects.add((Object)builder.with(FireworkEffect.Type.BALL_LARGE).build());
        this.effects.add((Object)builder.with(FireworkEffect.Type.BURST).build());
        this.runTaskTimer((Plugin)main, 0L, 1L);
    }

    public HashMap<UUID, Integer> getDelay() {
        return this.delay;
    }

    public void run() {
        Iterator iterator = this.delay.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            if ((Integer)entry.getValue() > 0) {
                entry.setValue((Object)((Integer)entry.getValue() - 1));
                continue;
            }
            iterator.remove();
        }
        for (Gun gun : this.main.getGuns()) {
            gun.tick();
        }
        for (Gun gun : this.main.getGrenades()) {
            gun.tick(this.ticks);
        }
        for (Gun gun : this.main.getManager().getGames()) {
            if (gun.getState() == GameState.END && this.ticks % 10L == 0L && gun.getTimer() >= 2) {
                Iterator iterator2 = (Location)gun.getFireworks().get(MathUtils.random().nextInt(gun.getFireworks().size()));
                double d = iterator2.getX();
                double d2 = iterator2.getY();
                double d3 = iterator2.getZ();
                for (int i = 0; i < 4; ++i) {
                    iterator2.setX(d + (double)MathUtils.randomRange((int)-20, (int)20));
                    iterator2.setY(d2 + (double)MathUtils.randomRange((int)-5, (int)5));
                    iterator2.setZ(d3 + (double)MathUtils.randomRange((int)-20, (int)20));
                    Firework firework = (Firework)iterator2.getWorld().spawnEntity((Location)iterator2, EntityType.FIREWORK);
                    FireworkMeta fireworkMeta = firework.getFireworkMeta();
                    fireworkMeta.addEffect((FireworkEffect)this.effects.get(MathUtils.random().nextInt(this.effects.size())));
                    firework.setFireworkMeta(fireworkMeta);
                    firework.detonate();
                    iterator2.setX(d);
                    iterator2.setY(d2);
                    iterator2.setZ(d3);
                }
            }
            if (this.ticks % 20L != 0L) continue;
            if (gun.getTimer() > 0) {
                for (ScoreBoard scoreBoard : gun.getStatus().values()) {
                    this.main.getManager().updateStatus((Game)gun, scoreBoard.getStatus());
                }
            }
            try {
                gun.run();
            }
            catch (Exception exception) {
                exception.printStackTrace();
                this.main.getManager().stopGame((Game)gun, false);
            }
            if (gun.getState() != GameState.WAITING || gun.getTeamA().size() + gun.getTeamB().size() >= gun.getMinPlayers()) continue;
            for (Player player : gun.getTeamA().getPlayers()) {
                this.main.getVersionInterface().sendActionBar(player, Messages.BAR_PLAYERS.toString().replace((CharSequence)"%min%", (CharSequence)(gun.getMinPlayers() + "")));
            }
            for (Player player : gun.getTeamB().getPlayers()) {
                this.main.getVersionInterface().sendActionBar(player, Messages.BAR_PLAYERS.toString().replace((CharSequence)"%min%", (CharSequence)(gun.getMinPlayers() + "")));
            }
        }
        ++this.ticks;
    }
}
