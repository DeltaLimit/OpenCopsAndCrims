/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem
 */
package ro.Fr33styler.CounterStrike.Grenades;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem;

public class GrenadeCache {
    private Game g;
    private Player p;
    private long time;
    private Long duration;
    private NMSPsyhicsItem grenade;
    private List<Block> blocks = new ArrayList();

    public GrenadeCache(Game game, long l, Player player, NMSPsyhicsItem nMSPsyhicsItem) {
        this.g = game;
        this.p = player;
        this.time = l;
        this.grenade = nMSPsyhicsItem;
    }

    public Game getGame() {
        return this.g;
    }

    public Long getDuration() {
        return this.duration;
    }

    public List<Block> getBlocks() {
        return this.blocks;
    }

    public void setDuration(long l) {
        this.duration = l;
    }

    public long getTime() {
        return this.time;
    }

    public Player getPlayer() {
        return this.p;
    }

    public NMSPsyhicsItem getGrenade() {
        return this.grenade;
    }

    public List<Player> getNearbyPlayers(double d) {
        ArrayList arrayList = new ArrayList();
        for (Player player : this.g.getTeamA().getPlayers()) {
            if (player.getLocation().getWorld() != this.grenade.getLocation().getWorld() || !(player.getLocation().distance(this.grenade.getLocation()) <= d)) continue;
            arrayList.add((Object)player);
        }
        for (Player player : this.g.getTeamB().getPlayers()) {
            if (player.getLocation().getWorld() != this.grenade.getLocation().getWorld() || !(player.getLocation().distance(this.grenade.getLocation()) <= d)) continue;
            arrayList.add((Object)player);
        }
        return arrayList;
    }

    public List<Player> getNearbyToBlockPlayers() {
        ArrayList arrayList = new ArrayList();
        for (Player player : this.g.getTeamA().getPlayers()) {
            for (Block block : this.blocks) {
                if (player.getLocation().getWorld() != block.getWorld() || !(player.getLocation().distance(block.getLocation()) <= 1.0)) continue;
                arrayList.add((Object)player);
            }
        }
        for (Player player : this.g.getTeamB().getPlayers()) {
            for (Block block : this.blocks) {
                if (player.getLocation().getWorld() != block.getWorld() || !(player.getLocation().distance(block.getLocation()) <= 1.5)) continue;
                arrayList.add((Object)player);
            }
        }
        return arrayList;
    }
}
