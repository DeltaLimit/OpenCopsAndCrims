/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.block.data.Ageable
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.entity.Player
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.util.Vector
 *  ro.Fr33styler.CounterStrike.Grenades.GrenadeCache
 *  ro.Fr33styler.CounterStrike.Grenades.GrenadeType
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam$Role
 *  ro.Fr33styler.CounterStrike.Main
 *  ro.Fr33styler.CounterStrike.Utils.Item
 *  ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem
 *  ro.Fr33styler.CounterStrike.Version.MathUtils
 */
package ro.Fr33styler.CounterStrike.Grenades;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import ro.Fr33styler.CounterStrike.Grenades.GrenadeCache;
import ro.Fr33styler.CounterStrike.Grenades.GrenadeType;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameTeam;
import ro.Fr33styler.CounterStrike.Main;
import ro.Fr33styler.CounterStrike.Utils.Item;
import ro.Fr33styler.CounterStrike.Version.Entity.NMSPsyhicsItem;
import ro.Fr33styler.CounterStrike.Version.MathUtils;

public class Grenade {
    private Item item;
    private double effect_power;
    private String symbol;
    private String name;
    private int delay;
    private Main main;
    private int duration;
    private GrenadeType type;
    private double throwSpeed;
    private List<GrenadeCache> played = new ArrayList();

    public Grenade(Main main, String string, GrenadeType grenadeType, Item item, int n, int n2, double d, double d2, String string2) {
        this.type = grenadeType;
        this.item = item;
        this.name = string;
        this.main = main;
        this.duration = n2;
        this.effect_power = d2;
        this.symbol = string2;
        this.delay = n;
        this.throwSpeed = d;
    }

    public void throwGrenade(Main main, Game game, Player player) {
        if (player.getInventory().getHeldItemSlot() == this.type.getSlot()) {
            NMSPsyhicsItem nMSPsyhicsItem = main.getVersionInterface().spawnPsyhicsItem(player, player.getItemInHand(), this.throwSpeed);
            this.played.add((Object)new GrenadeCache(game, System.currentTimeMillis(), player, nMSPsyhicsItem));
            player.getInventory().setItem(this.type.getSlot(), null);
            for (Player player2 : main.getManager().getTeam(game, main.getManager().getTeam(game, player)).getPlayers()) {
                player2.playSound(player.getEyeLocation(), this.type.getSound(), 1.0f, 1.0f);
            }
        }
    }

    public String getName() {
        return this.name;
    }

    public String getSymbol() {
        return this.symbol;
    }

    public GrenadeType getGrenadeType() {
        return this.type;
    }

    public void tick(long l) {
        Iterator iterator = this.played.iterator();
        while (iterator.hasNext()) {
            Vector vector;
            Location location;
            GrenadeCache grenadeCache = (GrenadeCache)iterator.next();
            if ((System.currentTimeMillis() - grenadeCache.getTime()) / 1000L < (long)this.delay) continue;
            Location location2 = grenadeCache.getGrenade().getLocation();
            if (this.type == GrenadeType.FRAG) {
                for (Player player : this.main.getManager().getTeam(grenadeCache.getGame(), GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                    player.playSound(location2, "cs.throwables.explodegrenade", 1.0f, 1.0f);
                }
                for (Player player : this.main.getManager().getTeam(grenadeCache.getGame(), GameTeam.Role.TERRORIST).getPlayers()) {
                    player.playSound(location2, "cs.throwables.explodegrenade", 1.0f, 1.0f);
                }
                location2.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, location2, 15);
                for (Player player : grenadeCache.getNearbyPlayers(7.0)) {
                    if (grenadeCache.getPlayer() != player && this.main.getManager().getTeam(grenadeCache.getGame(), grenadeCache.getPlayer()) == this.main.getManager().getTeam(grenadeCache.getGame(), player) || grenadeCache.getGame().getSpectators().contains((Object)player)) continue;
                    location = player.getEyeLocation().clone();
                    vector = location2.toVector().subtract(location.toVector());
                    boolean bl = false;
                    int n = 0;
                    while ((long)n < Math.round((double)location2.distance(location)) + 1L) {
                        location.add(vector.normalize());
                        if (location.getBlock().getType() != Material.AIR) {
                            bl = true;
                            break;
                        }
                        ++n;
                    }
                    if (bl) continue;
                    this.main.getManager().damage(grenadeCache.getGame(), grenadeCache.getPlayer(), player, this.effect_power - grenadeCache.getGrenade().getLocation().distance(player.getLocation()) * 2.0, this.symbol);
                }
            }
            if (this.type == GrenadeType.FLASHBANG) {
                for (Player player : this.main.getManager().getTeam(grenadeCache.getGame(), GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                    player.playSound(location2, "cs.throwables.explodeflashbang", 1.0f, 1.0f);
                }
                for (Player player : this.main.getManager().getTeam(grenadeCache.getGame(), GameTeam.Role.TERRORIST).getPlayers()) {
                    player.playSound(location2, "cs.throwables.explodeflashbang", 1.0f, 1.0f);
                }
                for (Player player : grenadeCache.getNearbyPlayers(this.effect_power)) {
                    if (grenadeCache.getGame().getSpectators().contains((Object)player) && grenadeCache.getPlayer() != player && this.main.getManager().getTeam(grenadeCache.getGame(), grenadeCache.getPlayer()) == this.main.getManager().getTeam(grenadeCache.getGame(), player)) continue;
                    location = player.getEyeLocation();
                    vector = location2.toVector().subtract(location.toVector()).normalize();
                    Vector vector2 = location.getDirection();
                    float f = vector.angle(vector2);
                    if (!(location2.distanceSquared(location) <= 16.0) && (Float.isNaN((float)f) || !((double)f < 0.9))) continue;
                    Location location3 = player.getEyeLocation().clone();
                    Vector vector3 = location2.toVector().subtract(location3.toVector());
                    boolean bl = false;
                    int n = 0;
                    while ((long)n < Math.round((double)location2.distance(location3)) + 1L) {
                        location3.add(vector3.normalize());
                        if (location3.getBlock().getType() != Material.AIR) {
                            bl = true;
                            break;
                        }
                        ++n;
                    }
                    if (bl) continue;
                    player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, this.duration * 20, 2), true);
                }
            }
            if (this.type == GrenadeType.DECOY) {
                if (grenadeCache.getDuration() == null) {
                    grenadeCache.setDuration(System.currentTimeMillis());
                }
                if (grenadeCache.getDuration() == null) continue;
                if ((System.currentTimeMillis() - grenadeCache.getDuration()) / 1000L >= (long)this.duration) {
                    grenadeCache.getGrenade().remove();
                    iterator.remove();
                    continue;
                }
                if (l % 3L != 0L) continue;
                for (Player player : grenadeCache.getNearbyPlayers(20.0)) {
                    player.playSound(grenadeCache.getGrenade().getLocation(), "cs.weapons.ak47", 1.0f, 1.0f);
                    player.spawnParticle(Particle.SMOKE_LARGE, grenadeCache.getGrenade().getLocation(), 3, 0.1, 0.1, 0.1);
                }
                continue;
            }
            if (this.type == GrenadeType.SMOKE) {
                if (grenadeCache.getGrenade().isRemoved()) {
                    if ((System.currentTimeMillis() - grenadeCache.getDuration()) / 1000L < (long)this.duration) continue;
                    for (Player player : grenadeCache.getBlocks()) {
                        player.setType(Material.AIR);
                    }
                    grenadeCache.getBlocks().clear();
                    iterator.remove();
                    continue;
                }
                for (Player player : this.main.getManager().getTeam(grenadeCache.getGame(), GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                    player.playSound(location2, "cs.throwables.explodesmoke", 1.0f, 1.0f);
                }
                for (Player player : this.main.getManager().getTeam(grenadeCache.getGame(), GameTeam.Role.TERRORIST).getPlayers()) {
                    player.playSound(location2, "cs.throwables.explodesmoke", 1.0f, 1.0f);
                }
                for (Player player : this.getBlocks(grenadeCache.getGrenade().getLocation().getBlock(), this.effect_power)) {
                    if (player.getType() != Material.AIR) continue;
                    grenadeCache.getBlocks().add((Object)player);
                    player.setType(Material.WHEAT);
                    location = player.getBlockData();
                    ((Ageable)location).setAge(MathUtils.randomRange((int)1, (int)3));
                    player.setBlockData((BlockData)location);
                    player.getDrops().clear();
                }
                grenadeCache.setDuration(System.currentTimeMillis());
                grenadeCache.getGrenade().remove();
                continue;
            }
            if (this.type == GrenadeType.FIREBOMB) {
                if (grenadeCache.getGrenade().isRemoved()) {
                    if ((System.currentTimeMillis() - grenadeCache.getDuration()) / 1000L >= (long)this.duration) {
                        for (Player player : grenadeCache.getBlocks()) {
                            player.setType(Material.AIR);
                        }
                        grenadeCache.getBlocks().clear();
                        iterator.remove();
                        continue;
                    }
                    if (l % 15L != 0L) continue;
                    for (Player player : grenadeCache.getNearbyToBlockPlayers()) {
                        if (grenadeCache.getPlayer() != player && this.main.getManager().getTeam(grenadeCache.getGame(), grenadeCache.getPlayer()) == this.main.getManager().getTeam(grenadeCache.getGame(), player) || grenadeCache.getGame().getSpectators().contains((Object)player)) continue;
                        this.main.getManager().damage(grenadeCache.getGame(), grenadeCache.getPlayer(), player, 1.5, this.symbol);
                        player.setFireTicks(0);
                    }
                    continue;
                }
                for (Player player : this.main.getManager().getTeam(grenadeCache.getGame(), GameTeam.Role.COUNTERTERRORIST).getPlayers()) {
                    player.playSound(location2, "cs.throwables.explodefirebomb", 1.0f, 1.0f);
                }
                for (Player player : this.main.getManager().getTeam(grenadeCache.getGame(), GameTeam.Role.TERRORIST).getPlayers()) {
                    player.playSound(location2, "cs.throwables.explodefirebomb", 1.0f, 1.0f);
                }
                for (Player player : this.getBlocks(grenadeCache.getGrenade().getLocation().getBlock(), this.effect_power)) {
                    if (player.getType() == Material.AIR) {
                        location = player.getRelative(BlockFace.DOWN);
                        if (!location.getType().isSolid()) continue;
                        grenadeCache.getBlocks().add((Object)player);
                        player.setType(Material.FIRE);
                        player.getDrops().clear();
                        continue;
                    }
                    if (!player.getType().isSolid() || (location = player.getRelative(BlockFace.UP)).getType() != Material.AIR) continue;
                    grenadeCache.getBlocks().add((Object)location);
                    location.setType(Material.FIRE);
                    location.getDrops().clear();
                }
                grenadeCache.setDuration(System.currentTimeMillis());
                grenadeCache.getGrenade().remove();
                continue;
            }
            grenadeCache.getGrenade().remove();
            iterator.remove();
        }
    }

    public Item getItem() {
        return this.item;
    }

    public void removePlayer(Player player) {
        Iterator iterator = this.played.iterator();
        while (iterator.hasNext()) {
            GrenadeCache grenadeCache = (GrenadeCache)iterator.next();
            if (grenadeCache.getPlayer() != player) continue;
            for (Block block : grenadeCache.getBlocks()) {
                block.setType(Material.AIR);
            }
            grenadeCache.getGrenade().remove();
            iterator.remove();
        }
    }

    public void remove(Game game) {
        Iterator iterator = this.played.iterator();
        while (iterator.hasNext()) {
            GrenadeCache grenadeCache = (GrenadeCache)iterator.next();
            if (grenadeCache.getGame() != game) continue;
            for (Block block : grenadeCache.getBlocks()) {
                block.setType(Material.AIR);
            }
            grenadeCache.getGrenade().remove();
            iterator.remove();
        }
    }

    private ArrayList<Block> getBlocks(Block block, double d) {
        ArrayList arrayList = new ArrayList();
        int n = (int)d + 1;
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    Block block2 = block.getRelative(i, k, j);
                    if (!(block.getLocation().toVector().subtract(block2.getLocation().toVector()).length() <= d)) continue;
                    arrayList.add((Object)block2);
                }
            }
        }
        return arrayList;
    }
}
