/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package ro.Fr33styler.CounterStrike.Grenades;

public enum GrenadeType {
    FRAG(3, "cs.gamesounds.throwinggrenade"),
    FIREBOMB(3, "cs.gamesounds.throwingfirebomb"),
    DECOY(4, "cs.gamesounds.throwingdecoy"),
    SMOKE(4, "cs.gamesounds.throwingsmoke"),
    FLASHBANG(4, "cs.gamesounds.throwingflashbang");

    private int slot;
    private String sound;

    private GrenadeType(int n2, String string2) {
        this.slot = n2;
        this.sound = string2;
    }

    public int getSlot() {
        return this.slot;
    }

    public String getSound() {
        return this.sound;
    }
}
