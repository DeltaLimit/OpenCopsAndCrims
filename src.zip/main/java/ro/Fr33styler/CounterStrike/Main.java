/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLConnection
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.List
 *  java.util.UUID
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.java.JavaPlugin
 *  ro.Fr33styler.CounterStrike.Cache.PlayerShop
 *  ro.Fr33styler.CounterStrike.Grenades.Grenade
 *  ro.Fr33styler.CounterStrike.Guns.Gun
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameListener
 *  ro.Fr33styler.CounterStrike.Handler.GameManager
 *  ro.Fr33styler.CounterStrike.Handler.GameSetup
 *  ro.Fr33styler.CounterStrike.MySQL.MySQL
 *  ro.Fr33styler.CounterStrike.UpdateTask
 *  ro.Fr33styler.CounterStrike.Version.VersionInterface
 */
package ro.Fr33styler.CounterStrike;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import ro.Fr33styler.CounterStrike.Cache.PlayerShop;
import ro.Fr33styler.CounterStrike.Grenades.Grenade;
import ro.Fr33styler.CounterStrike.Guns.Gun;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameListener;
import ro.Fr33styler.CounterStrike.Handler.GameManager;
import ro.Fr33styler.CounterStrike.Handler.GameSetup;
import ro.Fr33styler.CounterStrike.MySQL.MySQL;
import ro.Fr33styler.CounterStrike.UpdateTask;
import ro.Fr33styler.CounterStrike.Version.VersionInterface;

public class Main
extends JavaPlugin {
    private MySQL mysql;
    private static Main main;
    private UpdateTask update;
    private int lobby_time = 10;
    private int round_time = 120;
    private int bomb_time = 45;
    private int round_to_win = 8;
    private double hitAddition = 0.0;
    private boolean blood = false;
    private boolean boss = true;
    private boolean autojoin = true;
    private boolean shutdown = false;
    private String bungee_hub;
    private boolean bungee;
    private int maxRadius = 100;
    private boolean canjoinstartedgame = false;
    private int round_to_switch = 6;
    private int round_win_money = 3000;
    private int round_lose_money = 2000;
    private int bomb_plant_money = 150;
    private boolean compass = true;
    private boolean force_texture = true;
    private GameManager manager = null;
    private boolean hide_vip_guns = false;
    private boolean bungee_random = false;
    private YamlConfiguration gun = null;
    private YamlConfiguration grenade = null;
    private GameListener listener = null;
    private YamlConfiguration shop = null;
    private VersionInterface version = null;
    private FileConfiguration config = null;
    private YamlConfiguration database = null;
    private YamlConfiguration messages = null;
    private String copsdefaultweapon = "P250";
    private String crimsdefaultweapon = "P250";
    private List<Gun> guns = new ArrayList();
    private boolean ReplaceGunsWithoutDrop = false;
    private Material defaultCrimKnife = Material.IRON_AXE;
    private Material defaultCopKnife = Material.STONE_AXE;
    private String defaulthelmetname = "&aKevlar Helmet";
    private String defaultchestplatename = "&aKevlar Vest";
    private List<UUID> TextureUsers = new ArrayList();
    private List<String> whitelist = new ArrayList();
    private String end_command_win = "money give %player% 30";
    private List<Grenade> grenades = new ArrayList();
    private String end_command_lose = "money give %player% 20";
    private String kill_win_command = "money give %player% 3";
    private boolean corpse = false;
    private boolean papi = false;
    private List<PlayerShop> shop_items = new ArrayList();
    private HashMap<UUID, GameSetup> setup = new HashMap();

    /*
     * Exception decompiling
     */
    public void onEnable() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter$TooOptimisticMatchException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.getString(SwitchStringRewriter.java:404)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.access$600(SwitchStringRewriter.java:53)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter$SwitchStringMatchResultCollector.collectMatches(SwitchStringRewriter.java:368)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest.match(ResetAfterTest.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleeneN.match(KleeneN.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence.match(MatchSequence.java:26)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest.match(ResetAfterTest.java:23)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.rewriteComplex(SwitchStringRewriter.java:201)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.rewrite(SwitchStringRewriter.java:73)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:881)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.Main.doClass(Main.java:18)
         *     at org.benf.cfr.reader.PluginRunner.getDecompilationFor(PluginRunner.java:115)
         *     at cn.enaium.joe.service.decompiler.CFRDecompiler.decompile(CFRDecompiler.java:63)
         *     at cn.enaium.joe.task.SaveAllSourceTask.get(SaveAllSourceTask.java:60)
         *     at cn.enaium.joe.task.SaveAllSourceTask.get(SaveAllSourceTask.java:39)
         *     at java.util.concurrent.CompletableFuture$AsyncSupply.run(CompletableFuture.java:1604)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1149)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
         *     at java.lang.Thread.run(Thread.java:750)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public void onDisable() {
        if (this.manager != null) {
            for (Game game : this.manager.getGames()) {
                this.manager.stopGame(game, false);
                for (Entity entity : ((Location)game.getCounterTerroristLoc().get(0)).getWorld().getEntities()) {
                    if (entity.getType() != EntityType.DROPPED_ITEM) continue;
                    entity.remove();
                }
            }
            this.manager = null;
        }
        if (this.mysql != null) {
            this.mysql.closeConnection();
        }
        HandlerList.unregisterAll((Listener)this.listener);
        this.listener = null;
        if (this.update != null) {
            this.update.cancel();
            this.update = null;
        }
    }

    public YamlConfiguration getGameDatabase() {
        return this.database;
    }

    public VersionInterface getVersionInterface() {
        return this.version;
    }

    public GameListener getListener() {
        return this.listener;
    }

    public void loadConfig() {
        this.reloadConfig();
        this.config = this.getConfig();
        this.config.addDefault("Config.AutoJoinOnEnd", (Object)true);
        this.config.addDefault("Config.LobbyTime", (Object)30);
        this.config.addDefault("Config.RoundToWin", (Object)8);
        this.config.addDefault("Config.RoundToSwitch", (Object)6);
        this.config.addDefault("Config.TexturePack", (Object)true);
        this.config.addDefault("Config.GameRoundTime", (Object)120);
        this.config.addDefault("Config.BombExplodeTimer", (Object)45);
        this.config.addDefault("Config.RoundWinMoney", (Object)3000);
        this.config.addDefault("Config.RoundLoseMoney", (Object)2000);
        this.config.addDefault("Config.BombPlantMoney", (Object)150);
        this.config.addDefault("Config.MaxRadiusAsSpectator", (Object)100);
        this.config.addDefault("Config.HitAddition", (Object)0.0);
        this.config.addDefault("Config.HideVipGuns", (Object)false);
        this.config.addDefault("Config.EnableBlood", (Object)false);
        this.config.addDefault("Config.Compass", (Object)true);
        this.config.addDefault("Config.EnableBossBar", (Object)true);
        this.config.addDefault("Config.CopsDefaultGun", (Object)"P250");
        this.config.addDefault("Config.CrimsDefaultGun", (Object)"P250");
        this.config.addDefault("Config.DefaultCrimKnife", (Object)this.defaultCrimKnife.name());
        this.config.addDefault("Config.DefaultCopKnife", (Object)this.defaultCopKnife.name());
        this.config.addDefault("Config.DefaultHelmetName", (Object)"&aKevlar Helmet");
        this.config.addDefault("Config.DefaultChestplateName", (Object)"&aKevlar Vest");
        this.config.addDefault("Config.Whitelist", (Object)Arrays.asList((Object[])new String[]{"/mute", "/list"}));
        this.config.addDefault("Config.ReplaceGunsWithoutDrop", (Object)false);
        this.config.addDefault("Config.EndGameCommandWin", (Object)"money give %player% 30");
        this.config.addDefault("Config.EndGameCommandLose", (Object)"money give %player% 20");
        this.config.addDefault("Config.KillWinCommand", (Object)"money give %player% 2");
        this.config.addDefault("BungeeMode.Enabled", (Object)false);
        this.config.addDefault("BungeeMode.ShutDown", (Object)false);
        this.config.addDefault("BungeeMode.CanJoinStartedGames", (Object)true);
        this.config.addDefault("BungeeMode.ServerOnGameEnd", (Object)"Hub");
        this.config.addDefault("BungeeMode.RandomMap", (Object)false);
        this.config.addDefault("MySQL.Enabled", (Object)false);
        this.config.addDefault("MySQL.QueueAmount", (Object)20);
        this.config.addDefault("MySQL.Host", (Object)"127.0.0.1");
        this.config.addDefault("MySQL.Database", (Object)"database");
        this.config.addDefault("MySQL.Username", (Object)"Fr33styler");
        this.config.addDefault("MySQL.Password", (Object)"12345");
        this.config.addDefault("MySQL.Port", (Object)3306);
        this.config.options().copyDefaults(true);
        this.saveConfig();
        this.autojoin = this.config.getBoolean("Config.AutoJoinOnEnd");
        this.canjoinstartedgame = this.config.getBoolean("BungeeMode.CanJoinStartedGames");
        this.bungee = this.config.getBoolean("BungeeMode.Enabled");
        this.bungee_hub = this.config.getString("BungeeMode.ServerOnGameEnd");
        this.bungee_random = this.config.getBoolean("BungeeMode.RandomMap");
        this.blood = this.config.getBoolean("Config.EnableBlood");
        this.boss = this.config.getBoolean("Config.EnableBossBar");
        this.lobby_time = this.config.getInt("Config.LobbyTime");
        this.whitelist = this.config.getStringList("Config.Whitelist");
        this.round_time = this.config.getInt("Config.GameRoundTime");
        this.hitAddition = this.config.getDouble("Config.HitAddition");
        this.bomb_time = this.config.getInt("Config.BombExplodeTimer");
        this.compass = this.config.getBoolean("Config.Compass");
        this.maxRadius = this.config.getInt("Config.MaxRadiusAsSpectator");
        this.copsdefaultweapon = this.config.getString("Config.CopsDefaultGun");
        this.crimsdefaultweapon = this.config.getString("Config.CrimsDefaultGun");
        this.end_command_win = this.config.getString("Config.EndGameCommandWin");
        this.kill_win_command = this.config.getString("Config.KillWinCommand");
        this.end_command_lose = this.config.getString("Config.EndGameCommandLose");
        this.round_win_money = this.config.getInt("Config.RoundWinMoney");
        this.round_lose_money = this.config.getInt("Config.RoundLoseMoney");
        this.bomb_plant_money = this.config.getInt("Config.BombPlantMoney");
        this.round_to_switch = this.config.getInt("Config.RoundToSwitch");
        this.round_to_win = this.config.getInt("Config.RoundToWin");
        this.shutdown = this.config.getBoolean("BungeeMode.ShutDown");
        this.defaultCrimKnife = Material.valueOf((String)this.config.getString("Config.DefaultCrimKnife"));
        this.defaultCopKnife = Material.valueOf((String)this.config.getString("Config.DefaultCopKnife"));
        this.defaulthelmetname = this.config.getString("Config.DefaultHelmetName");
        this.defaultchestplatename = this.config.getString("Config.DefaultChestplateName");
        this.hide_vip_guns = this.config.getBoolean("Config.HideVipGuns");
        this.ReplaceGunsWithoutDrop = this.config.getBoolean("Config.ReplaceGunsWithoutDrop");
        this.force_texture = this.config.getBoolean("Config.TexturePack");
    }

    public void saveGameDatabase() {
        File file = new File(this.getDataFolder(), "database.yml");
        try {
            if (!file.exists()) {
                ArrayList arrayList;
                file.createNewFile();
                this.database = YamlConfiguration.loadConfiguration((File)file);
                if (this.database.getString("Signs") == null) {
                    arrayList = new ArrayList();
                    this.database.set("Signs", (Object)arrayList);
                }
                if (this.database.getString("QuickJoinSigns") == null) {
                    arrayList = new ArrayList();
                    this.database.set("QuickJoinSigns", (Object)arrayList);
                }
                if (this.database.getString("Game") == null) {
                    this.database.set("Game", (Object)"No game made yet");
                }
            }
            this.database.save(file);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public MySQL getMySQL() {
        return this.mysql;
    }

    public String getHub() {
        return this.bungee_hub;
    }

    public void addSetup(Player player, GameSetup gameSetup) {
        this.setup.put((Object)player.getUniqueId(), (Object)gameSetup);
    }

    public List<UUID> getTextureUsers() {
        return this.TextureUsers;
    }

    public void removeSetup(Player player) {
        this.setup.remove((Object)player.getUniqueId());
    }

    public GameSetup getSetup(Player player) {
        return (GameSetup)this.setup.get((Object)player.getUniqueId());
    }

    public List<Gun> getGuns() {
        return this.guns;
    }

    public boolean randomMap() {
        return this.bungee_random;
    }

    public List<Grenade> getGrenades() {
        return this.grenades;
    }

    public List<PlayerShop> getShops() {
        return this.shop_items;
    }

    public UpdateTask getUpdateTask() {
        return this.update;
    }

    public Gun getGun(ItemStack itemStack) {
        for (Gun gun : this.guns) {
            if (!gun.getItem().equals(itemStack, gun.getSymbol())) continue;
            return gun;
        }
        return null;
    }

    public Gun getGun(String string) {
        for (Gun gun : this.guns) {
            if (!gun.getName().equals((Object)string)) continue;
            return gun;
        }
        return null;
    }

    public Grenade getGrenade(String string) {
        for (Grenade grenade : this.grenades) {
            if (!grenade.getName().equals((Object)string)) continue;
            return grenade;
        }
        return null;
    }

    public Grenade getGrenade(ItemStack itemStack) {
        for (Grenade grenade : this.grenades) {
            if (!grenade.getItem().equals(itemStack)) continue;
            return grenade;
        }
        return null;
    }

    public GameManager getManager() {
        return this.manager;
    }

    public boolean hasCompass() {
        return this.compass;
    }

    public int getLobbyTime() {
        return this.lobby_time;
    }

    public int getRoundTime() {
        return this.round_time;
    }

    public int getRadius() {
        return this.maxRadius;
    }

    public int getRoundWinMoney() {
        return this.round_win_money;
    }

    public int getRoundToWin() {
        return this.round_to_win;
    }

    public int getRoundToSwitch() {
        return this.round_to_switch;
    }

    public int getRoundLoseMoney() {
        return this.round_lose_money;
    }

    public int getBombPlantMoney() {
        return this.bomb_plant_money;
    }

    public String getEndGameCommandWin() {
        return this.end_command_win;
    }

    public String getEndGameCommandLose() {
        return this.end_command_lose;
    }

    public String getKillCommand() {
        return this.kill_win_command;
    }

    public int getBombTime() {
        return this.bomb_time;
    }

    public double hitAddition() {
        return this.hitAddition;
    }

    public boolean replaceOldGuns() {
        return this.ReplaceGunsWithoutDrop;
    }

    public boolean shutdown() {
        return this.shutdown;
    }

    public List<String> getWhitelistCommands() {
        return this.whitelist;
    }

    public boolean hideVipGuns() {
        return this.hide_vip_guns;
    }

    public boolean enableBlood() {
        return this.blood;
    }

    public boolean enableBoss() {
        return this.boss;
    }

    public String getCopsDefaultWeapon() {
        return this.copsdefaultweapon;
    }

    public String getCrimsDefaultWeapon() {
        return this.crimsdefaultweapon;
    }

    public String getDefaultHelmetName() {
        return this.defaulthelmetname;
    }

    public String getDefaultChestplateName() {
        return this.defaultchestplatename;
    }

    public boolean canForceTexture() {
        return this.force_texture;
    }

    public Material getDefaultCrimKnife() {
        return this.defaultCrimKnife;
    }

    public Material getDefaultCopKnife() {
        return this.defaultCopKnife;
    }

    public boolean autoJoin() {
        return this.autojoin;
    }

    public boolean corpseSupport() {
        return this.corpse;
    }

    public boolean placeholderSupport() {
        return this.papi;
    }

    public boolean canJoinStartedGame() {
        return this.canjoinstartedgame;
    }

    public static Main getInstance() {
        return main;
    }

    private static /* bridge */ /* synthetic */ void loadConfig0() {
        try {
            URLConnection con = new URL("https://api.spigotmc.org/legacy/premium.php?user_id=230596&resource_id=16641&nonce=-897806254").openConnection();
            con.setConnectTimeout(1000);
            con.setReadTimeout(1000);
            ((HttpURLConnection)con).setInstanceFollowRedirects(true);
            String response = new BufferedReader((Reader)new InputStreamReader(con.getInputStream())).readLine();
            if ("false".equals((Object)response)) {
                throw new RuntimeException("Access to this plugin has been disabled! Please contact the author!");
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }
}
