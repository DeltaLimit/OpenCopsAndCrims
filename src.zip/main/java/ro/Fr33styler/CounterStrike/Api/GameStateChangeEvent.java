/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 *  ro.Fr33styler.CounterStrike.Handler.Game
 *  ro.Fr33styler.CounterStrike.Handler.GameState
 */
package ro.Fr33styler.CounterStrike.Api;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import ro.Fr33styler.CounterStrike.Handler.Game;
import ro.Fr33styler.CounterStrike.Handler.GameState;

public class GameStateChangeEvent
extends Event {
    private Game game;
    private GameState state;
    private static final HandlerList handlers = new HandlerList();

    public GameStateChangeEvent(Game game, GameState gameState) {
        this.game = game;
        this.state = gameState;
    }

    public GameState getState() {
        return this.state;
    }

    public Game getGame() {
        return this.game;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
