/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.bukkit.Location
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 */
package ro.Fr33styler.CounterStrike.Api;

import org.bukkit.Location;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class BombExplodeEvent
extends Event {
    private static final HandlerList handlers = new HandlerList();
    private Location l;

    public BombExplodeEvent(Location location) {
        this.l = location;
    }

    public Location getBombLocation() {
        return this.l;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
