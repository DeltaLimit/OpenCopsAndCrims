/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 */
package ro.Fr33styler.CounterStrike.Api;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class GunDamageEvent
extends Event {
    private double damage;
    private boolean isHeadshot;
    private Player damager;
    private Player victim;
    private static final HandlerList handlers = new HandlerList();

    public GunDamageEvent(double d, boolean bl, Player player, Player player2) {
        this.damage = d;
        this.isHeadshot = bl;
        this.damager = player;
        this.victim = player2;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public double getDamage() {
        return this.damage;
    }

    public boolean isHeadshot() {
        return this.isHeadshot;
    }

    public Player getDamager() {
        return this.damager;
    }

    public Player getVictim() {
        return this.victim;
    }
}
