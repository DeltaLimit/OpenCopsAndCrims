/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.UUID
 */
package ro.Fr33styler.CounterStrike.Cache;

import java.util.UUID;

public class PlayerStatus {
    private int kills = 0;
    private int deaths = 0;
    private String uuid = null;
    private String name = null;
    private int headshotkills = 0;
    private int roundKills = 0;
    private int bombplanted = 0;

    public PlayerStatus(String string, UUID uUID) {
        this.uuid = uUID.toString();
        this.name = string;
    }

    public int getKills() {
        return this.kills;
    }

    public int getRoundKills() {
        return this.roundKills;
    }

    public int getDeaths() {
        return this.deaths;
    }

    public String getUUID() {
        return this.uuid;
    }

    public int getBombPlanted() {
        return this.bombplanted;
    }

    public int getHeadshotKill() {
        return this.headshotkills;
    }

    public String getName() {
        return this.name;
    }

    public void addBombPlanted() {
        ++this.bombplanted;
    }

    public void addHeadshotKill() {
        ++this.headshotkills;
    }

    public void addKill() {
        ++this.kills;
        ++this.roundKills;
    }

    public void resetRound() {
        this.roundKills = 0;
    }

    public void addDeath() {
        ++this.deaths;
    }
}
