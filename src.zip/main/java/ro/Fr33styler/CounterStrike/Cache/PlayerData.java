/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Collection
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.scoreboard.Scoreboard
 *  ro.Fr33styler.CounterStrike.Main
 */
package ro.Fr33styler.CounterStrike.Cache;

import java.util.Collection;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scoreboard.Scoreboard;
import ro.Fr33styler.CounterStrike.Main;

public class PlayerData {
    private Main main;
    private final float xp;
    private final int food;
    private final int level;
    private final Player p;
    private final Location loc;
    private final GameMode mode;
    private final double health;
    private final int fireticks;
    private final float flyspeed;
    private final float walkspeed;
    private final boolean isFlying;
    private final float fallDistance;
    private final Scoreboard scoreboard;
    private final ItemStack[] armour;
    private final ItemStack[] inventory;
    private final Collection<PotionEffect> effects;

    public PlayerData(Main main, Player player) {
        this.p = player;
        this.main = main;
        this.xp = player.getExp();
        this.level = player.getLevel();
        this.loc = player.getLocation();
        this.health = player.getHealth();
        this.mode = player.getGameMode();
        this.food = player.getFoodLevel();
        this.isFlying = player.getAllowFlight();
        this.flyspeed = player.getFlySpeed();
        this.fireticks = player.getFireTicks();
        this.walkspeed = player.getWalkSpeed();
        this.scoreboard = player.getScoreboard();
        this.fallDistance = player.getFallDistance();
        this.effects = player.getActivePotionEffects();
        this.inventory = player.getInventory().getContents();
        this.armour = player.getInventory().getArmorContents();
        main.getManager().clearPlayer(player);
    }

    public void restore(boolean bl) {
        if (bl) {
            this.p.teleport(this.loc);
        }
        this.p.setExp(this.xp);
        this.p.setLevel(this.level);
        this.p.setGameMode(this.mode);
        this.p.setHealth(20.0);
        this.p.setFoodLevel(this.food);
        if (this.isFlying) {
            this.p.setAllowFlight(true);
            this.p.setFlying(true);
        } else {
            this.p.setAllowFlight(true);
            this.p.setFlying(false);
            this.p.setAllowFlight(false);
        }
        this.p.setFlySpeed(this.flyspeed);
        this.p.setFireTicks(this.fireticks);
        this.p.setWalkSpeed(this.walkspeed);
        this.p.setFallDistance(this.fallDistance);
        this.p.getInventory().setArmorContents(this.armour);
        this.p.getInventory().setContents(this.inventory);
        this.main.getVersionInterface().setHandSpeed(this.p, 4.0);
        for (PotionEffect potionEffect : this.p.getActivePotionEffects()) {
            this.p.removePotionEffect(potionEffect.getType());
        }
        for (PotionEffect potionEffect : this.effects) {
            this.p.addPotionEffect(potionEffect);
        }
        this.p.setScoreboard(this.scoreboard);
        this.p.updateInventory();
    }
}
