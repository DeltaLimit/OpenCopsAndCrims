/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ro.Fr33styler.CounterStrike.Cache;

public enum ShopType {
    GUN,
    GRENADE,
    ITEMS;

}
