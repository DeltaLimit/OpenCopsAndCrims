/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ro.Fr33styler.CounterStrike.Cache;

public class Defuse {
    private int time;
    private final int max;

    public Defuse(int n) {
        this.time = n;
        this.max = n;
    }

    public void setTime(int n) {
        this.time = n;
    }

    public int getTime() {
        return this.time;
    }

    public int getMax() {
        return this.max;
    }
}
