/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.bukkit.Material
 *  ro.Fr33styler.CounterStrike.Cache.ShopType
 *  ro.Fr33styler.CounterStrike.Handler.GameTeam$Role
 */
package ro.Fr33styler.CounterStrike.Cache;

import org.bukkit.Material;
import ro.Fr33styler.CounterStrike.Cache.ShopType;
import ro.Fr33styler.CounterStrike.Handler.GameTeam;

public class PlayerShop {
    private int slot;
    private int price;
    private GameTeam.Role role;
    private String name;
    private String lore;
    private int slot_place;
    private String weapon_name;
    private Material material;
    private ShopType shoptype;
    private boolean permission;
    private String it_name;

    public PlayerShop(String string, String string2, int n, int n2, String string3, GameTeam.Role role, boolean bl) {
        this.name = string2;
        this.slot = n;
        this.price = n2;
        this.lore = string3;
        this.role = role;
        this.shoptype = ShopType.GUN;
        this.weapon_name = string;
        this.permission = bl;
    }

    public PlayerShop(String string, String string2, int n, int n2, String string3) {
        this.name = string2;
        this.slot = n;
        this.price = n2;
        this.lore = string3;
        this.weapon_name = string;
        this.shoptype = ShopType.GRENADE;
    }

    public PlayerShop(int n, int n2, String string, Material material, int n3, String string2, GameTeam.Role role, boolean bl, String string3) {
        this.shoptype = ShopType.ITEMS;
        this.slot = n;
        this.name = string;
        this.price = n3;
        this.lore = string2;
        this.it_name = string3;
        this.role = role;
        this.slot_place = n2;
        this.material = material;
        this.permission = bl;
    }

    public boolean hasPermission() {
        return this.permission;
    }

    public ShopType getType() {
        return this.shoptype;
    }

    public GameTeam.Role getRole() {
        return this.role;
    }

    public int getPrice() {
        return this.price;
    }

    public int getSlotPlace() {
        return this.slot_place;
    }

    public String getItName() {
        return this.it_name;
    }

    public String getLore() {
        return this.lore;
    }

    public Material getMaterial() {
        return this.material;
    }

    public int getSlot() {
        return this.slot;
    }

    public String getName() {
        return this.name;
    }

    public String getWeaponName() {
        return this.weapon_name;
    }
}
